(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications/subscription.coffee.js                          //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var fields,                                                            // 1
  slice = [].slice;                                                    //
                                                                       //
fields = {                                                             // 1
  t: 1,                                                                // 2
  ts: 1,                                                               // 2
  ls: 1,                                                               // 2
  name: 1,                                                             // 2
  rid: 1,                                                              // 2
  code: 1,                                                             // 2
  f: 1,                                                                // 2
  u: 1,                                                                // 2
  open: 1,                                                             // 2
  alert: 1,                                                            // 2
  roles: 1,                                                            // 2
  unread: 1,                                                           // 2
  archived: 1,                                                         // 2
  desktopNotifications: 1,                                             // 2
  desktopNotificationDuration: 1,                                      // 2
  mobilePushNotifications: 1,                                          // 2
  emailNotifications: 1,                                               // 2
  unreadAlert: 1,                                                      // 2
  _updatedAt: 1                                                        // 2
};                                                                     //
                                                                       //
Meteor.methods({                                                       // 1
  'subscriptions/get': function() {                                    // 24
    var options;                                                       // 25
    if (!Meteor.userId()) {                                            // 25
      return [];                                                       // 26
    }                                                                  //
    this.unblock();                                                    // 25
    options = {                                                        // 25
      fields: fields                                                   // 31
    };                                                                 //
    return RocketChat.models.Subscriptions.findByUserId(Meteor.userId(), options).fetch();
  },                                                                   //
  'subscriptions/sync': function(updatedAt) {                          // 24
    var options;                                                       // 36
    if (!Meteor.userId()) {                                            // 36
      return {};                                                       // 37
    }                                                                  //
    this.unblock();                                                    // 36
    options = {                                                        // 36
      fields: fields                                                   // 42
    };                                                                 //
    return RocketChat.models.Subscriptions.dinamicFindChangesAfter('findByUserId', updatedAt, Meteor.userId(), options);
  }                                                                    //
});                                                                    //
                                                                       //
RocketChat.models.Subscriptions.on('change', function() {              // 1
  var args, i, len, record, records, results, type;                    // 48
  type = arguments[0], args = 2 <= arguments.length ? slice.call(arguments, 1) : [];
  records = RocketChat.models.Subscriptions.getChangedRecords(type, args[0], fields);
  results = [];                                                        // 50
  for (i = 0, len = records.length; i < len; i++) {                    //
    record = records[i];                                               //
    results.push(RocketChat.Notifications.notifyUser(record.u._id, 'subscriptions-changed', type, record));
  }                                                                    // 50
  return results;                                                      //
});                                                                    // 47
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=subscription.coffee.js.map
