(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/findUser.coffee.js                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                       // 1
  findUser: function(account_email, account_pass) {                    // 2
    var exist, result;                                                 // 3
    exist = RocketChat.models.Users.findOne({                          // 3
      name: account_email                                              // 3
    });                                                                //
    result = {};                                                       // 3
    if (exist) {                                                       // 8
      result.status = true;                                            // 10
    } else {                                                           //
      result.status = false;                                           // 13
    }                                                                  //
    result.email = account_email;                                      // 3
    result.password = account_pass;                                    // 3
    return result;                                                     // 18
  }                                                                    //
});                                                                    //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=findUser.coffee.js.map
