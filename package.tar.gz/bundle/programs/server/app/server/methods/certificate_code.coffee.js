(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/certificate_code.coffee.js                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Future;                                                            // 1
                                                                       //
Future = Npm.require('fibers/future');                                 // 1
                                                                       //
Meteor.methods({                                                       // 1
  certificate_code: function(uid, formData, email, pass) {             // 3
    var code, future;                                                  // 4
    future = new Future();                                             // 4
    code = formData.captcha;                                           // 4
    Meteor.http.call("POST", "http://140.112.124.238/api/certificate_code", {
      data: {                                                          // 7
        uid: uid,                                                      // 7
        code: code                                                     // 7
      }                                                                //
    }, function(error, result) {                                       //
      return future["return"](result);                                 //
    });                                                                //
    return future.wait();                                              // 14
  }                                                                    //
});                                                                    //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=certificate_code.coffee.js.map
