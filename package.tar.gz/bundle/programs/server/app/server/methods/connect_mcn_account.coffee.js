(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/connect_mcn_account.coffee.js                        //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Future;                                                            // 1
                                                                       //
Future = Npm.require('fibers/future');                                 // 1
                                                                       //
Meteor.methods({                                                       // 1
  checkaccount: function(userName, password) {                         // 3
    var future;                                                        // 4
    future = new Future();                                             // 4
    Meteor.http.call("POST", "http://140.112.124.238/api/acc_query", {
      data: {                                                          // 6
        username: userName,                                            // 6
        password: password                                             // 6
      }                                                                //
    }, function(error, result) {                                       //
      if (result.statusCode === 200) {                                 // 8
        return future["return"](result.statusCode);                    //
      } else {                                                         //
        return future["return"](result.statusCode);                    //
      }                                                                //
    });                                                                //
    return future.wait();                                              // 14
  }                                                                    //
});                                                                    //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=connect_mcn_account.coffee.js.map
