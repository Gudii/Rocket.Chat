(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/connect_mcn_account.coffee.js                        //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Future;                                                            // 1
                                                                       //
Future = Npm.require('fibers/future');                                 // 1
                                                                       //
Meteor.methods({                                                       // 1
  acc_verify: function(formData) {                                     // 3
    var future;                                                        // 4
    future = new Future();                                             // 4
    Meteor.http.call("POST", "http://140.112.124.238/api/acc_verify", {
      data: {                                                          // 6
        username: formData.emailOrUsername,                            // 6
        password: formData.pass                                        // 6
      }                                                                //
    }, function(error, result) {                                       //
      return future["return"](result);                                 //
    });                                                                //
    return future.wait();                                              // 12
  }                                                                    //
});                                                                    //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=connect_mcn_account.coffee.js.map
