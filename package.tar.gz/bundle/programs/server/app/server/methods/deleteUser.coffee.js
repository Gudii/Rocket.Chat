(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/deleteUser.coffee.js                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                       // 1
  deleteUser: function(userId) {                                       // 2
    var adminCount, user, userIsAdmin;                                 // 3
    if (!Meteor.userId()) {                                            // 3
      throw new Meteor.Error('error-invalid-user', "Invalid user", {   // 4
        method: 'deleteUser'                                           // 4
      });                                                              //
    }                                                                  //
    user = RocketChat.models.Users.findOneById(Meteor.userId());       // 3
    if (RocketChat.authz.hasPermission(Meteor.userId(), 'delete-user') !== true) {
      throw new Meteor.Error('error-not-allowed', "Not allowed", {     // 9
        method: 'deleteUser'                                           // 9
      });                                                              //
    }                                                                  //
    user = RocketChat.models.Users.findOneById(userId);                // 3
    if (user == null) {                                                // 12
      throw new Meteor.Error('error-invalid-user', "Invalid user", {   // 13
        method: 'deleteUser'                                           // 13
      });                                                              //
    }                                                                  //
    adminCount = Meteor.users.find({                                   // 3
      roles: {                                                         // 16
        $in: ['admin']                                                 // 16
      }                                                                //
    }).count();                                                        //
    userIsAdmin = user.roles.indexOf('admin') > -1;                    // 3
    if (adminCount === 1 && userIsAdmin) {                             // 18
      throw new Meteor.Error('error-action-not-allowed', 'Leaving the app without admins is not allowed', {
        method: 'deleteUser',                                          // 19
        action: 'Remove_last_admin'                                    // 19
      });                                                              //
    }                                                                  //
    RocketChat.deleteUser(userId);                                     // 3
    return true;                                                       // 23
  }                                                                    //
});                                                                    //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=deleteUser.coffee.js.map
