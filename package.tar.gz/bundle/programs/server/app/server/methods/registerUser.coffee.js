(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/registerUser.coffee.js                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                       // 1
  registerUser: function(formData) {                                   // 2
    var customFields, customFieldsMeta, e, field, fieldName, modifyRecordField, update, userData, userId, value;
    if (RocketChat.settings.get('Accounts_RegistrationForm') === 'Disabled') {
      throw new Meteor.Error('error-user-registration-disabled', 'User registration is disabled', {
        method: 'registerUser'                                         // 4
      });                                                              //
    } else if (RocketChat.settings.get('Accounts_RegistrationForm') === 'Secret URL' && (!formData.secretURL || formData.secretURL !== RocketChat.settings.get('Accounts_RegistrationForm_SecretURL'))) {
      throw new Meteor.Error('error-user-registration-secret', 'User registration is only allowed via Secret URL', {
        method: 'registerUser'                                         // 7
      });                                                              //
    }                                                                  //
    RocketChat.validateEmailDomain(formData.email);                    // 3
    userData = {                                                       // 3
      email: s.trim(formData.email.toLowerCase()),                     // 12
      password: formData.pass                                          // 12
    };                                                                 //
    userId = Accounts.createUser(userData);                            // 3
    RocketChat.models.Users.setName(userId, s.trim(formData.name));    // 3
    if (RocketChat.settings.get('Accounts_CustomFields') !== '') {     // 20
      try {                                                            // 21
        customFieldsMeta = JSON.parse(RocketChat.settings.get('Accounts_CustomFields'));
        customFields = {};                                             // 22
        for (fieldName in customFieldsMeta) {                          // 25
          field = customFieldsMeta[fieldName];                         //
          customFields[fieldName] = formData[fieldName];               // 26
          if (field.required === true && !formData[fieldName]) {       // 27
            throw new Meteor.Error('error-user-registration-custom-field', "Field " + fieldName + " is required", {
              method: 'registerUser'                                   // 28
            });                                                        //
          }                                                            //
          if (field.type === 'select' && field.options.indexOf(formData[fieldName]) === -1) {
            throw new Meteor.Error('error-user-registration-custom-field', "Value for field " + fieldName + " is invalid", {
              method: 'registerUser'                                   // 31
            });                                                        //
          }                                                            //
          if ((field.maxLength != null) && formData[fieldName].length > field.maxLength) {
            throw new Meteor.Error('error-user-registration-custom-field', "Max length of field " + fieldName + " " + field.maxLength, {
              method: 'registerUser'                                   // 34
            });                                                        //
          }                                                            //
          if ((field.minLength != null) && formData[fieldName].length < field.minLength) {
            throw new Meteor.Error('error-user-registration-custom-field', "Min length of field " + fieldName + " " + field.minLength, {
              method: 'registerUser'                                   // 37
            });                                                        //
          }                                                            //
        }                                                              // 25
        RocketChat.models.Users.setCustomFields(userId, customFields);
        for (fieldName in customFields) {                              // 41
          value = customFields[fieldName];                             //
          if (!(customFieldsMeta[fieldName].modifyRecordField != null)) {
            continue;                                                  //
          }                                                            //
          modifyRecordField = customFieldsMeta[fieldName].modifyRecordField;
          update = {};                                                 // 42
          if (modifyRecordField.array === true) {                      // 44
            update.$addToSet = {};                                     // 45
            update.$addToSet[modifyRecordField.field] = value;         // 45
          } else {                                                     //
            update.$set = {};                                          // 48
            update.$set[modifyRecordField.field] = value;              // 48
          }                                                            //
          RocketChat.models.Users.update(userId, update);              // 42
        }                                                              // 41
      } catch (_error) {                                               //
        e = _error;                                                    // 54
        console.error('Invalid JSON for Accounts_CustomFields');       // 54
      }                                                                //
    }                                                                  //
    if (userData.email) {                                              // 56
      Accounts.sendVerificationEmail(userId, userData.email);          // 57
    }                                                                  //
    return userId;                                                     // 59
  }                                                                    //
});                                                                    //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=registerUser.coffee.js.map
