(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/startup/migrations/v056.js                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
RocketChat.Migrations.add({                                            // 1
	version: 56,                                                          // 2
	up: function () {                                                     // 3
		RocketChat.models.Messages.find({ _id: /\./ }).forEach(function (message) {
			var oldId = message._id;                                            // 5
			message._id = message._id.replace(/(.*)\.S?(.*)/, 'slack-$1-$2');   // 6
			RocketChat.models.Messages.insert(message);                         // 7
			RocketChat.models.Messages.remove({ _id: oldId });                  // 8
		});                                                                  //
	}                                                                     //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=v056.js.map
