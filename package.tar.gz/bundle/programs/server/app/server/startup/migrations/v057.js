(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/startup/migrations/v057.js                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
RocketChat.Migrations.add({                                            // 1
	version: 57,                                                          // 2
	up: function () {                                                     // 3
		RocketChat.models.Messages.find({ _id: /slack-([a-zA-Z0-9]+)S([0-9]+-[0-9]+)/ }).forEach(function (message) {
			var oldId = message._id;                                            // 5
			message._id = message._id.replace(/slack-([a-zA-Z0-9]+)S([0-9]+-[0-9]+)/, 'slack-$1-$2');
			RocketChat.models.Messages.insert(message);                         // 7
			RocketChat.models.Messages.remove({ _id: oldId });                  // 8
		});                                                                  //
                                                                       //
		RocketChat.models.Messages.find({ _id: /slack-slack/ }).forEach(function (message) {
			var oldId = message._id;                                            // 12
			message._id = message._id.replace('slack-slack', 'slack');          // 13
			RocketChat.models.Messages.insert(message);                         // 14
			RocketChat.models.Messages.remove({ _id: oldId });                  // 15
		});                                                                  //
                                                                       //
		RocketChat.models.Messages.find({ _id: /\./ }).forEach(function (message) {
			var oldId = message._id;                                            // 19
			message._id = message._id.replace(/(.*)\.?S(.*)/, 'slack-$1-$2');   // 20
			message._id = message._id.replace(/\./g, '-');                      // 21
			RocketChat.models.Messages.remove({ _id: message._id });            // 22
			RocketChat.models.Messages.insert(message);                         // 23
			RocketChat.models.Messages.remove({ _id: oldId });                  // 24
		});                                                                  //
	}                                                                     //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=v057.js.map
