(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var ECMAScript = Package.ecmascript.ECMAScript;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var Migrations, migrated;

var require = meteorInstall({"node_modules":{"meteor":{"rocketchat:migrations":{"migrations.js":["moment",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/rocketchat_migrations/migrations.js                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var moment;module.import('moment',{"default":function(v){moment=v}});                                          // 1
                                                                                                               //
/*                                                                                                             // 3
	Adds migration capabilities. Migrations are defined like:                                                     //
                                                                                                               //
	Migrations.add({                                                                                              //
		up: function() {}, //*required* code to run to migrate upwards                                               //
		version: 1, //*required* number to identify migration order                                                  //
		down: function() {}, //*optional* code to run to migrate downwards                                           //
		name: 'Something' //*optional* display name for the migration                                                //
	});                                                                                                           //
                                                                                                               //
	The ordering of migrations is determined by the version you set.                                              //
                                                                                                               //
	To run the migrations, set the MIGRATE environment variable to either                                         //
	'latest' or the version number you want to migrate to. Optionally, append                                     //
	',exit' if you want the migrations to exit the meteor process, e.g if you're                                  //
	migrating from a script (remember to pass the --once parameter).                                              //
                                                                                                               //
	e.g:                                                                                                          //
	MIGRATE="latest" mrt # ensure we'll be at the latest version and run the app                                  //
	MIGRATE="latest,exit" mrt --once # ensure we'll be at the latest version and exit                             //
	MIGRATE="2,exit" mrt --once # migrate to version 2 and exit                                                   //
                                                                                                               //
	Note: Migrations will lock ensuring only 1 app can be migrating at once. If                                   //
	a migration crashes, the control record in the migrations collection will                                     //
	remain locked and at the version it was at previously, however the db could                                   //
	be in an inconsistant state.                                                                                  //
*/                                                                                                             //
                                                                                                               //
// since we'll be at version 0 by default, we should have a migration set for                                  // 31
// it.                                                                                                         // 32
var DefaultMigration = {                                                                                       // 33
	version: 0,                                                                                                   // 34
	up: function () {                                                                                             // 35
		function up() {                                                                                              // 35
			// @TODO: check if collection "migrations" exist                                                            // 36
			// If exists, rename and rerun _migrateTo                                                                   // 37
		}                                                                                                            // 38
                                                                                                               //
		return up;                                                                                                   // 35
	}()                                                                                                           // 35
};                                                                                                             // 33
                                                                                                               //
Migrations = {                                                                                                 // 41
	_list: [DefaultMigration],                                                                                    // 42
	options: {                                                                                                    // 43
		// false disables logging                                                                                    // 44
		log: true,                                                                                                   // 45
		// null or a function                                                                                        // 46
		logger: null,                                                                                                // 47
		// enable/disable info log "already at latest."                                                              // 48
		logIfLatest: true,                                                                                           // 49
		// lock will be valid for this amount of minutes                                                             // 50
		lockExpiration: 5,                                                                                           // 51
		// retry interval in seconds                                                                                 // 52
		retryInterval: 10,                                                                                           // 53
		// max number of attempts to retry unlock                                                                    // 54
		maxAttempts: 30,                                                                                             // 55
		// migrations collection name                                                                                // 56
		collectionName: "migrations"                                                                                 // 57
		// collectionName: "rocketchat_migrations"                                                                   // 58
	},                                                                                                            // 43
	config: function () {                                                                                         // 60
		function config(opts) {                                                                                      // 60
			this.options = _.extend({}, this.options, opts);                                                            // 61
		}                                                                                                            // 62
                                                                                                               //
		return config;                                                                                               // 60
	}()                                                                                                           // 60
};                                                                                                             // 41
                                                                                                               //
Migrations._collection = new Mongo.Collection(Migrations.options.collectionName);                              // 65
                                                                                                               //
/* Create a box around messages for displaying on a console.log */                                             // 67
function makeABox(message) {                                                                                   // 68
	var color = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'red';                        // 68
                                                                                                               //
	if (!_.isArray(message)) {                                                                                    // 69
		message = message.split("\n");                                                                               // 70
	}                                                                                                             // 71
	var len = _(message).reduce(function (memo, msg) {                                                            // 72
		return Math.max(memo, msg.length);                                                                           // 73
	}, 0) + 4;                                                                                                    // 74
	var text = message.map(function (msg) {                                                                       // 75
		return "|"[color] + s.lrpad(msg, len)[color] + "|"[color];                                                   // 76
	}).join("\n");                                                                                                // 77
	var topLine = "+"[color] + s.pad('', len, '-')[color] + "+"[color];                                           // 78
	var separator = "|"[color] + s.pad('', len, '') + "|"[color];                                                 // 79
	var bottomLine = "+"[color] + s.pad('', len, '-')[color] + "+"[color];                                        // 80
	return '\n' + topLine + '\n' + separator + '\n' + text + '\n' + separator + '\n' + bottomLine + '\n';         // 81
}                                                                                                              // 82
                                                                                                               //
/*                                                                                                             // 84
	Logger factory function. Takes a prefix string and options object                                             //
	and uses an injected `logger` if provided, else falls back to                                                 //
	Meteor's `Log` package.                                                                                       //
	Will send a log object to the injected logger, on the following form:                                         //
		message: String                                                                                              //
		level: String (info, warn, error, debug)                                                                     //
		tag: 'Migrations'                                                                                            //
*/                                                                                                             //
function createLogger(prefix) {                                                                                // 93
	check(prefix, String);                                                                                        // 94
                                                                                                               //
	// Return noop if logging is disabled.                                                                        // 96
	if (Migrations.options.log === false) {                                                                       // 97
		return function () {};                                                                                       // 98
	}                                                                                                             // 99
                                                                                                               //
	return function (level, message) {                                                                            // 101
		check(level, Match.OneOf('info', 'error', 'warn', 'debug'));                                                 // 102
		check(message, Match.OneOf(String, [String]));                                                               // 103
                                                                                                               //
		var logger = Migrations.options && Migrations.options.logger;                                                // 105
                                                                                                               //
		if (logger && _.isFunction(logger)) {                                                                        // 107
                                                                                                               //
			logger({                                                                                                    // 109
				level: level,                                                                                              // 110
				message: message,                                                                                          // 111
				tag: prefix                                                                                                // 112
			});                                                                                                         // 109
		} else {                                                                                                     // 115
			Log[level]({                                                                                                // 116
				message: prefix + ': ' + message                                                                           // 117
			});                                                                                                         // 116
		}                                                                                                            // 119
	};                                                                                                            // 120
}                                                                                                              // 121
                                                                                                               //
var log;                                                                                                       // 123
                                                                                                               //
var options = Migrations.options;                                                                              // 125
                                                                                                               //
// collection holding the control record                                                                       // 127
                                                                                                               //
log = createLogger('Migrations');                                                                              // 129
                                                                                                               //
['info', 'warn', 'error', 'debug'].forEach(function (level) {                                                  // 131
	log[level] = _.partial(log, level);                                                                           // 132
});                                                                                                            // 133
                                                                                                               //
// if (process.env.MIGRATE)                                                                                    // 135
//   Migrations.migrateTo(process.env.MIGRATE);                                                                // 136
                                                                                                               //
// Add a new migration:                                                                                        // 138
// {up: function *required                                                                                     // 139
//  version: Number *required                                                                                  // 140
//  down: function *optional                                                                                   // 141
//  name: String *optional                                                                                     // 142
// }                                                                                                           // 143
Migrations.add = function (migration) {                                                                        // 144
	if (typeof migration.up !== 'function') throw new Meteor.Error('Migration must supply an up function.');      // 145
                                                                                                               //
	if (typeof migration.version !== 'number') throw new Meteor.Error('Migration must supply a version number.');
                                                                                                               //
	if (migration.version <= 0) throw new Meteor.Error('Migration version must be greater than 0');               // 151
                                                                                                               //
	// Freeze the migration object to make it hereafter immutable                                                 // 154
	Object.freeze(migration);                                                                                     // 155
                                                                                                               //
	this._list.push(migration);                                                                                   // 157
	this._list = _.sortBy(this._list, function (m) {                                                              // 158
		return m.version;                                                                                            // 159
	});                                                                                                           // 160
};                                                                                                             // 161
                                                                                                               //
// Attempts to run the migrations using command in the form of:                                                // 163
// e.g 'latest', 'latest,exit', 2                                                                              // 164
// use 'XX,rerun' to re-run the migration at that version                                                      // 165
Migrations.migrateTo = function (command) {                                                                    // 166
	if (_.isUndefined(command) || command === '' || this._list.length === 0) throw new Error("Cannot migrate using invalid command: " + command);
                                                                                                               //
	if (typeof command === 'number') {                                                                            // 170
		var version = command;                                                                                       // 171
	} else {                                                                                                      // 172
		var version = command.split(',')[0];                                                                         // 173
		var subcommand = command.split(',')[1];                                                                      // 174
	}                                                                                                             // 175
                                                                                                               //
	var maxAttempts = Migrations.options.maxAttempts;                                                             // 177
	var retryInterval = Migrations.options.retryInterval;                                                         // 178
	for (var attempts = 1; attempts <= maxAttempts; attempts++) {                                                 // 179
		if (version === 'latest') {                                                                                  // 180
			migrated = this._migrateTo(_.last(this._list).version);                                                     // 181
		} else {                                                                                                     // 182
			migrated = this._migrateTo(parseInt(version), subcommand === 'rerun');                                      // 183
		}                                                                                                            // 184
		if (migrated) {                                                                                              // 185
			break;                                                                                                      // 186
		} else {                                                                                                     // 187
			var willRetry = void 0;                                                                                     // 188
			if (attempts < maxAttempts) {                                                                               // 189
				willRetry = ' Trying again in ' + retryInterval + ' seconds.';                                             // 190
				Meteor._sleepForMs(retryInterval * 1000);                                                                  // 191
			} else {                                                                                                    // 192
				willRetry = "";                                                                                            // 193
			}                                                                                                           // 194
			console.log(('Not migrating, control is locked. Attempt ' + attempts + '/' + maxAttempts + '.' + willRetry).yellow);
		}                                                                                                            // 196
	}                                                                                                             // 197
	if (!migrated) {                                                                                              // 198
		var control = this._getControl(); // Side effect: upserts control document.                                  // 199
		console.log(makeABox(["ERROR! SERVER STOPPED", "", "Your database migration control is locked.", "Please make sure you are running the latest version and try again.", "If the problem persists, please contact support.", "", "This Rocket.Chat version: " + RocketChat.Info.version, "Database locked at version: " + control.version, "Database target version: " + (version === 'latest' ? _.last(this._list).version : version), "", "Commit: " + RocketChat.Info.commit.hash, "Date: " + RocketChat.Info.commit.date, "Branch: " + RocketChat.Info.commit.branch, "Tag: " + RocketChat.Info.commit.tag]));
		process.exit(1);                                                                                             // 216
	}                                                                                                             // 217
                                                                                                               //
	// remember to run meteor with --once otherwise it will restart                                               // 219
	if (subcommand === 'exit') process.exit(0);                                                                   // 220
};                                                                                                             // 222
                                                                                                               //
// just returns the current version                                                                            // 224
Migrations.getVersion = function () {                                                                          // 225
	return this._getControl().version;                                                                            // 226
};                                                                                                             // 227
                                                                                                               //
// migrates to the specific version passed in                                                                  // 229
Migrations._migrateTo = function (version, rerun) {                                                            // 230
	var self = this;                                                                                              // 231
	var control = this._getControl(); // Side effect: upserts control document.                                   // 232
	var currentVersion = control.version;                                                                         // 233
                                                                                                               //
	if (lock() === false) {                                                                                       // 235
		// log.info('Not migrating, control is locked.');                                                            // 236
		// Warning                                                                                                   // 237
		return false;                                                                                                // 238
	}                                                                                                             // 239
                                                                                                               //
	if (rerun) {                                                                                                  // 241
		log.info('Rerunning version ' + version);                                                                    // 242
		migrate('up', version);                                                                                      // 243
		log.info('Finished migrating.');                                                                             // 244
		unlock();                                                                                                    // 245
		return true;                                                                                                 // 246
	}                                                                                                             // 247
                                                                                                               //
	if (currentVersion === version) {                                                                             // 249
		if (this.options.logIfLatest) {                                                                              // 250
			log.info('Not migrating, already at version ' + version);                                                   // 251
		}                                                                                                            // 252
		unlock();                                                                                                    // 253
		return true;                                                                                                 // 254
	}                                                                                                             // 255
                                                                                                               //
	var startIdx = this._findIndexByVersion(currentVersion);                                                      // 257
	var endIdx = this._findIndexByVersion(version);                                                               // 258
                                                                                                               //
	// log.info('startIdx:' + startIdx + ' endIdx:' + endIdx);                                                    // 260
	log.info('Migrating from version ' + this._list[startIdx].version + ' -> ' + this._list[endIdx].version);     // 261
                                                                                                               //
	// run the actual migration                                                                                   // 263
	function migrate(direction, idx) {                                                                            // 264
		var migration = self._list[idx];                                                                             // 265
                                                                                                               //
		if (typeof migration[direction] !== 'function') {                                                            // 267
			unlock();                                                                                                   // 268
			throw new Meteor.Error('Cannot migrate ' + direction + ' on version ' + migration.version);                 // 269
		}                                                                                                            // 270
                                                                                                               //
		function maybeName() {                                                                                       // 272
			return migration.name ? ' (' + migration.name + ')' : '';                                                   // 273
		}                                                                                                            // 274
                                                                                                               //
		log.info('Running ' + direction + '() on version ' + migration.version + maybeName());                       // 276
                                                                                                               //
		try {                                                                                                        // 278
			migration[direction](migration);                                                                            // 279
		} catch (e) {                                                                                                // 280
			console.log(makeABox(["ERROR! SERVER STOPPED", "", "Your database migration failed:", e.message, "", "Please make sure you are running the latest version and try again.", "If the problem persists, please contact support.", "", "This Rocket.Chat version: " + RocketChat.Info.version, "Database locked at version: " + control.version, "Database target version: " + version, "", "Commit: " + RocketChat.Info.commit.hash, "Date: " + RocketChat.Info.commit.date, "Branch: " + RocketChat.Info.commit.branch, "Tag: " + RocketChat.Info.commit.tag]));
			process.exit(1);                                                                                            // 299
		}                                                                                                            // 300
	}                                                                                                             // 301
                                                                                                               //
	// Returns true if lock was acquired.                                                                         // 303
	function lock() {                                                                                             // 304
		var date = new Date();                                                                                       // 305
		var dateMinusInterval = moment(date).subtract(self.options.lockExpiration, 'minutes').toDate();              // 306
		var build = RocketChat.Info ? RocketChat.Info.build.date : date;                                             // 307
                                                                                                               //
		// This is atomic. The selector ensures only one caller at a time will see                                   // 309
		// the unlocked control, and locking occurs in the same update's modifier.                                   // 310
		// All other simultaneous callers will get false back from the update.                                       // 311
		return self._collection.update({                                                                             // 312
			_id: 'control',                                                                                             // 313
			$or: [{                                                                                                     // 314
				locked: false                                                                                              // 315
			}, {                                                                                                        // 314
				lockedAt: {                                                                                                // 317
					$lt: dateMinusInterval                                                                                    // 318
				}                                                                                                          // 317
			}, {                                                                                                        // 316
				buildAt: {                                                                                                 // 321
					$ne: build                                                                                                // 322
				}                                                                                                          // 321
			}]                                                                                                          // 320
		}, {                                                                                                         // 312
			$set: {                                                                                                     // 326
				locked: true,                                                                                              // 327
				lockedAt: date,                                                                                            // 328
				buildAt: build                                                                                             // 329
			}                                                                                                           // 326
		}) === 1;                                                                                                    // 325
	}                                                                                                             // 332
                                                                                                               //
	// Side effect: saves version.                                                                                // 335
	function unlock() {                                                                                           // 336
		self._setControl({                                                                                           // 337
			locked: false,                                                                                              // 338
			version: currentVersion                                                                                     // 339
		});                                                                                                          // 337
	}                                                                                                             // 341
                                                                                                               //
	if (currentVersion < version) {                                                                               // 343
		for (var i = startIdx; i < endIdx; i++) {                                                                    // 344
			migrate('up', i + 1);                                                                                       // 345
			currentVersion = self._list[i + 1].version;                                                                 // 346
			self._setControl({                                                                                          // 347
				locked: true,                                                                                              // 348
				version: currentVersion                                                                                    // 349
			});                                                                                                         // 347
		}                                                                                                            // 351
	} else {                                                                                                      // 352
		for (var i = startIdx; i > endIdx; i--) {                                                                    // 353
			migrate('down', i);                                                                                         // 354
			currentVersion = self._list[i - 1].version;                                                                 // 355
			self._setControl({                                                                                          // 356
				locked: true,                                                                                              // 357
				version: currentVersion                                                                                    // 358
			});                                                                                                         // 356
		}                                                                                                            // 360
	}                                                                                                             // 361
                                                                                                               //
	unlock();                                                                                                     // 363
	log.info('Finished migrating.');                                                                              // 364
};                                                                                                             // 365
                                                                                                               //
// gets the current control record, optionally creating it if non-existant                                     // 367
Migrations._getControl = function () {                                                                         // 368
	var control = this._collection.findOne({                                                                      // 369
		_id: 'control'                                                                                               // 370
	});                                                                                                           // 369
                                                                                                               //
	return control || this._setControl({                                                                          // 373
		version: 0,                                                                                                  // 374
		locked: false                                                                                                // 375
	});                                                                                                           // 373
};                                                                                                             // 377
                                                                                                               //
// sets the control record                                                                                     // 379
Migrations._setControl = function (control) {                                                                  // 380
	// be quite strict                                                                                            // 381
	check(control.version, Number);                                                                               // 382
	check(control.locked, Boolean);                                                                               // 383
                                                                                                               //
	this._collection.update({                                                                                     // 385
		_id: 'control'                                                                                               // 386
	}, {                                                                                                          // 385
		$set: {                                                                                                      // 388
			version: control.version,                                                                                   // 389
			locked: control.locked                                                                                      // 390
		}                                                                                                            // 388
	}, {                                                                                                          // 387
		upsert: true                                                                                                 // 393
	});                                                                                                           // 392
                                                                                                               //
	return control;                                                                                               // 396
};                                                                                                             // 397
                                                                                                               //
// returns the migration index in _list or throws if not found                                                 // 399
Migrations._findIndexByVersion = function (version) {                                                          // 400
	for (var i = 0; i < this._list.length; i++) {                                                                 // 401
		if (this._list[i].version === version) return i;                                                             // 402
	}                                                                                                             // 404
                                                                                                               //
	throw new Meteor.Error('Can\'t find migration version ' + version);                                           // 406
};                                                                                                             // 407
                                                                                                               //
//reset (mainly intended for tests)                                                                            // 409
Migrations._reset = function () {                                                                              // 410
	this._list = [{                                                                                               // 411
		version: 0,                                                                                                  // 412
		up: function () {                                                                                            // 413
			function up() {}                                                                                            // 413
                                                                                                               //
			return up;                                                                                                  // 413
		}()                                                                                                          // 413
	}];                                                                                                           // 411
	this._collection.remove({});                                                                                  // 415
};                                                                                                             // 416
                                                                                                               //
RocketChat.Migrations = Migrations;                                                                            // 418
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/rocketchat:migrations/migrations.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:migrations'] = {};

})();

//# sourceMappingURL=rocketchat_migrations.js.map
