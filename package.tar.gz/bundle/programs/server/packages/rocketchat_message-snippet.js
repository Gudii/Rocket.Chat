(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var RocketChatFile = Package['rocketchat:file'].RocketChatFile;
var Random = Package.random.Random;
var _ = Package.underscore._;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;

var require = meteorInstall({"node_modules":{"meteor":{"rocketchat:message-snippet":{"server":{"startup":{"settings.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_message-snippet/server/startup/settings.js                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.startup(function () {                                                                                         // 1
	RocketChat.settings.add('Message_AllowSnippeting', false, {                                                         // 2
		type: 'boolean',                                                                                                   // 3
		'public': true,                                                                                                    // 4
		group: 'Message'                                                                                                   // 5
	});                                                                                                                 // 2
	RocketChat.models.Permissions.upsert('snippet-message', {                                                           // 7
		$setOnInsert: {                                                                                                    // 8
			roles: ['owner', 'moderator', 'admin']                                                                            // 9
		}                                                                                                                  // 8
	});                                                                                                                 // 7
});                                                                                                                  // 12
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods":{"snippetMessage.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_message-snippet/server/methods/snippetMessage.js                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.methods({                                                                                                     // 1
	snippetMessage: function () {                                                                                       // 2
		function snippetMessage(message, filename) {                                                                       // 2
			if (typeof Meteor.userId() === 'undefined' || Meteor.userId() === null) {                                         // 3
				//noinspection JSUnresolvedFunction                                                                              // 4
				throw new Meteor.Error('error-invalid-user', 'Invalid user', { method: 'snippetMessage' });                      // 5
			}                                                                                                                 // 7
                                                                                                                     //
			var room = RocketChat.models.Rooms.findOne({ _id: message.rid });                                                 // 9
                                                                                                                     //
			if (typeof room === 'undefined' || room === null) {                                                               // 11
				return false;                                                                                                    // 12
			}                                                                                                                 // 13
                                                                                                                     //
			if (Array.isArray(room.usernames) && room.usernames.indexOf(Meteor.user().username) === -1) {                     // 15
				return false;                                                                                                    // 16
			}                                                                                                                 // 17
                                                                                                                     //
			// If we keep history of edits, insert a new message to store history information                                 // 19
			if (RocketChat.settings.get('Message_KeepHistory')) {                                                             // 20
				RocketChat.models.Messages.cloneAndSaveAsHistoryById(message._id);                                               // 21
			}                                                                                                                 // 22
                                                                                                                     //
			var me = RocketChat.models.Users.findOneById(Meteor.userId());                                                    // 24
                                                                                                                     //
			message.snippeted = true;                                                                                         // 26
			message.snippetedAt = Date.now;                                                                                   // 27
			message.snippetedBy = {                                                                                           // 28
				_id: Meteor.userId(),                                                                                            // 29
				username: me.username                                                                                            // 30
			};                                                                                                                // 28
                                                                                                                     //
			message = RocketChat.callbacks.run('beforeSaveMessage', message);                                                 // 33
                                                                                                                     //
			// Create the SnippetMessage                                                                                      // 35
			RocketChat.models.Messages.setSnippetedByIdAndUserId(message, filename, message.snippetedBy, message.snippeted, Date.now, filename);
                                                                                                                     //
			RocketChat.models.Messages.createWithTypeRoomIdMessageAndUser('message_snippeted', message.rid, '', me, { 'snippetId': message._id, 'snippetName': filename });
		}                                                                                                                  // 41
                                                                                                                     //
		return snippetMessage;                                                                                             // 2
	}()                                                                                                                 // 2
});                                                                                                                  // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"requests.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_message-snippet/server/requests.js                                                            //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/* global Cookies */                                                                                                 // 1
WebApp.connectHandlers.use('/snippet/download', function (req, res) {                                                // 2
	var cookie, rawCookies, ref, token, uid;                                                                            // 3
	cookie = new Cookies();                                                                                             // 4
                                                                                                                     //
	if ((typeof req !== 'undefined' && req !== null ? (ref = req.headers) !== null ? ref.cookie : void 0 : void 0) !== null) {
		rawCookies = req.headers.cookie;                                                                                   // 7
	}                                                                                                                   // 8
                                                                                                                     //
	if (rawCookies !== null) {                                                                                          // 10
		uid = cookie.get('rc_uid', rawCookies);                                                                            // 11
	}                                                                                                                   // 12
                                                                                                                     //
	if (rawCookies !== null) {                                                                                          // 14
		token = cookie.get('rc_token', rawCookies);                                                                        // 15
	}                                                                                                                   // 16
                                                                                                                     //
	if (uid === null) {                                                                                                 // 18
		uid = req.query.rc_uid;                                                                                            // 19
		token = req.query.rc_token;                                                                                        // 20
	}                                                                                                                   // 21
                                                                                                                     //
	var user = RocketChat.models.Users.findOneByIdAndLoginToken(uid, token);                                            // 23
                                                                                                                     //
	if (!(uid && token && user)) {                                                                                      // 25
		res.writeHead(403);                                                                                                // 26
		res.end();                                                                                                         // 27
		return false;                                                                                                      // 28
	}                                                                                                                   // 29
	var match = /^\/([^\/]+)\/(.*)/.exec(req.url);                                                                      // 30
                                                                                                                     //
	if (match[1]) {                                                                                                     // 32
		var snippet = RocketChat.models.Messages.findOne({                                                                 // 33
			'_id': match[1],                                                                                                  // 35
			'snippeted': true                                                                                                 // 36
		});                                                                                                                // 34
		var room = RocketChat.models.Rooms.findOne({ '_id': snippet.rid, 'usernames': { '$in': [user.username] } });       // 39
		if (room === undefined) {                                                                                          // 40
			res.writeHead(403);                                                                                               // 41
			res.end();                                                                                                        // 42
			return false;                                                                                                     // 43
		}                                                                                                                  // 44
                                                                                                                     //
		res.setHeader('Content-Disposition', 'attachment; filename*=UTF-8\'\'' + encodeURIComponent(snippet.snippetName));
		res.setHeader('Content-Type', 'application/octet-stream');                                                         // 47
                                                                                                                     //
		// Removing the ``` contained in the msg.                                                                          // 49
		var snippetContent = snippet.msg.substr(3, snippet.msg.length - 6);                                                // 50
		res.setHeader('Content-Length', snippetContent.length);                                                            // 51
		res.write(snippetContent);                                                                                         // 52
		res.end();                                                                                                         // 53
		return;                                                                                                            // 54
	}                                                                                                                   // 55
                                                                                                                     //
	res.writeHead(404);                                                                                                 // 57
	res.end();                                                                                                          // 58
	return;                                                                                                             // 59
});                                                                                                                  // 60
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications":{"snippetedMessagesByRoom.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_message-snippet/server/publications/snippetedMessagesByRoom.js                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.publish('snippetedMessages', function (rid) {                                                                 // 1
	var limit = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 50;                                 // 1
                                                                                                                     //
	if (typeof this.userId === 'undefined' || this.userId === null) {                                                   // 2
		return this.ready();                                                                                               // 3
	}                                                                                                                   // 4
                                                                                                                     //
	var publication = this;                                                                                             // 6
                                                                                                                     //
	var user = RocketChat.models.Users.findOneById(this.userId);                                                        // 8
                                                                                                                     //
	if (typeof user === 'undefined' || user === null) {                                                                 // 10
		return this.ready();                                                                                               // 11
	}                                                                                                                   // 12
                                                                                                                     //
	var cursorHandle = RocketChat.models.Messages.findSnippetedByRoom(rid, {                                            // 14
		sort: { ts: -1 },                                                                                                  // 17
		limit: limit                                                                                                       // 18
	}).observeChanges({                                                                                                 // 16
		added: function () {                                                                                               // 21
			function added(_id, record) {                                                                                     // 21
				publication.added('rocketchat_snippeted_message', _id, record);                                                  // 22
			}                                                                                                                 // 23
                                                                                                                     //
			return added;                                                                                                     // 21
		}(),                                                                                                               // 21
		changed: function () {                                                                                             // 24
			function changed(_id, record) {                                                                                   // 24
				publication.changed('rocketchat_snippeted_message', _id, record);                                                // 25
			}                                                                                                                 // 26
                                                                                                                     //
			return changed;                                                                                                   // 24
		}(),                                                                                                               // 24
		removed: function () {                                                                                             // 27
			function removed(_id) {                                                                                           // 27
				publication.removed('rocketchat_snippeted_message', _id);                                                        // 28
			}                                                                                                                 // 29
                                                                                                                     //
			return removed;                                                                                                   // 27
		}()                                                                                                                // 27
	});                                                                                                                 // 20
	this.ready();                                                                                                       // 31
                                                                                                                     //
	this.onStop = function () {                                                                                         // 33
		cursorHandle.stop();                                                                                               // 34
	};                                                                                                                  // 35
});                                                                                                                  // 36
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"snippetedMessage.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_message-snippet/server/publications/snippetedMessage.js                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.publish('snippetedMessage', function (_id) {                                                                  // 1
	if (typeof this.userId === 'undefined' || this.userId === null) {                                                   // 2
		return this.ready();                                                                                               // 3
	}                                                                                                                   // 4
                                                                                                                     //
	var snippet = RocketChat.models.Messages.findOne({ '_id': _id, snippeted: true });                                  // 6
	var user = RocketChat.models.Users.findOneById(this.userId);                                                        // 7
	var roomSnippetQuery = {                                                                                            // 8
		'_id': snippet.rid,                                                                                                // 9
		'usernames': {                                                                                                     // 10
			'$in': [user.username]                                                                                            // 11
		}                                                                                                                  // 10
	};                                                                                                                  // 8
                                                                                                                     //
	if (RocketChat.models.Rooms.findOne(roomSnippetQuery) === undefined) {                                              // 17
		return this.ready();                                                                                               // 18
	}                                                                                                                   // 19
                                                                                                                     //
	var publication = this;                                                                                             // 21
                                                                                                                     //
	if (typeof user === 'undefined' || user === null) {                                                                 // 24
		return this.ready();                                                                                               // 25
	}                                                                                                                   // 26
                                                                                                                     //
	var cursor = RocketChat.models.Messages.find({ '_id': _id }).observeChanges({                                       // 28
		added: function () {                                                                                               // 31
			function added(_id, record) {                                                                                     // 31
				publication.added('rocketchat_snippeted_message', _id, record);                                                  // 32
			}                                                                                                                 // 33
                                                                                                                     //
			return added;                                                                                                     // 31
		}(),                                                                                                               // 31
		changed: function () {                                                                                             // 34
			function changed(_id, record) {                                                                                   // 34
				publication.changed('rocketchat_snippeted_message', _id, record);                                                // 35
			}                                                                                                                 // 36
                                                                                                                     //
			return changed;                                                                                                   // 34
		}(),                                                                                                               // 34
		removed: function () {                                                                                             // 37
			function removed(_id) {                                                                                           // 37
				publication.removed('rocketchat_snippeted_message', _id);                                                        // 38
			}                                                                                                                 // 39
                                                                                                                     //
			return removed;                                                                                                   // 37
		}()                                                                                                                // 37
	});                                                                                                                 // 30
                                                                                                                     //
	this.ready();                                                                                                       // 42
                                                                                                                     //
	this.onStop = function () {                                                                                         // 44
		cursor.stop();                                                                                                     // 45
	};                                                                                                                  // 46
});                                                                                                                  // 47
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/rocketchat:message-snippet/server/startup/settings.js");
require("./node_modules/meteor/rocketchat:message-snippet/server/methods/snippetMessage.js");
require("./node_modules/meteor/rocketchat:message-snippet/server/requests.js");
require("./node_modules/meteor/rocketchat:message-snippet/server/publications/snippetedMessagesByRoom.js");
require("./node_modules/meteor/rocketchat:message-snippet/server/publications/snippetedMessage.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:message-snippet'] = {};

})();

//# sourceMappingURL=rocketchat_message-snippet.js.map
