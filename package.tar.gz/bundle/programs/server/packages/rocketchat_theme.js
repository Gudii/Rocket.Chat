(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var Logger = Package['rocketchat:logger'].Logger;
var _ = Package.underscore._;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var WebAppHashing = Package['webapp-hashing'].WebAppHashing;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;

/* Package-scope variables */
var __coffeescriptShare;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/rocketchat_theme/server/server.coffee.js                                                  //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var autoprefixer, calculateClientHash, crypto, less, logger, setctionPerType;                         // 1
                                                                                                      //
less = Npm.require('less');                                                                           // 1
                                                                                                      //
autoprefixer = Npm.require('less-plugin-autoprefix');                                                 // 1
                                                                                                      //
crypto = Npm.require('crypto');                                                                       // 1
                                                                                                      //
logger = new Logger('rocketchat:theme', {                                                             // 1
  methods: {                                                                                          // 6
    stop_rendering: {                                                                                 // 7
      type: 'info'                                                                                    // 8
    }                                                                                                 //
  }                                                                                                   //
});                                                                                                   //
                                                                                                      //
calculateClientHash = WebAppHashing.calculateClientHash;                                              // 1
                                                                                                      //
WebAppHashing.calculateClientHash = function(manifest, includeFilter, runtimeConfigOverride) {        // 1
  var css, hash, themeManifestItem;                                                                   // 13
  css = RocketChat.theme.getCss();                                                                    // 13
  WebAppInternals.staticFiles['/__cordova/theme.css'] = WebAppInternals.staticFiles['/theme.css'] = {
    cacheable: true,                                                                                  // 16
    sourceMapUrl: void 0,                                                                             // 16
    type: 'css',                                                                                      // 16
    content: css                                                                                      // 16
  };                                                                                                  //
  hash = crypto.createHash('sha1').update(css).digest('hex');                                         // 13
  themeManifestItem = _.find(manifest, function(item) {                                               // 13
    return item.path === 'app/theme.css';                                                             // 23
  });                                                                                                 //
  if (themeManifestItem == null) {                                                                    // 24
    themeManifestItem = {};                                                                           // 25
    manifest.push(themeManifestItem);                                                                 // 25
  }                                                                                                   //
  themeManifestItem.path = 'app/theme.css';                                                           // 13
  themeManifestItem.type = 'css';                                                                     // 13
  themeManifestItem.cacheable = true;                                                                 // 13
  themeManifestItem.where = 'client';                                                                 // 13
  themeManifestItem.url = "/theme.css?" + hash;                                                       // 13
  themeManifestItem.size = css.length;                                                                // 13
  themeManifestItem.hash = hash;                                                                      // 13
  return calculateClientHash.call(this, manifest, includeFilter, runtimeConfigOverride);              //
};                                                                                                    // 12
                                                                                                      //
setctionPerType = {                                                                                   // 1
  'color': 'Colors',                                                                                  // 40
  'font': 'Fonts'                                                                                     // 40
};                                                                                                    //
                                                                                                      //
RocketChat.theme = new ((function() {                                                                 // 1
  _Class.prototype.variables = {};                                                                    // 45
                                                                                                      //
  _Class.prototype.packageCallbacks = [];                                                             // 45
                                                                                                      //
  _Class.prototype.files = ['assets/stylesheets/global/_variables.less', 'assets/stylesheets/utils/_keyframes.import.less', 'assets/stylesheets/utils/_lesshat.import.less', 'assets/stylesheets/utils/_preloader.import.less', 'assets/stylesheets/utils/_reset.import.less', 'assets/stylesheets/utils/_chatops.less', 'assets/stylesheets/animation.css', 'assets/stylesheets/base.less', 'assets/stylesheets/fontello.css', 'assets/stylesheets/rtl.less', 'assets/stylesheets/swipebox.min.css', 'assets/stylesheets/utils/_colors.import.less'];
                                                                                                      //
  function _Class() {                                                                                 // 62
    this.customCSS = '';                                                                              // 63
    RocketChat.settings.add('css', '');                                                               // 63
    RocketChat.settings.addGroup('Layout');                                                           // 63
    this.compileDelayed = _.debounce(Meteor.bindEnvironment(this.compile.bind(this)), 300);           // 63
    RocketChat.settings.onload('*', Meteor.bindEnvironment((function(_this) {                         // 63
      return function(key, value, initialLoad) {                                                      //
        var name;                                                                                     // 71
        if (key === 'theme-custom-css') {                                                             // 71
          if ((value != null ? value.trim() : void 0) !== '') {                                       // 72
            _this.customCSS = value;                                                                  // 73
          }                                                                                           //
        } else if (/^theme-.+/.test(key) === true) {                                                  //
          name = key.replace(/^theme-[a-z]+-/, '');                                                   // 75
          if (_this.variables[name] != null) {                                                        // 76
            _this.variables[name].value = value;                                                      // 77
          }                                                                                           //
        } else {                                                                                      //
          return;                                                                                     // 79
        }                                                                                             //
        return _this.compileDelayed();                                                                //
      };                                                                                              //
    })(this)));                                                                                       //
  }                                                                                                   //
                                                                                                      //
  _Class.prototype.compile = function() {                                                             // 45
    var content, file, i, j, len, len1, options, packageCallback, ref, ref1, result, start;           // 84
    content = [this.getVariablesAsLess()];                                                            // 84
    ref = this.files;                                                                                 // 88
    for (i = 0, len = ref.length; i < len; i++) {                                                     // 88
      file = ref[i];                                                                                  //
      content.push(Assets.getText(file));                                                             // 88
    }                                                                                                 // 88
    ref1 = this.packageCallbacks;                                                                     // 90
    for (j = 0, len1 = ref1.length; j < len1; j++) {                                                  // 90
      packageCallback = ref1[j];                                                                      //
      result = packageCallback();                                                                     // 91
      if (_.isString(result)) {                                                                       // 92
        content.push(result);                                                                         // 93
      }                                                                                               //
    }                                                                                                 // 90
    content.push(this.customCSS);                                                                     // 84
    content = content.join('\n');                                                                     // 84
    options = {                                                                                       // 84
      compress: true,                                                                                 // 100
      plugins: [new autoprefixer()]                                                                   // 100
    };                                                                                                //
    start = Date.now();                                                                               // 84
    return less.render(content, options, function(err, data) {                                        //
      logger.stop_rendering(Date.now() - start);                                                      // 107
      if (err != null) {                                                                              // 108
        return console.log(err);                                                                      // 109
      }                                                                                               //
      RocketChat.settings.updateById('css', data.css);                                                // 107
      return process.emit('message', {                                                                //
        refresh: 'client'                                                                             // 113
      });                                                                                             //
    });                                                                                               //
  };                                                                                                  //
                                                                                                      //
  _Class.prototype.addVariable = function(type, name, value, persist) {                               // 45
    var config;                                                                                       // 116
    if (persist == null) {                                                                            //
      persist = true;                                                                                 //
    }                                                                                                 //
    this.variables[name] = {                                                                          // 116
      type: type,                                                                                     // 117
      value: value                                                                                    // 117
    };                                                                                                //
    if (persist === true) {                                                                           // 120
      config = {                                                                                      // 121
        group: 'Layout',                                                                              // 122
        type: type,                                                                                   // 122
        section: setctionPerType[type],                                                               // 122
        "public": false                                                                               // 122
      };                                                                                              //
      return RocketChat.settings.add("theme-" + type + "-" + name, value, config);                    //
    }                                                                                                 //
  };                                                                                                  //
                                                                                                      //
  _Class.prototype.addPublicColor = function(name, value) {                                           // 45
    return this.addVariable('color', name, value, true);                                              //
  };                                                                                                  //
                                                                                                      //
  _Class.prototype.addPublicFont = function(name, value) {                                            // 45
    return this.addVariable('font', name, value, true);                                               //
  };                                                                                                  //
                                                                                                      //
  _Class.prototype.getVariablesAsObject = function() {                                                // 45
    var name, obj, ref, variable;                                                                     // 136
    obj = {};                                                                                         // 136
    ref = this.variables;                                                                             // 137
    for (name in ref) {                                                                               // 137
      variable = ref[name];                                                                           //
      obj[name] = variable.value;                                                                     // 138
    }                                                                                                 // 137
    return obj;                                                                                       // 140
  };                                                                                                  //
                                                                                                      //
  _Class.prototype.getVariablesAsLess = function() {                                                  // 45
    var items, name, ref, variable;                                                                   // 143
    items = [];                                                                                       // 143
    ref = this.variables;                                                                             // 144
    for (name in ref) {                                                                               // 144
      variable = ref[name];                                                                           //
      items.push("@" + name + ": " + variable.value + ";");                                           // 145
    }                                                                                                 // 144
    return items.join('\n');                                                                          // 147
  };                                                                                                  //
                                                                                                      //
  _Class.prototype.addPackageAsset = function(cb) {                                                   // 45
    this.packageCallbacks.push(cb);                                                                   // 150
    return this.compileDelayed();                                                                     //
  };                                                                                                  //
                                                                                                      //
  _Class.prototype.getCss = function() {                                                              // 45
    return RocketChat.settings.get('css');                                                            // 154
  };                                                                                                  //
                                                                                                      //
  return _Class;                                                                                      //
                                                                                                      //
})());                                                                                                //
                                                                                                      //
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/rocketchat_theme/server/variables.coffee.js                                               //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat.theme.addPublicColor("primary-background-color", "#04436a");                               // 1
                                                                                                      //
RocketChat.theme.addPublicColor("primary-font-color", "#444444");                                     // 1
                                                                                                      //
RocketChat.theme.addPublicColor("secondary-background-color", "#f4f4f4");                             // 1
                                                                                                      //
RocketChat.theme.addPublicColor("secondary-font-color", "#7f7f7f");                                   // 1
                                                                                                      //
RocketChat.theme.addPublicColor("tertiary-background-color", "#eaeaea");                              // 1
                                                                                                      //
RocketChat.theme.addPublicColor("tertiary-font-color", "rgba(255, 255, 255, 0.6)");                   // 1
                                                                                                      //
RocketChat.theme.addPublicColor("quaternary-font-color", "#ffffff");                                  // 1
                                                                                                      //
RocketChat.theme.addPublicColor("action-buttons-color", "#13679a");                                   // 1
                                                                                                      //
RocketChat.theme.addPublicColor("active-channel-background-color", "rgba(255, 255, 255, 0.075)");     // 1
                                                                                                      //
RocketChat.theme.addPublicColor("active-channel-font-color", "rgba(255, 255, 255, 0.75)");            // 1
                                                                                                      //
RocketChat.theme.addPublicColor("blockquote-background", "#cccccc");                                  // 1
                                                                                                      //
RocketChat.theme.addPublicColor("clean-buttons-color", "rgba(0, 0, 0, 0.25)");                        // 1
                                                                                                      //
RocketChat.theme.addPublicColor("code-background", "#f8f8f8");                                        // 1
                                                                                                      //
RocketChat.theme.addPublicColor("code-border", "#cccccc");                                            // 1
                                                                                                      //
RocketChat.theme.addPublicColor("code-color", "#333333");                                             // 1
                                                                                                      //
RocketChat.theme.addPublicColor("content-background-color", "#ffffff");                               // 1
                                                                                                      //
RocketChat.theme.addPublicColor("custom-scrollbar-color", "rgba(255, 255, 255, 0.05)");               // 1
                                                                                                      //
RocketChat.theme.addPublicColor("info-active-font-color", "#ff0000");                                 // 1
                                                                                                      //
RocketChat.theme.addPublicColor("info-font-color", "#aaaaaa");                                        // 1
                                                                                                      //
RocketChat.theme.addPublicColor("input-font-color", "rgba(255, 255, 255, 0.85)");                     // 1
                                                                                                      //
RocketChat.theme.addPublicColor("link-font-color", "#008ce3");                                        // 1
                                                                                                      //
RocketChat.theme.addPublicColor("message-hover-background-color", "rgba(0, 0, 0, 0.025)");            // 1
                                                                                                      //
RocketChat.theme.addPublicColor("smallprint-font-color", "#c2e7ff");                                  // 1
                                                                                                      //
RocketChat.theme.addPublicColor("smallprint-hover-color", "#ffffff");                                 // 1
                                                                                                      //
RocketChat.theme.addPublicColor("status-away", "#fcb316");                                            // 1
                                                                                                      //
RocketChat.theme.addPublicColor("status-busy", "#d30230");                                            // 1
                                                                                                      //
RocketChat.theme.addPublicColor("status-offline", "rgba(150, 150, 150, 0.50)");                       // 1
                                                                                                      //
RocketChat.theme.addPublicColor("status-online", "#72ff52");                                          // 1
                                                                                                      //
RocketChat.theme.addPublicColor("unread-notification-color", "#1dce73");                              // 1
                                                                                                      //
RocketChat.theme.addPublicFont("body-font-family", '-apple-system, BlinkMacSystemFont, Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI", "Segoe UI Emoji", "Segoe UI Symbol", "Meiryo UI"');
                                                                                                      //
RocketChat.settings.add("theme-custom-css", '', {                                                     // 1
  group: 'Layout',                                                                                    // 36
  type: 'code',                                                                                       // 36
  code: 'text/x-less',                                                                                // 36
  multiline: true,                                                                                    // 36
  section: 'Custom CSS',                                                                              // 36
  "public": false                                                                                     // 36
});                                                                                                   //
                                                                                                      //
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:theme'] = {};

})();

//# sourceMappingURL=rocketchat_theme.js.map
