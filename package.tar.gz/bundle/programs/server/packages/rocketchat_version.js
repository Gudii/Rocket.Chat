(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:version'] = {};

})();

//# sourceMappingURL=rocketchat_version.js.map
