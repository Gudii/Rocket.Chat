(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var ECMAScript = Package.ecmascript.ECMAScript;
var RoutePolicy = Package.routepolicy.RoutePolicy;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var _ = Package.underscore._;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
var HTTP = Package.http.HTTP;
var HTTPInternals = Package.http.HTTPInternals;
var Accounts = Package['accounts-base'].Accounts;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var SAML, __coffeescriptShare;

var require = meteorInstall({"node_modules":{"meteor":{"steffo:meteor-accounts-saml":{"saml_server.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/steffo_meteor-accounts-saml/saml_server.js                                                            //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/* globals RoutePolicy, SAML */                                                                                   // 1
/* jshint newcap: false */                                                                                        // 2
                                                                                                                  //
if (!Accounts.saml) {                                                                                             // 4
	Accounts.saml = {                                                                                                // 5
		settings: {                                                                                                     // 6
			debug: true,                                                                                                   // 7
			generateUsername: false,                                                                                       // 8
			providers: []                                                                                                  // 9
		}                                                                                                               // 6
	};                                                                                                               // 5
}                                                                                                                 // 12
                                                                                                                  //
var fiber = Npm.require('fibers');                                                                                // 14
var connect = Npm.require('connect');                                                                             // 15
RoutePolicy.declare('/_saml/', 'network');                                                                        // 16
                                                                                                                  //
Meteor.methods({                                                                                                  // 18
	samlLogout: function () {                                                                                        // 19
		function samlLogout(provider) {                                                                                 // 19
			// Make sure the user is logged in before initiate SAML SLO                                                    // 20
			if (!Meteor.userId()) {                                                                                        // 21
				throw new Meteor.Error('error-invalid-user', 'Invalid user', { method: 'samlLogout' });                       // 22
			}                                                                                                              // 23
			var samlProvider = function () {                                                                               // 24
				function samlProvider(element) {                                                                              // 24
					return element.provider === provider;                                                                        // 25
				}                                                                                                             // 26
                                                                                                                  //
				return samlProvider;                                                                                          // 24
			}();                                                                                                           // 24
			var providerConfig = Accounts.saml.settings.providers.filter(samlProvider)[0];                                 // 27
                                                                                                                  //
			if (Accounts.saml.settings.debug) {                                                                            // 29
				console.log('Logout request from ' + JSON.stringify(providerConfig));                                         // 30
			}                                                                                                              // 31
			// This query should respect upcoming array of SAML logins                                                     // 32
			var user = Meteor.users.findOne({                                                                              // 33
				_id: Meteor.userId(),                                                                                         // 34
				'services.saml.provider': provider                                                                            // 35
			}, {                                                                                                           // 33
				'services.saml': 1                                                                                            // 37
			});                                                                                                            // 36
			var nameID = user.services.saml.nameID;                                                                        // 39
			var sessionIndex = user.services.saml.idpSession;                                                              // 40
			nameID = sessionIndex;                                                                                         // 41
			if (Accounts.saml.settings.debug) {                                                                            // 42
				console.log('NameID for user ' + Meteor.userId() + ' found: ' + JSON.stringify(nameID));                      // 43
			}                                                                                                              // 44
                                                                                                                  //
			var _saml = new SAML(providerConfig);                                                                          // 46
                                                                                                                  //
			var request = _saml.generateLogoutRequest({                                                                    // 48
				nameID: nameID,                                                                                               // 49
				sessionIndex: sessionIndex                                                                                    // 50
			});                                                                                                            // 48
                                                                                                                  //
			// request.request: actual XML SAML Request                                                                    // 53
			// request.id: comminucation id which will be mentioned in the ResponseTo field of SAMLResponse                // 54
                                                                                                                  //
			Meteor.users.update({                                                                                          // 56
				_id: Meteor.userId()                                                                                          // 57
			}, {                                                                                                           // 56
				$set: {                                                                                                       // 59
					'services.saml.inResponseTo': request.id                                                                     // 60
				}                                                                                                             // 59
			});                                                                                                            // 58
                                                                                                                  //
			var _syncRequestToUrl = Meteor.wrapAsync(_saml.requestToUrl, _saml);                                           // 64
			var result = _syncRequestToUrl(request.request, 'logout');                                                     // 65
			if (Accounts.saml.settings.debug) {                                                                            // 66
				console.log('SAML Logout Request ' + result);                                                                 // 67
			}                                                                                                              // 68
                                                                                                                  //
			return result;                                                                                                 // 71
		}                                                                                                               // 72
                                                                                                                  //
		return samlLogout;                                                                                              // 19
	}()                                                                                                              // 19
});                                                                                                               // 18
                                                                                                                  //
Accounts.registerLoginHandler(function (loginRequest) {                                                           // 75
	if (!loginRequest.saml || !loginRequest.credentialToken) {                                                       // 76
		return undefined;                                                                                               // 77
	}                                                                                                                // 78
                                                                                                                  //
	var loginResult = Accounts.saml.retrieveCredential(loginRequest.credentialToken);                                // 80
	if (Accounts.saml.settings.debug) {                                                                              // 81
		console.log('RESULT :' + JSON.stringify(loginResult));                                                          // 82
	}                                                                                                                // 83
                                                                                                                  //
	if (loginResult === undefined) {                                                                                 // 85
		return {                                                                                                        // 86
			type: 'saml',                                                                                                  // 87
			error: new Meteor.Error(Accounts.LoginCancelledError.numericError, 'No matching login attempt found')          // 88
		};                                                                                                              // 86
	}                                                                                                                // 90
                                                                                                                  //
	if (loginResult && loginResult.profile && loginResult.profile.email) {                                           // 92
		var user = Meteor.users.findOne({                                                                               // 93
			'emails.address': loginResult.profile.email                                                                    // 94
		});                                                                                                             // 93
                                                                                                                  //
		if (!user) {                                                                                                    // 97
			var newUser = {                                                                                                // 98
				name: loginResult.profile.cn || loginResult.profile.username,                                                 // 99
				active: true,                                                                                                 // 100
				globalRoles: ['user'],                                                                                        // 101
				emails: [{                                                                                                    // 102
					address: loginResult.profile.email,                                                                          // 103
					verified: true                                                                                               // 104
				}]                                                                                                            // 102
			};                                                                                                             // 98
                                                                                                                  //
			if (Accounts.saml.settings.generateUsername === true) {                                                        // 108
				var username = RocketChat.generateUsernameSuggestion(newUser);                                                // 109
				if (username) {                                                                                               // 110
					newUser.username = username;                                                                                 // 111
				}                                                                                                             // 112
			} else if (loginResult.profile.username) {                                                                     // 113
				newUser.username = loginResult.profile.username;                                                              // 114
			}                                                                                                              // 115
                                                                                                                  //
			var userId = Accounts.insertUserDoc({}, newUser);                                                              // 117
			user = Meteor.users.findOne(userId);                                                                           // 118
		}                                                                                                               // 119
                                                                                                                  //
		//creating the token and adding to the user                                                                     // 121
		var stampedToken = Accounts._generateStampedLoginToken();                                                       // 122
		Meteor.users.update(user, {                                                                                     // 123
			$push: {                                                                                                       // 124
				'services.resume.loginTokens': stampedToken                                                                   // 125
			}                                                                                                              // 124
		});                                                                                                             // 123
                                                                                                                  //
		var samlLogin = {                                                                                               // 129
			provider: Accounts.saml.RelayState,                                                                            // 130
			idp: loginResult.profile.issuer,                                                                               // 131
			idpSession: loginResult.profile.sessionIndex,                                                                  // 132
			nameID: loginResult.profile.nameID                                                                             // 133
		};                                                                                                              // 129
                                                                                                                  //
		Meteor.users.update({                                                                                           // 136
			_id: user._id                                                                                                  // 137
		}, {                                                                                                            // 136
			$set: {                                                                                                        // 139
				// TBD this should be pushed, otherwise we're only able to SSO into a single IDP at a time                    // 140
				'services.saml': samlLogin                                                                                    // 141
			}                                                                                                              // 139
		});                                                                                                             // 138
                                                                                                                  //
		//sending token along with the userId                                                                           // 145
		var result = {                                                                                                  // 146
			userId: user._id,                                                                                              // 147
			token: stampedToken.token                                                                                      // 148
		};                                                                                                              // 146
                                                                                                                  //
		return result;                                                                                                  // 151
	} else {                                                                                                         // 153
		throw new Error('SAML Profile did not contain an email address');                                               // 154
	}                                                                                                                // 155
});                                                                                                               // 156
                                                                                                                  //
Accounts.saml._loginResultForCredentialToken = {};                                                                // 158
                                                                                                                  //
Accounts.saml.hasCredential = function (credentialToken) {                                                        // 160
	return _.has(Accounts.saml._loginResultForCredentialToken, credentialToken);                                     // 161
};                                                                                                                // 162
                                                                                                                  //
Accounts.saml.retrieveCredential = function (credentialToken) {                                                   // 164
	// The credentialToken in all these functions corresponds to SAMLs inResponseTo field and is mandatory to check.
	var result = Accounts.saml._loginResultForCredentialToken[credentialToken];                                      // 166
	delete Accounts.saml._loginResultForCredentialToken[credentialToken];                                            // 167
	return result;                                                                                                   // 168
};                                                                                                                // 169
                                                                                                                  //
var closePopup = function closePopup(res, err) {                                                                  // 171
	res.writeHead(200, {                                                                                             // 172
		'Content-Type': 'text/html'                                                                                     // 173
	});                                                                                                              // 172
	var content = '<html><head><script>window.close()</script></head><body><H1>Verified</H1></body></html>';         // 175
	if (err) {                                                                                                       // 176
		content = '<html><body><h2>Sorry, an annoying error occured</h2><div>' + err + '</div><a onclick="window.close();">Close Window</a></body></html>';
	}                                                                                                                // 178
	res.end(content, 'utf-8');                                                                                       // 179
};                                                                                                                // 180
                                                                                                                  //
var samlUrlToObject = function samlUrlToObject(url) {                                                             // 182
	// req.url will be '/_saml/<action>/<service name>/<credentialToken>'                                            // 183
	if (!url) {                                                                                                      // 184
		return null;                                                                                                    // 185
	}                                                                                                                // 186
                                                                                                                  //
	var splitPath = url.split('/');                                                                                  // 188
                                                                                                                  //
	// Any non-saml request will continue down the default                                                           // 190
	// middlewares.                                                                                                  // 191
	if (splitPath[1] !== '_saml') {                                                                                  // 192
		return null;                                                                                                    // 193
	}                                                                                                                // 194
                                                                                                                  //
	var result = {                                                                                                   // 196
		actionName: splitPath[2],                                                                                       // 197
		serviceName: splitPath[3],                                                                                      // 198
		credentialToken: splitPath[4]                                                                                   // 199
	};                                                                                                               // 196
	if (Accounts.saml.settings.debug) {                                                                              // 201
		console.log(result);                                                                                            // 202
	}                                                                                                                // 203
	return result;                                                                                                   // 204
};                                                                                                                // 205
                                                                                                                  //
var middleware = function middleware(req, res, next) {                                                            // 207
	// Make sure to catch any exceptions because otherwise we'd crash                                                // 208
	// the runner                                                                                                    // 209
	try {                                                                                                            // 210
		var samlObject = samlUrlToObject(req.url);                                                                      // 211
		if (!samlObject || !samlObject.serviceName) {                                                                   // 212
			next();                                                                                                        // 213
			return;                                                                                                        // 214
		}                                                                                                               // 215
                                                                                                                  //
		if (!samlObject.actionName) {                                                                                   // 217
			throw new Error('Missing SAML action');                                                                        // 218
		}                                                                                                               // 219
                                                                                                                  //
		console.log(Accounts.saml.settings.providers);                                                                  // 221
		console.log(samlObject.serviceName);                                                                            // 222
		var service = _.find(Accounts.saml.settings.providers, function (samlSetting) {                                 // 223
			return samlSetting.provider === samlObject.serviceName;                                                        // 224
		});                                                                                                             // 225
                                                                                                                  //
		// Skip everything if there's no service set by the saml middleware                                             // 227
		if (!service) {                                                                                                 // 228
			throw new Error('Unexpected SAML service ' + samlObject.serviceName);                                          // 229
		}                                                                                                               // 230
		var _saml;                                                                                                      // 231
		switch (samlObject.actionName) {                                                                                // 232
			case 'metadata':                                                                                               // 233
				_saml = new SAML(service);                                                                                    // 234
				service.callbackUrl = Meteor.absoluteUrl('_saml/validate/' + service.provider);                               // 235
				res.writeHead(200);                                                                                           // 236
				res.write(_saml.generateServiceProviderMetadata(service.callbackUrl));                                        // 237
				res.end();                                                                                                    // 238
				//closePopup(res);                                                                                            // 239
				break;                                                                                                        // 240
			case 'logout':                                                                                                 // 241
				// This is where we receive SAML LogoutResponse                                                               // 242
				_saml = new SAML(service);                                                                                    // 243
				_saml.validateLogoutResponse(req.query.SAMLResponse, function (err, result) {                                 // 244
					if (!err) {                                                                                                  // 245
						var logOutUser = function logOutUser(inResponseTo) {                                                        // 246
							if (Accounts.saml.settings.debug) {                                                                        // 247
								console.log('Logging Out user via inResponseTo ' + inResponseTo);                                         // 248
							}                                                                                                          // 249
							var loggedOutUser = Meteor.users.find({                                                                    // 250
								'services.saml.inResponseTo': inResponseTo                                                                // 251
							}).fetch();                                                                                                // 250
							if (loggedOutUser.length === 1) {                                                                          // 253
								if (Accounts.saml.settings.debug) {                                                                       // 254
									console.log('Found user ' + loggedOutUser[0]._id);                                                       // 255
								}                                                                                                         // 256
								Meteor.users.update({                                                                                     // 257
									_id: loggedOutUser[0]._id                                                                                // 258
								}, {                                                                                                      // 257
									$set: {                                                                                                  // 260
										'services.resume.loginTokens': []                                                                       // 261
									}                                                                                                        // 260
								});                                                                                                       // 259
								Meteor.users.update({                                                                                     // 264
									_id: loggedOutUser[0]._id                                                                                // 265
								}, {                                                                                                      // 264
									$unset: {                                                                                                // 267
										'services.saml': ''                                                                                     // 268
									}                                                                                                        // 267
								});                                                                                                       // 266
							} else {                                                                                                   // 271
								throw new Meteor.Error('Found multiple users matching SAML inResponseTo fields');                         // 272
							}                                                                                                          // 273
						};                                                                                                          // 274
                                                                                                                  //
						fiber(function () {                                                                                         // 276
							logOutUser(result);                                                                                        // 277
						}).run();                                                                                                   // 278
                                                                                                                  //
						res.writeHead(302, {                                                                                        // 281
							'Location': req.query.RelayState                                                                           // 282
						});                                                                                                         // 281
						res.end();                                                                                                  // 284
					}                                                                                                            // 285
					//  else {                                                                                                   // 286
					// 	// TBD thinking of sth meaning full.                                                                     // 287
					// }                                                                                                         // 288
				});                                                                                                           // 289
				break;                                                                                                        // 290
			case 'sloRedirect':                                                                                            // 291
				var idpLogout = req.query.redirect;                                                                           // 292
				res.writeHead(302, {                                                                                          // 293
					// credentialToken here is the SAML LogOut Request that we'll send back to IDP                               // 294
					'Location': idpLogout                                                                                        // 295
				});                                                                                                           // 293
				res.end();                                                                                                    // 297
				break;                                                                                                        // 298
			case 'authorize':                                                                                              // 299
				service.callbackUrl = Meteor.absoluteUrl('_saml/validate/' + service.provider);                               // 300
				service.id = samlObject.credentialToken;                                                                      // 301
				_saml = new SAML(service);                                                                                    // 302
				_saml.getAuthorizeUrl(req, function (err, url) {                                                              // 303
					if (err) {                                                                                                   // 304
						throw new Error('Unable to generate authorize url');                                                        // 305
					}                                                                                                            // 306
					res.writeHead(302, {                                                                                         // 307
						'Location': url                                                                                             // 308
					});                                                                                                          // 307
					res.end();                                                                                                   // 310
				});                                                                                                           // 311
				break;                                                                                                        // 312
			case 'validate':                                                                                               // 313
				_saml = new SAML(service);                                                                                    // 314
				Accounts.saml.RelayState = req.body.RelayState;                                                               // 315
				_saml.validateResponse(req.body.SAMLResponse, req.body.RelayState, function (err, profile /*, loggedOut*/) {  // 316
					if (err) {                                                                                                   // 317
						throw new Error('Unable to validate response url: ' + err);                                                 // 318
					}                                                                                                            // 319
                                                                                                                  //
					var credentialToken = profile.inResponseToId || profile.InResponseTo || samlObject.credentialToken;          // 321
					if (!credentialToken) {                                                                                      // 322
						throw new Error('Unable to determine credentialToken');                                                     // 323
					}                                                                                                            // 324
					Accounts.saml._loginResultForCredentialToken[credentialToken] = {                                            // 325
						profile: profile                                                                                            // 326
					};                                                                                                           // 325
					closePopup(res);                                                                                             // 328
				});                                                                                                           // 329
				break;                                                                                                        // 330
			default:                                                                                                       // 331
				throw new Error('Unexpected SAML action ' + samlObject.actionName);                                           // 332
                                                                                                                  //
		}                                                                                                               // 232
	} catch (err) {                                                                                                  // 335
		closePopup(res, err);                                                                                           // 336
	}                                                                                                                // 337
};                                                                                                                // 338
                                                                                                                  //
// Listen to incoming SAML http requests                                                                          // 340
WebApp.connectHandlers.use(connect.bodyParser()).use(function (req, res, next) {                                  // 341
	// Need to create a fiber since we're using synchronous http calls and nothing                                   // 342
	// else is wrapping this in a fiber automatically                                                                // 343
	fiber(function () {                                                                                              // 344
		middleware(req, res, next);                                                                                     // 345
	}).run();                                                                                                        // 346
});                                                                                                               // 347
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"saml_utils.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/steffo_meteor-accounts-saml/saml_utils.js                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/* globals SAML:true */                                                                                           // 1
                                                                                                                  //
var zlib = Npm.require('zlib');                                                                                   // 3
var xml2js = Npm.require('xml2js');                                                                               // 4
var xmlCrypto = Npm.require('xml-crypto');                                                                        // 5
var crypto = Npm.require('crypto');                                                                               // 6
var xmldom = Npm.require('xmldom');                                                                               // 7
var querystring = Npm.require('querystring');                                                                     // 8
var xmlbuilder = Npm.require('xmlbuilder');                                                                       // 9
// var xmlenc = Npm.require('xml-encryption');                                                                    // 10
// var xpath = xmlCrypto.xpath;                                                                                   // 11
// var Dom = xmldom.DOMParser;                                                                                    // 12
                                                                                                                  //
// var prefixMatch = new RegExp(/(?!xmlns)^.*:/);                                                                 // 14
                                                                                                                  //
                                                                                                                  //
SAML = function SAML(options) {                                                                                   // 17
	this.options = this.initialize(options);                                                                         // 18
};                                                                                                                // 19
                                                                                                                  //
// var stripPrefix = function(str) {                                                                              // 21
// 	return str.replace(prefixMatch, '');                                                                          // 22
// };                                                                                                             // 23
                                                                                                                  //
SAML.prototype.initialize = function (options) {                                                                  // 25
	if (!options) {                                                                                                  // 26
		options = {};                                                                                                   // 27
	}                                                                                                                // 28
                                                                                                                  //
	if (!options.protocol) {                                                                                         // 30
		options.protocol = 'https://';                                                                                  // 31
	}                                                                                                                // 32
                                                                                                                  //
	if (!options.path) {                                                                                             // 34
		options.path = '/saml/consume';                                                                                 // 35
	}                                                                                                                // 36
                                                                                                                  //
	if (!options.issuer) {                                                                                           // 38
		options.issuer = 'onelogin_saml';                                                                               // 39
	}                                                                                                                // 40
                                                                                                                  //
	if (options.identifierFormat === undefined) {                                                                    // 42
		options.identifierFormat = 'urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress';                            // 43
	}                                                                                                                // 44
                                                                                                                  //
	if (options.authnContext === undefined) {                                                                        // 46
		options.authnContext = 'urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport';                     // 47
	}                                                                                                                // 48
                                                                                                                  //
	return options;                                                                                                  // 50
};                                                                                                                // 51
                                                                                                                  //
SAML.prototype.generateUniqueID = function () {                                                                   // 53
	var chars = 'abcdef0123456789';                                                                                  // 54
	var uniqueID = '';                                                                                               // 55
	for (var i = 0; i < 20; i++) {                                                                                   // 56
		uniqueID += chars.substr(Math.floor(Math.random() * 15), 1);                                                    // 57
	}                                                                                                                // 58
	return uniqueID;                                                                                                 // 59
};                                                                                                                // 60
                                                                                                                  //
SAML.prototype.generateInstant = function () {                                                                    // 62
	return new Date().toISOString();                                                                                 // 63
};                                                                                                                // 64
                                                                                                                  //
SAML.prototype.signRequest = function (xml) {                                                                     // 66
	var signer = crypto.createSign('RSA-SHA1');                                                                      // 67
	signer.update(xml);                                                                                              // 68
	return signer.sign(this.options.privateKey, 'base64');                                                           // 69
};                                                                                                                // 70
                                                                                                                  //
SAML.prototype.generateAuthorizeRequest = function (req) {                                                        // 72
	var id = '_' + this.generateUniqueID();                                                                          // 73
	var instant = this.generateInstant();                                                                            // 74
                                                                                                                  //
	// Post-auth destination                                                                                         // 76
	var callbackUrl;                                                                                                 // 77
	if (this.options.callbackUrl) {                                                                                  // 78
		callbackUrl = this.options.callbackUrl;                                                                         // 79
	} else {                                                                                                         // 80
		callbackUrl = this.options.protocol + req.headers.host + this.options.path;                                     // 81
	}                                                                                                                // 82
                                                                                                                  //
	if (this.options.id) {                                                                                           // 84
		id = this.options.id;                                                                                           // 85
	}                                                                                                                // 86
                                                                                                                  //
	var request = '<samlp:AuthnRequest xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol" ID="' + id + '" Version="2.0" IssueInstant="' + instant + '" ProtocolBinding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST" AssertionConsumerServiceURL="' + callbackUrl + '" Destination="' + this.options.entryPoint + '">' + '<saml:Issuer xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion">' + this.options.issuer + '</saml:Issuer>\n';
                                                                                                                  //
	if (this.options.identifierFormat) {                                                                             // 94
		request += '<samlp:NameIDPolicy xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol" Format="' + this.options.identifierFormat + '" AllowCreate="true"></samlp:NameIDPolicy>\n';
	}                                                                                                                // 97
                                                                                                                  //
	request += '<samlp:RequestedAuthnContext xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol" Comparison="exact">' + '<saml:AuthnContextClassRef xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion">urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport</saml:AuthnContextClassRef></samlp:RequestedAuthnContext>\n' + '</samlp:AuthnRequest>';
                                                                                                                  //
	return request;                                                                                                  // 104
};                                                                                                                // 105
                                                                                                                  //
SAML.prototype.generateLogoutRequest = function (options) {                                                       // 107
	// options should be of the form                                                                                 // 108
	// nameId: <nameId as submitted during SAML SSO>                                                                 // 109
	// sessionIndex: sessionIndex                                                                                    // 110
	// --- NO SAMLsettings: <Meteor.setting.saml  entry for the provider you want to SLO from                        // 111
                                                                                                                  //
	var id = '_' + this.generateUniqueID();                                                                          // 113
	var instant = this.generateInstant();                                                                            // 114
                                                                                                                  //
	var request = '<samlp:LogoutRequest xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol" ' + 'xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion" ID="' + id + '" Version="2.0" IssueInstant="' + instant + '" Destination="' + this.options.idpSLORedirectURL + '">' + '<saml:Issuer xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion">' + this.options.issuer + '</saml:Issuer>' + '<saml:NameID Format="' + this.options.identifierFormat + '">' + options.nameID + '</saml:NameID>' + '</samlp:LogoutRequest>';
                                                                                                                  //
	request = '<samlp:LogoutRequest xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol"  ' + 'ID="' + id + '" ' + 'Version="2.0" ' + 'IssueInstant="' + instant + '" ' + 'Destination="' + this.options.idpSLORedirectURL + '" ' + '>' + '<saml:Issuer xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion">' + this.options.issuer + '</saml:Issuer>' + '<saml:NameID xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion" ' + 'NameQualifier="http://id.init8.net:8080/openam" ' + 'SPNameQualifier="' + this.options.issuer + '" ' + 'Format="' + this.options.identifierFormat + '">' + options.nameID + '</saml:NameID>' + '<samlp:SessionIndex xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol">' + options.sessionIndex + '</samlp:SessionIndex>' + '</samlp:LogoutRequest>';
	if (Meteor.settings.debug) {                                                                                     // 137
		console.log('------- SAML Logout request -----------');                                                         // 138
		console.log(request);                                                                                           // 139
	}                                                                                                                // 140
	return {                                                                                                         // 141
		request: request,                                                                                               // 142
		id: id                                                                                                          // 143
	};                                                                                                               // 141
};                                                                                                                // 145
                                                                                                                  //
SAML.prototype.requestToUrl = function (request, operation, callback) {                                           // 147
	var self = this;                                                                                                 // 148
	zlib.deflateRaw(request, function (err, buffer) {                                                                // 149
		if (err) {                                                                                                      // 150
			return callback(err);                                                                                          // 151
		}                                                                                                               // 152
                                                                                                                  //
		var base64 = buffer.toString('base64');                                                                         // 154
		var target = self.options.entryPoint;                                                                           // 155
                                                                                                                  //
		if (operation === 'logout') {                                                                                   // 157
			if (self.options.idpSLORedirectURL) {                                                                          // 158
				target = self.options.idpSLORedirectURL;                                                                      // 159
			}                                                                                                              // 160
		}                                                                                                               // 161
                                                                                                                  //
		if (target.indexOf('?') > 0) {                                                                                  // 163
			target += '&';                                                                                                 // 164
		} else {                                                                                                        // 165
			target += '?';                                                                                                 // 166
		}                                                                                                               // 167
                                                                                                                  //
		var samlRequest = {                                                                                             // 169
			SAMLRequest: base64                                                                                            // 170
		};                                                                                                              // 169
                                                                                                                  //
		if (self.options.privateCert) {                                                                                 // 173
			samlRequest.SigAlg = 'http://www.w3.org/2000/09/xmldsig#rsa-sha1';                                             // 174
			samlRequest.Signature = self.signRequest(querystring.stringify(samlRequest));                                  // 175
		}                                                                                                               // 176
                                                                                                                  //
		// TBD. We should really include a proper RelayState here                                                       // 178
		var relayState;                                                                                                 // 179
		if (operation === 'logout') {                                                                                   // 180
			// in case of logout we want to be redirected back to the Meteor app.                                          // 181
			relayState = Meteor.absoluteUrl();                                                                             // 182
		} else {                                                                                                        // 183
			relayState = self.options.provider;                                                                            // 184
		}                                                                                                               // 185
		target += querystring.stringify(samlRequest) + '&RelayState=' + relayState;                                     // 186
                                                                                                                  //
		if (Meteor.settings.debug) {                                                                                    // 188
			console.log('requestToUrl: ' + target);                                                                        // 189
		}                                                                                                               // 190
		if (operation === 'logout') {                                                                                   // 191
			// in case of logout we want to be redirected back to the Meteor app.                                          // 192
			return callback(null, target);                                                                                 // 193
		} else {                                                                                                        // 195
			callback(null, target);                                                                                        // 196
		}                                                                                                               // 197
	});                                                                                                              // 198
};                                                                                                                // 199
                                                                                                                  //
SAML.prototype.getAuthorizeUrl = function (req, callback) {                                                       // 201
	var request = this.generateAuthorizeRequest(req);                                                                // 202
                                                                                                                  //
	this.requestToUrl(request, 'authorize', callback);                                                               // 204
};                                                                                                                // 205
                                                                                                                  //
SAML.prototype.getLogoutUrl = function (req, callback) {                                                          // 207
	var request = this.generateLogoutRequest(req);                                                                   // 208
                                                                                                                  //
	this.requestToUrl(request, 'logout', callback);                                                                  // 210
};                                                                                                                // 211
                                                                                                                  //
SAML.prototype.certToPEM = function (cert) {                                                                      // 213
	cert = cert.match(/.{1,64}/g).join('\n');                                                                        // 214
	cert = '-----BEGIN CERTIFICATE-----\n' + cert;                                                                   // 215
	cert = cert + '\n-----END CERTIFICATE-----\n';                                                                   // 216
	return cert;                                                                                                     // 217
};                                                                                                                // 218
                                                                                                                  //
// functionfindChilds(node, localName, namespace) {                                                               // 220
// 	var res = [];                                                                                                 // 221
// 	for (var i = 0; i < node.childNodes.length; i++) {                                                            // 222
// 		var child = node.childNodes[i];                                                                              // 223
// 		if (child.localName === localName && (child.namespaceURI === namespace || !namespace)) {                     // 224
// 			res.push(child);                                                                                            // 225
// 		}                                                                                                            // 226
// 	}                                                                                                             // 227
// 	return res;                                                                                                   // 228
// }                                                                                                              // 229
                                                                                                                  //
SAML.prototype.validateSignature = function (xml, cert) {                                                         // 231
	var self = this;                                                                                                 // 232
                                                                                                                  //
	var doc = new xmldom.DOMParser().parseFromString(xml);                                                           // 234
	var signature = xmlCrypto.xpath(doc, '//*[local-name(.)=\'Signature\' and namespace-uri(.)=\'http://www.w3.org/2000/09/xmldsig#\']')[0];
                                                                                                                  //
	var sig = new xmlCrypto.SignedXml();                                                                             // 237
                                                                                                                  //
	sig.keyInfoProvider = {                                                                                          // 239
		getKeyInfo: function () {                                                                                       // 240
			function getKeyInfo() /*key*/{                                                                                 // 240
				return '<X509Data></X509Data>';                                                                               // 241
			}                                                                                                              // 242
                                                                                                                  //
			return getKeyInfo;                                                                                             // 240
		}(),                                                                                                            // 240
		getKey: function () {                                                                                           // 243
			function getKey() /*keyInfo*/{                                                                                 // 243
				return self.certToPEM(cert);                                                                                  // 244
			}                                                                                                              // 245
                                                                                                                  //
			return getKey;                                                                                                 // 243
		}()                                                                                                             // 243
	};                                                                                                               // 239
                                                                                                                  //
	sig.loadSignature(signature);                                                                                    // 248
                                                                                                                  //
	return sig.checkSignature(xml);                                                                                  // 250
};                                                                                                                // 251
                                                                                                                  //
SAML.prototype.getElement = function (parentElement, elementName) {                                               // 253
	if (parentElement['saml:' + elementName]) {                                                                      // 254
		return parentElement['saml:' + elementName];                                                                    // 255
	} else if (parentElement['samlp:' + elementName]) {                                                              // 256
		return parentElement['samlp:' + elementName];                                                                   // 257
	} else if (parentElement['saml2p:' + elementName]) {                                                             // 258
		return parentElement['saml2p:' + elementName];                                                                  // 259
	} else if (parentElement['saml2:' + elementName]) {                                                              // 260
		return parentElement['saml2:' + elementName];                                                                   // 261
	}                                                                                                                // 262
	return parentElement[elementName];                                                                               // 263
};                                                                                                                // 264
                                                                                                                  //
SAML.prototype.validateLogoutResponse = function (samlResponse, callback) {                                       // 266
	var self = this;                                                                                                 // 267
                                                                                                                  //
	var compressedSAMLResponse = new Buffer(samlResponse, 'base64');                                                 // 269
	zlib.inflateRaw(compressedSAMLResponse, function (err, decoded) {                                                // 270
                                                                                                                  //
		if (err) {                                                                                                      // 272
			if (Meteor.settings.debug) {                                                                                   // 273
				console.log(err);                                                                                             // 274
			}                                                                                                              // 275
		} else {                                                                                                        // 276
			var parser = new xml2js.Parser({                                                                               // 277
				explicitRoot: true                                                                                            // 278
			});                                                                                                            // 277
			parser.parseString(decoded, function (err, doc) {                                                              // 280
				var response = self.getElement(doc, 'LogoutResponse');                                                        // 281
                                                                                                                  //
				if (response) {                                                                                               // 283
					// TBD. Check if this msg corresponds to one we sent                                                         // 284
					var inResponseTo = response.$.InResponseTo;                                                                  // 285
					if (Meteor.settings.debug) {                                                                                 // 286
						console.log('In Response to: ' + inResponseTo);                                                             // 287
					}                                                                                                            // 288
					var status = self.getElement(response, 'Status');                                                            // 289
					var statusCode = self.getElement(status[0], 'StatusCode')[0].$.Value;                                        // 290
					if (Meteor.settings.debug) {                                                                                 // 291
						console.log('StatusCode: ' + JSON.stringify(statusCode));                                                   // 292
					}                                                                                                            // 293
					if (statusCode === 'urn:oasis:names:tc:SAML:2.0:status:Success') {                                           // 294
						// In case of a successful logout at IDP we return inResponseTo value.                                      // 295
						// This is the only way how we can identify the Meteor user (as we don't use Session Cookies)               // 296
						callback(null, inResponseTo);                                                                               // 297
					} else {                                                                                                     // 298
						callback('Error. Logout not confirmed by IDP', null);                                                       // 299
					}                                                                                                            // 300
				} else {                                                                                                      // 301
					callback('No Response Found', null);                                                                         // 302
				}                                                                                                             // 303
			});                                                                                                            // 304
		}                                                                                                               // 305
	});                                                                                                              // 307
};                                                                                                                // 308
                                                                                                                  //
SAML.prototype.validateResponse = function (samlResponse, relayState, callback) {                                 // 310
	var self = this;                                                                                                 // 311
	var xml = new Buffer(samlResponse, 'base64').toString('utf8');                                                   // 312
	// We currently use RelayState to save SAML provider                                                             // 313
	if (Meteor.settings.debug) {                                                                                     // 314
		console.log('Validating response with relay state: ' + xml);                                                    // 315
	}                                                                                                                // 316
	var parser = new xml2js.Parser({                                                                                 // 317
		explicitRoot: true                                                                                              // 318
	});                                                                                                              // 317
                                                                                                                  //
	parser.parseString(xml, function (err, doc) {                                                                    // 321
		// Verify signature                                                                                             // 322
		if (Meteor.settings.debug) {                                                                                    // 323
			console.log('Verify signature');                                                                               // 324
		}                                                                                                               // 325
		if (self.options.cert && !self.validateSignature(xml, self.options.cert)) {                                     // 326
			if (Meteor.settings.debug) {                                                                                   // 327
				console.log('Signature WRONG');                                                                               // 328
			}                                                                                                              // 329
			return callback(new Error('Invalid signature'), null, false);                                                  // 330
		}                                                                                                               // 331
		if (Meteor.settings.debug) {                                                                                    // 332
			console.log('Signature OK');                                                                                   // 333
		}                                                                                                               // 334
		var response = self.getElement(doc, 'Response');                                                                // 335
		if (Meteor.settings.debug) {                                                                                    // 336
			console.log('Got response');                                                                                   // 337
		}                                                                                                               // 338
		if (response) {                                                                                                 // 339
			var assertion = self.getElement(response, 'Assertion');                                                        // 340
			if (!assertion) {                                                                                              // 341
				return callback(new Error('Missing SAML assertion'), null, false);                                            // 342
			}                                                                                                              // 343
                                                                                                                  //
			var profile = {};                                                                                              // 345
                                                                                                                  //
			if (response.$ && response.$.InResponseTo) {                                                                   // 347
				profile.inResponseToId = response.$.InResponseTo;                                                             // 348
			}                                                                                                              // 349
                                                                                                                  //
			var issuer = self.getElement(assertion[0], 'Issuer');                                                          // 351
			if (issuer) {                                                                                                  // 352
				profile.issuer = issuer[0]._;                                                                                 // 353
			}                                                                                                              // 354
                                                                                                                  //
			var subject = self.getElement(assertion[0], 'Subject');                                                        // 356
                                                                                                                  //
			if (subject) {                                                                                                 // 358
				var nameID = self.getElement(subject[0], 'NameID');                                                           // 359
				if (nameID) {                                                                                                 // 360
					profile.nameID = nameID[0]._;                                                                                // 361
                                                                                                                  //
					if (nameID[0].$.Format) {                                                                                    // 363
						profile.nameIDFormat = nameID[0].$.Format;                                                                  // 364
					}                                                                                                            // 365
				}                                                                                                             // 366
			}                                                                                                              // 367
                                                                                                                  //
			var authnStatement = self.getElement(assertion[0], 'AuthnStatement');                                          // 369
                                                                                                                  //
			if (authnStatement) {                                                                                          // 371
				if (authnStatement[0].$.SessionIndex) {                                                                       // 372
                                                                                                                  //
					profile.sessionIndex = authnStatement[0].$.SessionIndex;                                                     // 374
					if (Meteor.settings.debug) {                                                                                 // 375
						console.log('Session Index: ' + profile.sessionIndex);                                                      // 376
					}                                                                                                            // 377
				} else if (Meteor.settings.debug) {                                                                           // 378
					console.log('No Session Index Found');                                                                       // 379
				}                                                                                                             // 380
			} else if (Meteor.settings.debug) {                                                                            // 383
				console.log('No AuthN Statement found');                                                                      // 384
			}                                                                                                              // 385
                                                                                                                  //
			var attributeStatement = self.getElement(assertion[0], 'AttributeStatement');                                  // 387
			if (attributeStatement) {                                                                                      // 388
				var attributes = self.getElement(attributeStatement[0], 'Attribute');                                         // 389
                                                                                                                  //
				if (attributes) {                                                                                             // 391
					attributes.forEach(function (attribute) {                                                                    // 392
						var value = self.getElement(attribute, 'AttributeValue');                                                   // 393
						if (typeof value[0] === 'string') {                                                                         // 394
							profile[attribute.$.Name] = value[0];                                                                      // 395
						} else {                                                                                                    // 396
							profile[attribute.$.Name] = value[0]._;                                                                    // 397
						}                                                                                                           // 398
					});                                                                                                          // 399
				}                                                                                                             // 400
                                                                                                                  //
				if (!profile.mail && profile['urn:oid:0.9.2342.19200300.100.1.3']) {                                          // 402
					// See http://www.incommonfederation.org/attributesummary.html for definition of attribute OIDs              // 403
					profile.mail = profile['urn:oid:0.9.2342.19200300.100.1.3'];                                                 // 404
				}                                                                                                             // 405
                                                                                                                  //
				if (!profile.email && profile.mail) {                                                                         // 407
					profile.email = profile.mail;                                                                                // 408
				}                                                                                                             // 409
			}                                                                                                              // 410
                                                                                                                  //
			if (!profile.email && profile.nameID && profile.nameIDFormat && profile.nameIDFormat.indexOf('emailAddress') >= 0) {
				profile.email = profile.nameID;                                                                               // 413
			}                                                                                                              // 414
			if (Meteor.settings.debug) {                                                                                   // 415
				console.log('NameID: ' + JSON.stringify(profile));                                                            // 416
			}                                                                                                              // 417
                                                                                                                  //
			callback(null, profile, false);                                                                                // 419
		} else {                                                                                                        // 420
			var logoutResponse = self.getElement(doc, 'LogoutResponse');                                                   // 421
                                                                                                                  //
			if (logoutResponse) {                                                                                          // 423
				callback(null, null, true);                                                                                   // 424
			} else {                                                                                                       // 425
				return callback(new Error('Unknown SAML response message'), null, false);                                     // 426
			}                                                                                                              // 427
		}                                                                                                               // 429
	});                                                                                                              // 430
};                                                                                                                // 431
                                                                                                                  //
var decryptionCert;                                                                                               // 433
SAML.prototype.generateServiceProviderMetadata = function (callbackUrl) {                                         // 434
                                                                                                                  //
	var keyDescriptor = null;                                                                                        // 436
                                                                                                                  //
	if (!decryptionCert) {                                                                                           // 438
		decryptionCert = this.options.privateCert;                                                                      // 439
	}                                                                                                                // 440
                                                                                                                  //
	if (this.options.privateKey) {                                                                                   // 442
		if (!decryptionCert) {                                                                                          // 443
			throw new Error('Missing decryptionCert while generating metadata for decrypting service provider');           // 444
		}                                                                                                               // 446
                                                                                                                  //
		decryptionCert = decryptionCert.replace(/-+BEGIN CERTIFICATE-+\r?\n?/, '');                                     // 448
		decryptionCert = decryptionCert.replace(/-+END CERTIFICATE-+\r?\n?/, '');                                       // 449
		decryptionCert = decryptionCert.replace(/\r\n/g, '\n');                                                         // 450
                                                                                                                  //
		keyDescriptor = {                                                                                               // 452
			'ds:KeyInfo': {                                                                                                // 453
				'ds:X509Data': {                                                                                              // 454
					'ds:X509Certificate': {                                                                                      // 455
						'#text': decryptionCert                                                                                     // 456
					}                                                                                                            // 455
				}                                                                                                             // 454
			},                                                                                                             // 453
			'#list': [                                                                                                     // 460
			// this should be the set that the xmlenc library supports                                                     // 461
			{                                                                                                              // 462
				'EncryptionMethod': {                                                                                         // 463
					'@Algorithm': 'http://www.w3.org/2001/04/xmlenc#aes256-cbc'                                                  // 464
				}                                                                                                             // 463
			}, {                                                                                                           // 462
				'EncryptionMethod': {                                                                                         // 468
					'@Algorithm': 'http://www.w3.org/2001/04/xmlenc#aes128-cbc'                                                  // 469
				}                                                                                                             // 468
			}, {                                                                                                           // 467
				'EncryptionMethod': {                                                                                         // 473
					'@Algorithm': 'http://www.w3.org/2001/04/xmlenc#tripledes-cbc'                                               // 474
				}                                                                                                             // 473
			}]                                                                                                             // 472
		};                                                                                                              // 452
	}                                                                                                                // 479
                                                                                                                  //
	if (!this.options.callbackUrl && !callbackUrl) {                                                                 // 481
		throw new Error('Unable to generate service provider metadata when callbackUrl option is not set');             // 482
	}                                                                                                                // 484
                                                                                                                  //
	var metadata = {                                                                                                 // 486
		'EntityDescriptor': {                                                                                           // 487
			'@xmlns': 'urn:oasis:names:tc:SAML:2.0:metadata',                                                              // 488
			'@xmlns:ds': 'http://www.w3.org/2000/09/xmldsig#',                                                             // 489
			'@entityID': this.options.issuer,                                                                              // 490
			'SPSSODescriptor': {                                                                                           // 491
				'@protocolSupportEnumeration': 'urn:oasis:names:tc:SAML:2.0:protocol',                                        // 492
				'KeyDescriptor': keyDescriptor,                                                                               // 493
				'SingleLogoutService': {                                                                                      // 494
					'@Binding': 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect',                                            // 495
					'@Location': Meteor.absoluteUrl() + '_saml/logout/' + this.options.provider + '/',                           // 496
					'@ResponseLocation': Meteor.absoluteUrl() + '_saml/logout/' + this.options.provider + '/'                    // 497
				},                                                                                                            // 494
				'NameIDFormat': this.options.identifierFormat,                                                                // 499
				'AssertionConsumerService': {                                                                                 // 500
					'@index': '1',                                                                                               // 501
					'@isDefault': 'true',                                                                                        // 502
					'@Binding': 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST',                                                // 503
					'@Location': callbackUrl                                                                                     // 504
				}                                                                                                             // 500
			}                                                                                                              // 491
		}                                                                                                               // 487
	};                                                                                                               // 486
                                                                                                                  //
	return xmlbuilder.create(metadata).end({                                                                         // 510
		pretty: true,                                                                                                   // 511
		indent: '  ',                                                                                                   // 512
		newline: '\n'                                                                                                   // 513
	});                                                                                                              // 510
};                                                                                                                // 515
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"saml_rocketchat.coffee.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/steffo_meteor-accounts-saml/saml_rocketchat.coffee.js                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var logger, timer, updateServices;                                                                                // 1
                                                                                                                  //
logger = new Logger('steffo:meteor-accounts-saml', {                                                              // 1
  methods: {                                                                                                      //
    updated: {                                                                                                    //
      type: 'info'                                                                                                //
    }                                                                                                             //
  }                                                                                                               //
});                                                                                                               //
                                                                                                                  //
RocketChat.settings.addGroup('SAML');                                                                             // 6
                                                                                                                  //
Meteor.methods({                                                                                                  // 7
  addSamlService: function(name) {                                                                                //
    RocketChat.settings.add("SAML_Custom_" + name, false, {                                                       //
      type: 'boolean',                                                                                            //
      group: 'SAML',                                                                                              //
      section: name,                                                                                              //
      i18nLabel: 'Accounts_OAuth_Custom_Enable'                                                                   //
    });                                                                                                           //
    RocketChat.settings.add("SAML_Custom_" + name + "_provider", 'openidp', {                                     //
      type: 'string',                                                                                             //
      group: 'SAML',                                                                                              //
      section: name,                                                                                              //
      i18nLabel: 'SAML_Custom_Provider'                                                                           //
    });                                                                                                           //
    RocketChat.settings.add("SAML_Custom_" + name + "_entry_point", 'https://openidp.feide.no/simplesaml/saml2/idp/SSOService.php', {
      type: 'string',                                                                                             //
      group: 'SAML',                                                                                              //
      section: name,                                                                                              //
      i18nLabel: 'SAML_Custom_Entry_point'                                                                        //
    });                                                                                                           //
    RocketChat.settings.add("SAML_Custom_" + name + "_issuer", 'https://rocket.chat/', {                          //
      type: 'string',                                                                                             //
      group: 'SAML',                                                                                              //
      section: name,                                                                                              //
      i18nLabel: 'SAML_Custom_Issuer'                                                                             //
    });                                                                                                           //
    RocketChat.settings.add("SAML_Custom_" + name + "_cert", '', {                                                //
      type: 'string',                                                                                             //
      group: 'SAML',                                                                                              //
      section: name,                                                                                              //
      i18nLabel: 'SAML_Custom_Cert'                                                                               //
    });                                                                                                           //
    RocketChat.settings.add("SAML_Custom_" + name + "_button_label_text", '', {                                   //
      type: 'string',                                                                                             //
      group: 'SAML',                                                                                              //
      section: name,                                                                                              //
      i18nLabel: 'Accounts_OAuth_Custom_Button_Label_Text'                                                        //
    });                                                                                                           //
    RocketChat.settings.add("SAML_Custom_" + name + "_button_label_color", '#FFFFFF', {                           //
      type: 'string',                                                                                             //
      group: 'SAML',                                                                                              //
      section: name,                                                                                              //
      i18nLabel: 'Accounts_OAuth_Custom_Button_Label_Color'                                                       //
    });                                                                                                           //
    RocketChat.settings.add("SAML_Custom_" + name + "_button_color", '#13679A', {                                 //
      type: 'string',                                                                                             //
      group: 'SAML',                                                                                              //
      section: name,                                                                                              //
      i18nLabel: 'Accounts_OAuth_Custom_Button_Color'                                                             //
    });                                                                                                           //
    return RocketChat.settings.add("SAML_Custom_" + name + "_generate_username", false, {                         //
      type: 'boolean',                                                                                            //
      group: 'SAML',                                                                                              //
      section: name,                                                                                              //
      i18nLabel: 'SAML_Custom_Generate_Username'                                                                  //
    });                                                                                                           //
  }                                                                                                               //
});                                                                                                               //
                                                                                                                  //
timer = void 0;                                                                                                   // 19
                                                                                                                  //
updateServices = function() {                                                                                     // 20
  if (timer != null) {                                                                                            //
    Meteor.clearTimeout(timer);                                                                                   //
  }                                                                                                               //
  return timer = Meteor.setTimeout(function() {                                                                   //
    var data, i, len, results, service, serviceName, services;                                                    // 24
    services = RocketChat.settings.get(/^(SAML_Custom_)[a-z]+$/i);                                                //
    Accounts.saml.settings.providers = [];                                                                        //
    results = [];                                                                                                 // 28
    for (i = 0, len = services.length; i < len; i++) {                                                            //
      service = services[i];                                                                                      //
      logger.updated(service.key);                                                                                //
      serviceName = 'saml';                                                                                       //
      if (service.value === true) {                                                                               //
        data = {                                                                                                  //
          buttonLabelText: RocketChat.settings.get(service.key + "_button_label_text"),                           //
          buttonLabelColor: RocketChat.settings.get(service.key + "_button_label_color"),                         //
          buttonColor: RocketChat.settings.get(service.key + "_button_color"),                                    //
          clientConfig: {                                                                                         //
            provider: RocketChat.settings.get(service.key + "_provider")                                          //
          }                                                                                                       //
        };                                                                                                        //
        Accounts.saml.settings.generateUsername = RocketChat.settings.get(service.key + "_generate_username");    //
        Accounts.saml.settings.providers.push({                                                                   //
          provider: data.clientConfig.provider,                                                                   //
          entryPoint: RocketChat.settings.get(service.key + "_entry_point"),                                      //
          issuer: RocketChat.settings.get(service.key + "_issuer"),                                               //
          cert: RocketChat.settings.get(service.key + "_cert")                                                    //
        });                                                                                                       //
        results.push(ServiceConfiguration.configurations.upsert({                                                 //
          service: serviceName.toLowerCase()                                                                      //
        }, {                                                                                                      //
          $set: data                                                                                              //
        }));                                                                                                      //
      } else {                                                                                                    //
        results.push(ServiceConfiguration.configurations.remove({                                                 //
          service: serviceName.toLowerCase()                                                                      //
        }));                                                                                                      //
      }                                                                                                           //
    }                                                                                                             // 28
    return results;                                                                                               //
  }, 2000);                                                                                                       //
};                                                                                                                // 20
                                                                                                                  //
RocketChat.settings.get(/^SAML_.+/, function(key, value) {                                                        // 54
  return updateServices();                                                                                        //
});                                                                                                               // 54
                                                                                                                  //
Meteor.startup(function() {                                                                                       // 57
  var ref;                                                                                                        // 58
  if (((ref = RocketChat.settings.get(/^(SAML_Custom)_[a-z]+$/i)) != null ? ref.length : void 0) === 0) {         //
    return Meteor.call('addSamlService', 'Default');                                                              //
  }                                                                                                               //
});                                                                                                               // 57
                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json",".coffee"]});
require("./node_modules/meteor/steffo:meteor-accounts-saml/saml_server.js");
require("./node_modules/meteor/steffo:meteor-accounts-saml/saml_utils.js");
require("./node_modules/meteor/steffo:meteor-accounts-saml/saml_rocketchat.coffee.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['steffo:meteor-accounts-saml'] = {};

})();

//# sourceMappingURL=steffo_meteor-accounts-saml.js.map
