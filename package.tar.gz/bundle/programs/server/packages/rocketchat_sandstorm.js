(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var ECMAScript = Package.ecmascript.ECMAScript;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;

/* Package-scope variables */
var getHttpBridge, waitPromise;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/rocketchat_sandstorm/server/lib.js                                                                  //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
/* globals getHttpBridge, waitPromise */                                                                        //
/* exported getHttpBridge, waitPromise */                                                                       //
                                                                                                                //
RocketChat.Sandstorm = {};                                                                                      // 4
                                                                                                                //
if (process.env.SANDSTORM === '1') {                                                                            // 6
	var Future;                                                                                                    //
	var Capnp;                                                                                                     //
	var SandstormHttpBridge;                                                                                       //
	var capnpConnection;                                                                                           //
	var httpBridge;                                                                                                //
                                                                                                                //
	(function () {                                                                                                 //
		Future = Npm.require('fibers/future');                                                                        // 7
		Capnp = Npm.require('capnp');                                                                                 // 8
		SandstormHttpBridge = Npm.require('sandstorm/sandstorm-http-bridge.capnp').SandstormHttpBridge;               // 9
		capnpConnection = null;                                                                                       // 11
		httpBridge = null;                                                                                            // 12
                                                                                                                //
		getHttpBridge = function () {                                                                                 // 14
			if (!httpBridge) {                                                                                           // 15
				capnpConnection = Capnp.connect('unix:/tmp/sandstorm-api');                                                 // 16
				httpBridge = capnpConnection.restore(null, SandstormHttpBridge);                                            // 17
			}                                                                                                            //
			return httpBridge;                                                                                           // 19
		};                                                                                                            //
                                                                                                                //
		var promiseToFuture = function (promise) {                                                                    // 22
			var result = new Future();                                                                                   // 23
			promise.then(result['return'].bind(result), result['throw'].bind(result));                                   // 24
			return result;                                                                                               // 25
		};                                                                                                            //
                                                                                                                //
		waitPromise = function (promise) {                                                                            // 28
			return promiseToFuture(promise).wait();                                                                      // 29
		};                                                                                                            //
	})();                                                                                                          //
}                                                                                                               //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/rocketchat_sandstorm/server/events.js                                                               //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
/* globals getHttpBridge, waitPromise */                                                                        //
                                                                                                                //
RocketChat.Sandstorm.notify = function () {};                                                                   // 3
                                                                                                                //
if (process.env.SANDSTORM === '1') {                                                                            // 5
	var ACTIVITY_TYPES = {                                                                                         // 6
		'message': 0,                                                                                                 // 7
		'privateMessage': 1                                                                                           // 8
	};                                                                                                             //
                                                                                                                //
	RocketChat.Sandstorm.notify = function (message, userIds, caption, type) {                                     // 11
		var sessionId = message.sandstormSessionId;                                                                   // 12
		if (!sessionId) {                                                                                             // 13
			return;                                                                                                      // 14
		}                                                                                                             //
		var httpBridge = getHttpBridge();                                                                             // 16
		var activity = {};                                                                                            // 17
                                                                                                                //
		if (type) {                                                                                                   // 19
			activity.type = ACTIVITY_TYPES[type];                                                                        // 20
		}                                                                                                             //
                                                                                                                //
		if (caption) {                                                                                                // 23
			activity.notification = { caption: { defaultText: caption } };                                               // 24
		}                                                                                                             //
                                                                                                                //
		if (userIds) {                                                                                                // 27
			activity.users = _.map(userIds, function (userId) {                                                          // 28
				var user = Meteor.users.findOne({ _id: userId }, { fields: { 'services.sandstorm.id': 1 } });               // 29
				return {                                                                                                    // 30
					identity: httpBridge.getSavedIdentity(user.services.sandstorm.id).identity,                                // 31
					mentioned: true                                                                                            // 32
				};                                                                                                          //
			});                                                                                                          //
		}                                                                                                             //
                                                                                                                //
		return waitPromise(httpBridge.getSessionContext(sessionId).context.activity(activity));                       // 37
	};                                                                                                             //
}                                                                                                               //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/rocketchat_sandstorm/server/powerbox.js                                                             //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
/* globals getHttpBridge, waitPromise */                                                                        //
                                                                                                                //
RocketChat.Sandstorm.offerUiView = function () {};                                                              // 3
                                                                                                                //
if (process.env.SANDSTORM === '1') {                                                                            // 5
	var Capnp = Npm.require('capnp');                                                                              // 6
	var Powerbox = Npm.require('sandstorm/powerbox.capnp');                                                        // 7
	var Grain = Npm.require('sandstorm/grain.capnp');                                                              // 8
                                                                                                                //
	RocketChat.Sandstorm.offerUiView = function (token, sessionId) {                                               // 10
		var httpBridge = getHttpBridge();                                                                             // 11
		var session = httpBridge.getSessionContext(sessionId).context;                                                // 12
		var api = httpBridge.getSandstormApi(sessionId).api;                                                          // 13
		var cap = waitPromise(api.restore(new Buffer(token, 'base64'))).cap;                                          // 14
		return waitPromise(session.offer(cap, undefined, { tags: [{ id: '15831515641881813735' }] }));                // 15
	};                                                                                                             //
                                                                                                                //
	Meteor.methods({                                                                                               // 18
		sandstormClaimRequest: function (token, seriliazedDescriptor) {                                               // 19
			var descriptor = Capnp.parsePacked(Powerbox.PowerboxDescriptor, new Buffer(seriliazedDescriptor, 'base64'));
			var grainTitle = Capnp.parse(Grain.UiView.PowerboxTag, descriptor.tags[0].value).title;                      // 21
			var sessionId = this.connection.sandstormSessionId();                                                        // 22
			var httpBridge = getHttpBridge();                                                                            // 23
			var session = httpBridge.getSessionContext(sessionId).context;                                               // 24
			var cap = waitPromise(session.claimRequest(token)).cap.castAs(Grain.UiView);                                 // 25
			var api = httpBridge.getSandstormApi(sessionId).api;                                                         // 26
			var newToken = waitPromise(api.save(cap)).token.toString('base64');                                          // 27
			var viewInfo = waitPromise(cap.getViewInfo());                                                               // 28
			var appTitle = viewInfo.appTitle;                                                                            // 29
			var asset = waitPromise(viewInfo.grainIcon.getUrl());                                                        // 30
			var appIconUrl = asset.protocol + '://' + asset.hostPath;                                                    // 31
			return {                                                                                                     // 32
				token: newToken,                                                                                            // 33
				appTitle: appTitle,                                                                                         // 34
				appIconUrl: appIconUrl,                                                                                     // 35
				grainTitle: grainTitle                                                                                      // 36
			};                                                                                                           //
		},                                                                                                            //
		sandstormOffer: function (token) {                                                                            // 39
			RocketChat.Sandstorm.offerUiView(token, this.connection.sandstormSessionId());                               // 40
		}                                                                                                             //
	});                                                                                                            //
}                                                                                                               //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:sandstorm'] = {};

})();

//# sourceMappingURL=rocketchat_sandstorm.js.map
