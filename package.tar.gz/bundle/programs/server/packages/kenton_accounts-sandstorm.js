(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Random = Package.random.Random;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var check = Package.check.check;
var Match = Package.check.Match;
var DDPServer = Package['ddp-server'].DDPServer;
var DDP = Package['ddp-client'].DDP;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/kenton_accounts-sandstorm/server.js                                                           //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
// Copyright (c) 2014 Sandstorm Development Group, Inc. and contributors                                  // 1
// Licensed under the MIT License:                                                                        // 2
//                                                                                                        // 3
// Permission is hereby granted, free of charge, to any person obtaining a copy                           // 4
// of this software and associated documentation files (the "Software"), to deal                          // 5
// in the Software without restriction, including without limitation the rights                           // 6
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell                              // 7
// copies of the Software, and to permit persons to whom the Software is                                  // 8
// furnished to do so, subject to the following conditions:                                               // 9
//                                                                                                        // 10
// The above copyright notice and this permission notice shall be included in                             // 11
// all copies or substantial portions of the Software.                                                    // 12
//                                                                                                        // 13
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                             // 14
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,                               // 15
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE                            // 16
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER                                 // 17
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,                          // 18
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN                              // 19
// THE SOFTWARE.                                                                                          // 20
                                                                                                          // 21
if (process.env.SANDSTORM) {                                                                              // 22
  __meteor_runtime_config__.SANDSTORM = true;                                                             // 23
}                                                                                                         // 24
                                                                                                          // 25
if (__meteor_runtime_config__.SANDSTORM) {                                                                // 26
  if (Package["accounts-base"]) {                                                                         // 27
    // Highlander Mode: Disable all non-Sandstorm login mechanisms.                                       // 28
    Package["accounts-base"].Accounts.validateLoginAttempt(function (attempt) {                           // 29
      if (!attempt.allowed) {                                                                             // 30
        return false;                                                                                     // 31
      }                                                                                                   // 32
      if (attempt.type !== "sandstorm") {                                                                 // 33
        throw new Meteor.Error(403, "Non-Sandstorm login mechanisms disabled on Sandstorm.");             // 34
      }                                                                                                   // 35
      return true;                                                                                        // 36
    });                                                                                                   // 37
    Package["accounts-base"].Accounts.validateNewUser(function (user) {                                   // 38
      if (!user.services.sandstorm) {                                                                     // 39
        throw new Meteor.Error(403, "Non-Sandstorm login mechanisms disabled on Sandstorm.");             // 40
      }                                                                                                   // 41
      return true;                                                                                        // 42
    });                                                                                                   // 43
  }                                                                                                       // 44
                                                                                                          // 45
  var Future = Npm.require("fibers/future");                                                              // 46
                                                                                                          // 47
  var inMeteor = Meteor.bindEnvironment(function (callback) {                                             // 48
    callback();                                                                                           // 49
  });                                                                                                     // 50
                                                                                                          // 51
  var logins = {};                                                                                        // 52
  // Maps tokens to currently-waiting login method calls.                                                 // 53
                                                                                                          // 54
  if (Package["accounts-base"]) {                                                                         // 55
    Meteor.users._ensureIndex("services.sandstorm.id", {unique: 1, sparse: 1});                           // 56
  }                                                                                                       // 57
                                                                                                          // 58
  Meteor.onConnection(function (connection) {                                                             // 59
    connection._sandstormUser = null;                                                                     // 60
    connection._sandstormSessionId = null;                                                                // 61
    connection.sandstormUser = function () {                                                              // 62
      if (!connection._sandstormUser) {                                                                   // 63
        throw new Meteor.Error(400, "Client did not complete authentication handshake.");                 // 64
      }                                                                                                   // 65
      return this._sandstormUser;                                                                         // 66
    };                                                                                                    // 67
    connection.sandstormSessionId = function () {                                                         // 68
      if (!connection._sandstormSessionId) {                                                              // 69
        throw new Meteor.Error(400, "Client did not complete authentication handshake.");                 // 70
      }                                                                                                   // 71
      return this._sandstormSessionId;                                                                    // 72
    }                                                                                                     // 73
  });                                                                                                     // 74
                                                                                                          // 75
  Meteor.methods({                                                                                        // 76
    loginWithSandstorm: function (token) {                                                                // 77
      check(token, String);                                                                               // 78
                                                                                                          // 79
      var future = new Future();                                                                          // 80
                                                                                                          // 81
      logins[token] = future;                                                                             // 82
                                                                                                          // 83
      var timeout = setTimeout(function () {                                                              // 84
        future.throw(new Meteor.Error("timeout", "Gave up waiting for login rendezvous XHR."));           // 85
      }, 10000);                                                                                          // 86
                                                                                                          // 87
      var info;                                                                                           // 88
      try {                                                                                               // 89
        info = future.wait();                                                                             // 90
      } finally {                                                                                         // 91
        clearTimeout(timeout);                                                                            // 92
        delete logins[token];                                                                             // 93
      }                                                                                                   // 94
                                                                                                          // 95
      // Set connection info. The call to setUserId() resets all publishes. We update the                 // 96
      // connection's sandstorm info first so that when the publishes are re-run they'll see the          // 97
      // new info. In theory we really want to update it exactly when this.userId is updated, but         // 98
      // we'd have to dig into Meteor internals to pull that off. Probably updating it a little           // 99
      // early is fine?                                                                                   // 100
      //                                                                                                  // 101
      // Note that calling setUserId() with the same ID a second time still goes through the motions      // 102
      // of restarting all subscriptions, which is important if the permissions changed. Hopefully        // 103
      // Meteor won't decide to "optimize" this by returning early if the user ID hasn't changed.         // 104
      this.connection._sandstormUser = info.sandstorm;                                                    // 105
      this.connection._sandstormSessionId = info.sessionId;                                               // 106
      this.setUserId(info.userId);                                                                        // 107
                                                                                                          // 108
      return info;                                                                                        // 109
    }                                                                                                     // 110
  });                                                                                                     // 111
                                                                                                          // 112
  WebApp.rawConnectHandlers.use(function (req, res, next) {                                               // 113
    if (req.url === "/.sandstorm-login") {                                                                // 114
      handlePostToken(req, res);                                                                          // 115
      return;                                                                                             // 116
    }                                                                                                     // 117
    return next();                                                                                        // 118
  });                                                                                                     // 119
                                                                                                          // 120
  function readAll(stream) {                                                                              // 121
    var future = new Future();                                                                            // 122
                                                                                                          // 123
    var chunks = [];                                                                                      // 124
    stream.on("data", function (chunk) {                                                                  // 125
      chunks.push(chunk.toString());                                                                      // 126
    });                                                                                                   // 127
    stream.on("error", function (err) {                                                                   // 128
      future.throw(err);                                                                                  // 129
    });                                                                                                   // 130
    stream.on("end", function () {                                                                        // 131
      future.return();                                                                                    // 132
    });                                                                                                   // 133
                                                                                                          // 134
    future.wait();                                                                                        // 135
                                                                                                          // 136
    return chunks.join("");                                                                               // 137
  }                                                                                                       // 138
                                                                                                          // 139
  var handlePostToken = Meteor.bindEnvironment(function (req, res) {                                      // 140
    inMeteor(function () {                                                                                // 141
      try {                                                                                               // 142
        // Note that cross-origin POSTs cannot set arbitrary Content-Types without explicit CORS          // 143
        // permission, so this effectively prevents XSRF.                                                 // 144
        if (req.headers["content-type"].split(";")[0].trim() !== "application/x-sandstorm-login-token") {
          throw new Error("wrong Content-Type for .sandstorm-login: " + req.headers["content-type"]);     // 146
        }                                                                                                 // 147
                                                                                                          // 148
        var token = readAll(req);                                                                         // 149
                                                                                                          // 150
        var future = logins[token];                                                                       // 151
        if (!future) {                                                                                    // 152
          throw new Error("no current login request matching token");                                     // 153
        }                                                                                                 // 154
                                                                                                          // 155
        var permissions = req.headers["x-sandstorm-permissions"];                                         // 156
        if (permissions && permissions !== "") {                                                          // 157
          permissions = permissions.split(",");                                                           // 158
        } else {                                                                                          // 159
          permissions = [];                                                                               // 160
        }                                                                                                 // 161
                                                                                                          // 162
        var sandstormInfo = {                                                                             // 163
          id: req.headers["x-sandstorm-user-id"] || null,                                                 // 164
          name: decodeURI(req.headers["x-sandstorm-username"]),                                           // 165
          permissions: permissions,                                                                       // 166
          picture: req.headers["x-sandstorm-user-picture"] || null,                                       // 167
          preferredHandle: req.headers["x-sandstorm-preferred-handle"] || null,                           // 168
          pronouns: req.headers["x-sandstorm-user-pronouns"] || null,                                     // 169
        };                                                                                                // 170
                                                                                                          // 171
        var userInfo = {sandstorm: sandstormInfo};                                                        // 172
        if (Package["accounts-base"]) {                                                                   // 173
          if (sandstormInfo.id) {                                                                         // 174
            // The user is logged into Sansdtorm. Create a Meteor account for them, or find the           // 175
            // existing one, and record the user ID.                                                      // 176
            var login = Package["accounts-base"].Accounts.updateOrCreateUserFromExternalService(          // 177
              "sandstorm", sandstormInfo, {profile: {name: sandstormInfo.name}});                         // 178
            userInfo.userId = login.userId;                                                               // 179
          } else {                                                                                        // 180
            userInfo.userId = null;                                                                       // 181
          }                                                                                               // 182
        } else {                                                                                          // 183
          // Since the app isn't using regular Meteor accounts, we can define Meteor.userId()             // 184
          // however we want.                                                                             // 185
          userInfo.userId = sandstormInfo.id;                                                             // 186
        }                                                                                                 // 187
                                                                                                          // 188
        userInfo.sessionId = req.headers["x-sandstorm-session-id"] || null;                               // 189
        future.return(userInfo);                                                                          // 190
        res.writeHead(204, {});                                                                           // 191
        res.end();                                                                                        // 192
      } catch (err) {                                                                                     // 193
        res.writeHead(500, {                                                                              // 194
          "Content-Type": "text/plain"                                                                    // 195
        });                                                                                               // 196
        res.end(err.stack);                                                                               // 197
      }                                                                                                   // 198
    });                                                                                                   // 199
  });                                                                                                     // 200
}                                                                                                         // 201
                                                                                                          // 202
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['kenton:accounts-sandstorm'] = {};

})();

//# sourceMappingURL=kenton_accounts-sandstorm.js.map
