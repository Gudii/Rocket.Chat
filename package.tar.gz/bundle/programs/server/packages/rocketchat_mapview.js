(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;

/* Package-scope variables */
var __coffeescriptShare;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/rocketchat_mapview/server/settings.coffee.js             //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.startup(function() {                                          // 1
  RocketChat.settings.add('MapView_Enabled', false, {                // 2
    type: 'boolean',                                                 // 2
    group: 'Message',                                                // 2
    section: 'Google Maps',                                          // 2
    "public": true,                                                  // 2
    i18nLabel: 'MapView_Enabled',                                    // 2
    i18nDescription: 'MapView_Enabled_Description'                   // 2
  });                                                                //
  return RocketChat.settings.add('MapView_GMapsAPIKey', '', {        //
    type: 'string',                                                  // 3
    group: 'Message',                                                // 3
    section: 'Google Maps',                                          // 3
    "public": true,                                                  // 3
    i18nLabel: 'MapView_GMapsAPIKey',                                // 3
    i18nDescription: 'MapView_GMapsAPIKey_Description'               // 3
  });                                                                //
});                                                                  // 1
                                                                     //
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:mapview'] = {};

})();

//# sourceMappingURL=rocketchat_mapview.js.map
