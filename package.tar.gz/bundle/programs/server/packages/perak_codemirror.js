(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['perak:codemirror'] = {};

})();

//# sourceMappingURL=perak_codemirror.js.map
