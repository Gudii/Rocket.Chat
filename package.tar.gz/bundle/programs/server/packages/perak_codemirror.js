(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['perak:codemirror'] = {};

})();
