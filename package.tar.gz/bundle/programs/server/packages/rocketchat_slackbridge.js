(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var ECMAScript = Package.ecmascript.ECMAScript;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var Logger = Package['rocketchat:logger'].Logger;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;

/* Package-scope variables */
var logger;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/rocketchat_slackbridge/logger.js                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/* globals logger:true */                                                                                             //
/* exported logger */                                                                                                 //
                                                                                                                      //
logger = new Logger('SlackBridge', {                                                                                  // 4
	sections: {                                                                                                          // 5
		connection: 'Connection',                                                                                           // 6
		events: 'Events',                                                                                                   // 7
		'class': 'Class'                                                                                                    // 8
	}                                                                                                                    //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/rocketchat_slackbridge/settings.js                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.startup(function () {                                                                                          // 1
	RocketChat.settings.addGroup('SlackBridge', function () {                                                            // 2
		this.add('SlackBridge_Enabled', false, {                                                                            // 3
			type: 'boolean',                                                                                                   // 4
			i18nLabel: 'Enabled',                                                                                              // 5
			'public': true                                                                                                     // 6
		});                                                                                                                 //
                                                                                                                      //
		this.add('SlackBridge_APIToken', '', {                                                                              // 9
			type: 'string',                                                                                                    // 10
			enableQuery: {                                                                                                     // 11
				_id: 'SlackBridge_Enabled',                                                                                       // 12
				value: true                                                                                                       // 13
			},                                                                                                                 //
			i18nLabel: 'API_Token'                                                                                             // 15
		});                                                                                                                 //
                                                                                                                      //
		this.add('SlackBridge_AliasFormat', '', {                                                                           // 18
			type: 'string',                                                                                                    // 19
			i18nLabel: 'Alias_Format',                                                                                         // 20
			i18nDescription: 'Alias_Format_Description'                                                                        // 21
		});                                                                                                                 //
                                                                                                                      //
		this.add('SlackBridge_ExcludeBotnames', '', {                                                                       // 24
			type: 'string',                                                                                                    // 25
			i18nLabel: 'Exclude_Botnames',                                                                                     // 26
			i18nDescription: 'Exclude_Botnames_Description'                                                                    // 27
		});                                                                                                                 //
	});                                                                                                                  //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/rocketchat_slackbridge/slackbridge.js                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/* globals logger */                                                                                                  //
                                                                                                                      //
var SlackBridge = (function () {                                                                                      //
	function SlackBridge() {                                                                                             // 4
		var _this = this;                                                                                                   //
                                                                                                                      //
		babelHelpers.classCallCheck(this, SlackBridge);                                                                     //
                                                                                                                      //
		this.util = Npm.require('util');                                                                                    // 5
		this.slackClient = Npm.require('slack-client');                                                                     // 6
		this.apiToken = RocketChat.settings.get('SlackBridge_APIToken');                                                    // 7
		this.aliasFormat = RocketChat.settings.get('SlackBridge_AliasFormat');                                              // 8
		this.excludeBotnames = RocketChat.settings.get('SlackBridge_Botnames');                                             // 9
		this.rtm = {};                                                                                                      // 10
		this.connected = false;                                                                                             // 11
		this.userTags = {};                                                                                                 // 12
		this.channelMap = {};                                                                                               // 13
                                                                                                                      //
		RocketChat.settings.onload('SlackBridge_APIToken', function (key, value) {                                          // 15
			_this.apiToken = value;                                                                                            // 16
			if (_this.connected) {                                                                                             // 17
				_this.disconnect();                                                                                               // 18
				_this.connect();                                                                                                  // 19
			} else if (RocketChat.settings.get('SlackBridge_Enabled')) {                                                       //
				_this.connect();                                                                                                  // 21
			}                                                                                                                  //
		});                                                                                                                 //
                                                                                                                      //
		RocketChat.settings.onload('SlackBridge_Enabled', function (key, value) {                                           // 25
			if (value && _this.apiToken) {                                                                                     // 26
				_this.connect();                                                                                                  // 27
			} else {                                                                                                           //
				_this.disconnect();                                                                                               // 29
			}                                                                                                                  //
		});                                                                                                                 //
                                                                                                                      //
		RocketChat.settings.onload('SlackBridge_AliasFormat', function (key, value) {                                       // 33
			_this.aliasFormat = value;                                                                                         // 34
		});                                                                                                                 //
                                                                                                                      //
		RocketChat.settings.onload('SlackBridge_ExcludeBotnames', function (key, value) {                                   // 37
			_this.excludeBotnames = value;                                                                                     // 38
		});                                                                                                                 //
	}                                                                                                                    //
                                                                                                                      //
	SlackBridge.prototype.connect = (function () {                                                                       // 3
		function connect() {                                                                                                // 42
			if (this.connected === false) {                                                                                    // 43
				this.connected = true;                                                                                            // 44
				logger.connection.info('Connecting via token: ', this.apiToken);                                                  // 45
				var RtmClient = this.slackClient.RtmClient;                                                                       // 46
				this.rtm = new RtmClient(this.apiToken);                                                                          // 47
				this.rtm.start();                                                                                                 // 48
				this.setEvents();                                                                                                 // 49
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return connect;                                                                                                     //
	})();                                                                                                                //
                                                                                                                      //
	SlackBridge.prototype.disconnect = (function () {                                                                    // 3
		function disconnect() {                                                                                             // 53
			if (this.connected === true) {                                                                                     // 54
				this.rtm.disconnect && this.rtm.disconnect();                                                                     // 55
				this.connected = false;                                                                                           // 56
				logger.connection.info('Disconnected');                                                                           // 57
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return disconnect;                                                                                                  //
	})();                                                                                                                //
                                                                                                                      //
	SlackBridge.prototype.convertSlackMessageToRocketChat = (function () {                                               // 3
		function convertSlackMessageToRocketChat(message) {                                                                 // 61
			var _this2 = this;                                                                                                 //
                                                                                                                      //
			if (!_.isEmpty(message)) {                                                                                         // 62
				message = message.replace(/<!everyone>/g, '@all');                                                                // 63
				message = message.replace(/<!channel>/g, '@all');                                                                 // 64
				message = message.replace(/&gt;/g, '<');                                                                          // 65
				message = message.replace(/&lt;/g, '>');                                                                          // 66
				message = message.replace(/&amp;/g, '&');                                                                         // 67
				message = message.replace(/:simple_smile:/g, ':smile:');                                                          // 68
				message = message.replace(/:memo:/g, ':pencil:');                                                                 // 69
				message = message.replace(/:piggy:/g, ':pig:');                                                                   // 70
				message = message.replace(/:uk:/g, ':gb:');                                                                       // 71
				message = message.replace(/<(http[s]?:[^>]*)>/g, '$1');                                                           // 72
                                                                                                                      //
				message.replace(/(?:<@)([a-zA-Z0-9]+)(?:\|.+)?(?:>)/g, function (match, userId) {                                 // 74
					if (!_this2.userTags[userId]) {                                                                                  // 75
						_this2.findUser(userId) || _this2.addUser(userId); // This adds userTags for the userId                         // 76
					}                                                                                                                //
					var userTags = _this2.userTags[userId];                                                                          // 78
					if (userTags) {                                                                                                  // 79
						message = message.replace(userTags.slack, userTags.rocket);                                                     // 80
					}                                                                                                                //
				});                                                                                                               //
			} else {                                                                                                           //
				message = '';                                                                                                     // 84
			}                                                                                                                  //
			return message;                                                                                                    // 86
		}                                                                                                                   //
                                                                                                                      //
		return convertSlackMessageToRocketChat;                                                                             //
	})();                                                                                                                //
                                                                                                                      //
	SlackBridge.prototype.findChannel = (function () {                                                                   // 3
		function findChannel(channelId) {                                                                                   // 89
			return RocketChat.models.Rooms.findOneByImportId(channelId);                                                       // 90
		}                                                                                                                   //
                                                                                                                      //
		return findChannel;                                                                                                 //
	})();                                                                                                                //
                                                                                                                      //
	SlackBridge.prototype.addChannel = (function () {                                                                    // 3
		function addChannel(channelId) {                                                                                    // 93
			var _this3 = this;                                                                                                 //
                                                                                                                      //
			var hasRetried = arguments.length <= 1 || arguments[1] === undefined ? false : arguments[1];                       //
                                                                                                                      //
			var data = null;                                                                                                   // 94
			var isGroup = false;                                                                                               // 95
			if (channelId.charAt(0) === 'C') {                                                                                 // 96
				data = HTTP.get('https://slack.com/api/channels.info', { params: { token: this.apiToken, channel: channelId } });
			} else if (channelId.charAt(0) === 'G') {                                                                          //
				data = HTTP.get('https://slack.com/api/groups.info', { params: { token: this.apiToken, channel: channelId } });   // 99
				isGroup = true;                                                                                                   // 100
			}                                                                                                                  //
			if (data && data.data && data.data.ok === true) {                                                                  // 102
				var _iterator, _isArray, _i;                                                                                      //
                                                                                                                      //
				var _ref;                                                                                                         //
                                                                                                                      //
				var _ret = (function () {                                                                                         //
					var channelData = isGroup ? data.data.group : data.data.channel;                                                 // 103
					var existingRoom = RocketChat.models.Rooms.findOneByName(channelData.name);                                      // 104
					if (existingRoom || channelData.is_general) {                                                                    // 105
						if (channelData.is_general && channelData.name !== (existingRoom && existingRoom.name)) {                       // 106
							Meteor.call('saveRoomSettings', 'GENERAL', 'roomName', channelData.name);                                      // 107
						}                                                                                                               //
						channelData.rocketId = channelData.is_general ? 'GENERAL' : existingRoom._id;                                   // 109
						RocketChat.models.Rooms.update({ _id: channelData.rocketId }, { $addToSet: { importIds: channelData.id } });    // 110
					} else {                                                                                                         //
						var _ret2 = (function () {                                                                                      //
							var users = [];                                                                                                // 112
							for (_iterator = channelData.members, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
								if (_isArray) {                                                                                               //
									if (_i >= _iterator.length) break;                                                                           //
									_ref = _iterator[_i++];                                                                                      //
								} else {                                                                                                      //
									_i = _iterator.next();                                                                                       //
									if (_i.done) break;                                                                                          //
									_ref = _i.value;                                                                                             //
								}                                                                                                             //
                                                                                                                      //
								var member = _ref;                                                                                            //
                                                                                                                      //
								if (member !== channelData.creator) {                                                                         // 114
									var user = _this3.findUser(member) || _this3.addUser(member);                                                // 115
									if (user) {                                                                                                  // 116
										users.push(user.username);                                                                                  // 117
									}                                                                                                            //
								}                                                                                                             //
							}                                                                                                              //
							var creator = channelData.creator ? _this3.findUser(channelData.creator) || _this3.addUser(channelData.creator) : null;
							if (!creator) {                                                                                                // 122
								logger.events.error('Could not fetch room creator information', channelData.creator);                         // 123
								return {                                                                                                      // 124
									v: {                                                                                                         //
										v: undefined                                                                                                //
									}                                                                                                            //
								};                                                                                                            //
							}                                                                                                              //
                                                                                                                      //
							try {                                                                                                          // 127
								Meteor.runAsUser(creator._id, function () {                                                                   // 128
									if (isGroup) {                                                                                               // 129
										var channel = Meteor.call('createPrivateGroup', channelData.name, users);                                   // 130
										channelData.rocketId = channel._id;                                                                         // 131
									} else {                                                                                                     //
										var channel = Meteor.call('createChannel', channelData.name, users);                                        // 133
										channelData.rocketId = channel._id;                                                                         // 134
									}                                                                                                            //
								});                                                                                                           //
							} catch (e) {                                                                                                  //
								if (!hasRetried) {                                                                                            // 138
									// If first time trying to create channel fails, could be because of multiple messages received at the same time. Try again once after 1s.
									Meteor._sleepForMs(1000);                                                                                    // 140
									return {                                                                                                     // 141
										v: {                                                                                                        //
											v: _this3.findChannel(channelId) || _this3.addChannel(channelId, true)                                     //
										}                                                                                                           //
									};                                                                                                           //
								}                                                                                                             //
							}                                                                                                              //
                                                                                                                      //
							var roomUpdate = {                                                                                             // 145
								ts: new Date(channelData.created * 1000)                                                                      // 146
							};                                                                                                             //
							var lastSetTopic = 0;                                                                                          // 148
							if (!_.isEmpty(channelData.topic && channelData.topic.value)) {                                                // 149
								roomUpdate.topic = channelData.topic.value;                                                                   // 150
								lastSetTopic = channelData.topic.last_set;                                                                    // 151
							}                                                                                                              //
							if (!_.isEmpty(channelData.purpose && channelData.purpose.value) && channelData.purpose.last_set > lastSetTopic) {
								roomUpdate.topic = channelData.purpose.value;                                                                 // 154
							}                                                                                                              //
                                                                                                                      //
							RocketChat.models.Rooms.update({ _id: channelData.rocketId }, { $set: roomUpdate, $addToSet: { importIds: channelData.id } });
							_this3.channelMap[channelData.rocketId] = { id: channelId, family: channelId.charAt(0) === 'C' ? 'channels' : 'groups' };
						})();                                                                                                           //
                                                                                                                      //
						if (typeof _ret2 === 'object') return _ret2.v;                                                                  //
					}                                                                                                                //
					return {                                                                                                         // 160
						v: RocketChat.models.Rooms.findOne(channelData.rocketId)                                                        //
					};                                                                                                               //
				})();                                                                                                             //
                                                                                                                      //
				if (typeof _ret === 'object') return _ret.v;                                                                      //
			}                                                                                                                  //
                                                                                                                      //
			return;                                                                                                            // 163
		}                                                                                                                   //
                                                                                                                      //
		return addChannel;                                                                                                  //
	})();                                                                                                                //
                                                                                                                      //
	SlackBridge.prototype.findUser = (function () {                                                                      // 3
		function findUser(userId) {                                                                                         // 166
			var user = RocketChat.models.Users.findOneByImportId(userId);                                                      // 167
			if (user && !this.userTags[userId]) {                                                                              // 168
				this.userTags[userId] = { slack: '<@' + userId + '>', rocket: '@' + user.username };                              // 169
			}                                                                                                                  //
			return user;                                                                                                       // 171
		}                                                                                                                   //
                                                                                                                      //
		return findUser;                                                                                                    //
	})();                                                                                                                //
                                                                                                                      //
	SlackBridge.prototype.addUser = (function () {                                                                       // 3
		function addUser(userId) {                                                                                          // 174
			var _this4 = this;                                                                                                 //
                                                                                                                      //
			var data = HTTP.get('https://slack.com/api/users.info', { params: { token: this.apiToken, user: userId } });       // 175
			if (data && data.data && data.data.ok === true && data.data.user && data.data.user.profile && data.data.user.profile.email) {
				var _ret3 = (function () {                                                                                        //
					var userData = data.data.user;                                                                                   // 177
					var existingUser = RocketChat.models.Users.findOneByEmailAddress(userData.profile.email) || RocketChat.models.Users.findOneByUsername(userData.name);
					if (existingUser) {                                                                                              // 179
						userData.rocketId = existingUser._id;                                                                           // 180
						userData.name = existingUser.username;                                                                          // 181
					} else {                                                                                                         //
						userData.rocketId = Accounts.createUser({ email: userData.profile.email, password: Date.now() + userData.name + userData.profile.email.toUpperCase() });
						Meteor.runAsUser(userData.rocketId, function () {                                                               // 184
							Meteor.call('setUsername', userData.name);                                                                     // 185
							Meteor.call('joinDefaultChannels', true);                                                                      // 186
							var url = null;                                                                                                // 187
							if (userData.profile.image_original) {                                                                         // 188
								url = userData.profile.image_original;                                                                        // 189
							} else if (userData.profile.image_512) {                                                                       //
								url = userData.profile.image_512;                                                                             // 191
							}                                                                                                              //
							Meteor.call('setAvatarFromService', url, null, 'url');                                                         // 193
							// Slack's is -18000 which translates to Rocket.Chat's after dividing by 3600                                  //
							if (userData.tz_offset) {                                                                                      // 195
								Meteor.call('updateUserUtcOffset', userData.tz_offset / 3600);                                                // 196
							}                                                                                                              //
							if (userData.profile.real_name) {                                                                              // 198
								RocketChat.models.Users.setName(userData.rocketId, userData.profile.real_name);                               // 199
							}                                                                                                              //
						});                                                                                                             //
						// Deleted users are 'inactive' users in Rocket.Chat                                                            //
						if (userData.deleted) {                                                                                         // 203
							RocketChat.models.Users.setUserActive(userData.rocketId, false);                                               // 204
							RocketChat.models.Users.unsetLoginTokens(userData.rocketId);                                                   // 205
						}                                                                                                               //
					}                                                                                                                //
					RocketChat.models.Users.update({ _id: userData.rocketId }, { $addToSet: { importIds: userData.id } });           // 208
					if (!_this4.userTags[userId]) {                                                                                  // 209
						_this4.userTags[userId] = { slack: '<@' + userId + '>', rocket: '@' + userData.name };                          // 210
					}                                                                                                                //
					return {                                                                                                         // 212
						v: RocketChat.models.Users.findOneById(userData.rocketId)                                                       //
					};                                                                                                               //
				})();                                                                                                             //
                                                                                                                      //
				if (typeof _ret3 === 'object') return _ret3.v;                                                                    //
			}                                                                                                                  //
                                                                                                                      //
			return;                                                                                                            // 215
		}                                                                                                                   //
                                                                                                                      //
		return addUser;                                                                                                     //
	})();                                                                                                                //
                                                                                                                      //
	SlackBridge.prototype.addAlias = (function () {                                                                      // 3
		function addAlias(username, msgObj) {                                                                               // 218
			if (this.aliasFormat) {                                                                                            // 219
				var alias = this.util.format(this.aliasFormat, username);                                                         // 220
                                                                                                                      //
				if (alias !== username) {                                                                                         // 222
					msgObj.alias = alias;                                                                                            // 223
				}                                                                                                                 //
			}                                                                                                                  //
                                                                                                                      //
			return msgObj;                                                                                                     // 227
		}                                                                                                                   //
                                                                                                                      //
		return addAlias;                                                                                                    //
	})();                                                                                                                //
                                                                                                                      //
	SlackBridge.prototype.sendMessage = (function () {                                                                   // 3
		function sendMessage(room, user, message, msgDataDefaults) {                                                        // 230
			if (message.type === 'message') {                                                                                  // 231
				var msgObj = {};                                                                                                  // 232
				if (!_.isEmpty(message.subtype)) {                                                                                // 233
					msgObj = this.processSubtypedMessage(room, user, message, msgDataDefaults);                                      // 234
					if (!msgObj) {                                                                                                   // 235
						return;                                                                                                         // 236
					}                                                                                                                //
				} else {                                                                                                          //
					msgObj = {                                                                                                       // 239
						msg: this.convertSlackMessageToRocketChat(message.text),                                                        // 240
						rid: room._id,                                                                                                  // 241
						u: {                                                                                                            // 242
							_id: user._id,                                                                                                 // 243
							username: user.username                                                                                        // 244
						}                                                                                                               //
					};                                                                                                               //
                                                                                                                      //
					this.addAlias(user.username, msgObj);                                                                            // 248
				}                                                                                                                 //
				_.extend(msgObj, msgDataDefaults);                                                                                // 250
				if (message.edited) {                                                                                             // 251
					msgObj.ets = new Date(parseInt(message.edited.ts.split('.')[0]) * 1000);                                         // 252
				}                                                                                                                 //
				if (message.subtype === 'bot_message') {                                                                          // 254
					user = RocketChat.models.Users.findOneById('rocket.cat', { fields: { username: 1 } });                           // 255
				}                                                                                                                 //
                                                                                                                      //
				if (message.pinned_to && message.pinned_to.indexOf(message.channel) !== -1) {                                     // 258
					msgObj.pinned = true;                                                                                            // 259
					msgObj.pinnedAt = Date.now;                                                                                      // 260
					msgObj.pinnedBy = _.pick(user, '_id', 'username');                                                               // 261
				}                                                                                                                 //
				RocketChat.sendMessage(user, msgObj, room, true);                                                                 // 263
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return sendMessage;                                                                                                 //
	})();                                                                                                                //
                                                                                                                      //
	SlackBridge.prototype.saveMessage = (function () {                                                                   // 3
		function saveMessage(message) {                                                                                     // 267
			var channel = message.channel ? this.findChannel(message.channel) || this.addChannel(message.channel) : null;      // 268
			var user = null;                                                                                                   // 269
			if (message.subtype === 'message_deleted' || message.subtype === 'message_changed') {                              // 270
				user = message.previous_message.user ? this.findUser(message.previous_message.user) || this.addUser(message.previous_message.user) : null;
			} else {                                                                                                           //
				user = message.user ? this.findUser(message.user) || this.addUser(message.user) : null;                           // 273
			}                                                                                                                  //
			if (channel && user) {                                                                                             // 275
				var msgDataDefaults = {                                                                                           // 276
					_id: 'slack-' + message.channel + '-' + message.ts.replace(/\./g, '-'),                                          // 277
					ts: new Date(parseInt(message.ts.split('.')[0]) * 1000)                                                          // 278
				};                                                                                                                //
				this.sendMessage(channel, user, message, msgDataDefaults);                                                        // 280
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return saveMessage;                                                                                                 //
	})();                                                                                                                //
                                                                                                                      //
	SlackBridge.prototype.processSubtypedMessage = (function () {                                                        // 3
		function processSubtypedMessage(room, user, message) {                                                              // 284
			var msgObj = null;                                                                                                 // 285
			switch (message.subtype) {                                                                                         // 286
				case 'bot_message':                                                                                               // 287
					if (message.username !== undefined && this.excludeBotnames && message.username.match(this.excludeBotnames)) {    // 288
						return;                                                                                                         // 289
					}                                                                                                                //
                                                                                                                      //
					msgObj = {                                                                                                       // 292
						msg: this.convertSlackMessageToRocketChat(message.text),                                                        // 293
						rid: room._id,                                                                                                  // 294
						bot: true,                                                                                                      // 295
						attachments: message.attachments,                                                                               // 296
						username: message.username                                                                                      // 297
					};                                                                                                               //
					this.addAlias(message.username, msgObj);                                                                         // 299
					if (message.icons) {                                                                                             // 300
						msgObj.emoji = message.icons.emoji;                                                                             // 301
					}                                                                                                                //
					return msgObj;                                                                                                   // 303
				case 'me_message':                                                                                                // 303
					return this.addAlias(user.username, {                                                                            // 305
						msg: '_' + this.convertSlackMessageToRocketChat(message.text) + '_'                                             // 306
					});                                                                                                              //
				case 'message_changed':                                                                                           // 307
					this.editMessage(room, user, message);                                                                           // 309
					return;                                                                                                          // 310
				case 'message_deleted':                                                                                           // 311
					msgObj = RocketChat.models.Messages.findOneById(message.channel + 'S' + message.deleted_ts);                     // 312
					if (msgObj) {                                                                                                    // 313
						Meteor.runAsUser(user._id, function () {                                                                        // 314
							Meteor.call('deleteMessage', msgObj);                                                                          // 315
						});                                                                                                             //
					}                                                                                                                //
					return;                                                                                                          // 318
				case 'channel_join':                                                                                              // 318
					return this.joinRoom(room, user);                                                                                // 320
				case 'group_join':                                                                                                // 320
					if (message.inviter) {                                                                                           // 322
						var inviter = message.inviter ? this.findUser(message.inviter) || this.addUser(message.inviter) : null;         // 323
						if (inviter) {                                                                                                  // 324
							return this.joinPrivateGroup(inviter, room, user);                                                             // 325
						}                                                                                                               //
					}                                                                                                                //
					break;                                                                                                           // 328
				case 'channel_leave':                                                                                             // 329
				case 'group_leave':                                                                                               // 330
					return this.leaveRoom(room, user);                                                                               // 331
				case 'channel_topic':                                                                                             // 332
				case 'group_topic':                                                                                               // 333
					this.setRoomTopic(room, user, message.topic);                                                                    // 334
					return;                                                                                                          // 335
				case 'channel_purpose':                                                                                           // 335
				case 'group_purpose':                                                                                             // 337
					this.setRoomTopic(room, user, message.purpose);                                                                  // 338
					return;                                                                                                          // 339
				case 'channel_name':                                                                                              // 340
				case 'group_name':                                                                                                // 341
					this.setRoomName(room, user, message.name);                                                                      // 342
					return;                                                                                                          // 343
				case 'channel_archive':                                                                                           // 344
				case 'group_archive':                                                                                             // 345
					this.archiveRoom(room, user);                                                                                    // 346
					return;                                                                                                          // 347
				case 'channel_unarchive':                                                                                         // 347
				case 'group_unarchive':                                                                                           // 349
					this.unarchiveRoom(room, user);                                                                                  // 350
					return;                                                                                                          // 351
				case 'file_share':                                                                                                // 352
					if (message.file && message.file.url_private_download !== undefined) {                                           // 353
						var details = {                                                                                                 // 354
							message_id: 'slack-' + message.ts.replace(/\./g, '-'),                                                         // 355
							name: message.file.name,                                                                                       // 356
							size: message.file.size,                                                                                       // 357
							type: message.file.mimetype,                                                                                   // 358
							rid: room._id                                                                                                  // 359
						};                                                                                                              //
						return this.uploadFile(details, message.file.url_private_download, user, room, new Date(parseInt(message.ts.split('.')[0]) * 1000));
					}                                                                                                                //
					break;                                                                                                           // 363
				case 'file_comment':                                                                                              // 364
					logger.events.error('File comment not implemented');                                                             // 365
					return;                                                                                                          // 366
				case 'file_mention':                                                                                              // 366
					logger.events.error('File mentioned not implemented');                                                           // 368
					return;                                                                                                          // 369
				case 'pinned_item':                                                                                               // 369
					if (message.attachments && message.attachments[0] && message.attachments[0].text) {                              // 371
						msgObj = {                                                                                                      // 372
							rid: room._id,                                                                                                 // 373
							t: 'message_pinned',                                                                                           // 374
							msg: '',                                                                                                       // 375
							u: {                                                                                                           // 376
								_id: user._id,                                                                                                // 377
								username: user.username                                                                                       // 378
							},                                                                                                             //
							attachments: [{                                                                                                // 380
								'text': this.convertSlackMessageToRocketChat(message.attachments[0].text),                                    // 381
								'author_name': message.attachments[0].author_subname,                                                         // 382
								'author_icon': getAvatarUrlFromUsername(message.attachments[0].author_subname),                               // 383
								'ts': new Date(parseInt(message.attachments[0].ts.split('.')[0]) * 1000)                                      // 384
							}]                                                                                                             //
						};                                                                                                              //
                                                                                                                      //
						RocketChat.models.Messages.setPinnedByIdAndUserId('slack-' + message.attachments[0].channel_id + '-' + message.attachments[0].ts.replace(/\./g, '-'), msgObj.u, true, new Date(parseInt(message.ts.split('.')[0]) * 1000));
                                                                                                                      //
						return msgObj;                                                                                                  // 390
					} else {                                                                                                         //
						logger.events.error('Pinned item with no attachment');                                                          // 392
					}                                                                                                                //
					return;                                                                                                          // 394
				case 'unpinned_item':                                                                                             // 394
					logger.events.error('Unpinned item not implemented');                                                            // 396
					return;                                                                                                          // 397
			}                                                                                                                  // 397
		}                                                                                                                   //
                                                                                                                      //
		return processSubtypedMessage;                                                                                      //
	})();                                                                                                                //
                                                                                                                      //
	/**                                                                                                                  //
 * Archives a room                                                                                                    //
 **/                                                                                                                  //
                                                                                                                      //
	SlackBridge.prototype.archiveRoom = (function () {                                                                   // 3
		function archiveRoom(room, user) {                                                                                  // 404
			Meteor.runAsUser(user._id, function () {                                                                           // 405
				return Meteor.call('archiveRoom', room._id);                                                                      // 406
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return archiveRoom;                                                                                                 //
	})();                                                                                                                //
                                                                                                                      //
	/**                                                                                                                  //
 * Unarchives a room                                                                                                  //
 **/                                                                                                                  //
                                                                                                                      //
	SlackBridge.prototype.unarchiveRoom = (function () {                                                                 // 3
		function unarchiveRoom(room, user) {                                                                                // 413
			Meteor.runAsUser(user._id, function () {                                                                           // 414
				return Meteor.call('unarchiveRoom', room._id);                                                                    // 415
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return unarchiveRoom;                                                                                               //
	})();                                                                                                                //
                                                                                                                      //
	/**                                                                                                                  //
 * Adds user to room and sends a message                                                                              //
 **/                                                                                                                  //
                                                                                                                      //
	SlackBridge.prototype.joinRoom = (function () {                                                                      // 3
		function joinRoom(room, user) {                                                                                     // 422
			Meteor.runAsUser(user._id, function () {                                                                           // 423
				return Meteor.call('joinRoom', room._id);                                                                         // 424
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return joinRoom;                                                                                                    //
	})();                                                                                                                //
                                                                                                                      //
	/**                                                                                                                  //
 * Adds user to room and sends a message                                                                              //
 **/                                                                                                                  //
                                                                                                                      //
	SlackBridge.prototype.joinPrivateGroup = (function () {                                                              // 3
		function joinPrivateGroup(inviter, room, user) {                                                                    // 431
			Meteor.runAsUser(inviter._id, function () {                                                                        // 432
				return Meteor.call('addUserToRoom', { rid: room._id, username: user.username });                                  // 433
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return joinPrivateGroup;                                                                                            //
	})();                                                                                                                //
                                                                                                                      //
	/**                                                                                                                  //
 * Removes user from room and sends a message                                                                         //
 **/                                                                                                                  //
                                                                                                                      //
	SlackBridge.prototype.leaveRoom = (function () {                                                                     // 3
		function leaveRoom(room, user) {                                                                                    // 440
			Meteor.runAsUser(user._id, function () {                                                                           // 441
				return Meteor.call('leaveRoom', room._id);                                                                        // 442
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return leaveRoom;                                                                                                   //
	})();                                                                                                                //
                                                                                                                      //
	/**                                                                                                                  //
 * Sets room topic                                                                                                    //
 **/                                                                                                                  //
                                                                                                                      //
	SlackBridge.prototype.setRoomTopic = (function () {                                                                  // 3
		function setRoomTopic(room, user, topic) {                                                                          // 449
			Meteor.runAsUser(user._id, function () {                                                                           // 450
				return Meteor.call('saveRoomSettings', room._id, 'roomTopic', topic);                                             // 451
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return setRoomTopic;                                                                                                //
	})();                                                                                                                //
                                                                                                                      //
	/**                                                                                                                  //
 * Sets room name                                                                                                     //
 **/                                                                                                                  //
                                                                                                                      //
	SlackBridge.prototype.setRoomName = (function () {                                                                   // 3
		function setRoomName(room, user, name) {                                                                            // 458
			Meteor.runAsUser(user._id, function () {                                                                           // 459
				return Meteor.call('saveRoomSettings', room._id, 'roomName', name);                                               // 460
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return setRoomName;                                                                                                 //
	})();                                                                                                                //
                                                                                                                      //
	/**                                                                                                                  //
 * Edits a message                                                                                                    //
 **/                                                                                                                  //
                                                                                                                      //
	SlackBridge.prototype.editMessage = (function () {                                                                   // 3
		function editMessage(room, user, message) {                                                                         // 467
			var msgObj = {                                                                                                     // 468
				_id: message.channel + 'S' + message.message.ts,                                                                  // 469
				rid: room._id,                                                                                                    // 470
				msg: this.convertSlackMessageToRocketChat(message.message.text)                                                   // 471
			};                                                                                                                 //
			Meteor.runAsUser(user._id, function () {                                                                           // 473
				return Meteor.call('updateMessage', msgObj);                                                                      // 474
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return editMessage;                                                                                                 //
	})();                                                                                                                //
                                                                                                                      //
	/**                                                                                                                  //
 Uploads the file to the storage.                                                                                     //
 @param [Object] details an object with details about the upload. name, size, type, and rid                           //
 @param [String] fileUrl url of the file to download/import                                                           //
 @param [Object] user the Rocket.Chat user                                                                            //
 @param [Object] room the Rocket.Chat room                                                                            //
 @param [Date] timeStamp the timestamp the file was uploaded                                                          //
 **/                                                                                                                  //
                                                                                                                      //
	SlackBridge.prototype.uploadFile = (function () {                                                                    // 3
		function uploadFile(details, fileUrl, user, room, timeStamp) {                                                      // 486
			var url = Npm.require('url');                                                                                      // 487
			var requestModule = /https/i.test(fileUrl) ? Npm.require('https') : Npm.require('http');                           // 488
			var parsedUrl = url.parse(fileUrl, true);                                                                          // 489
			parsedUrl.headers = { 'Authorization': 'Bearer ' + this.apiToken };                                                // 490
			requestModule.get(parsedUrl, Meteor.bindEnvironment(function (stream) {                                            // 491
				var fileId = Meteor.fileStore.create(details);                                                                    // 492
				if (fileId) {                                                                                                     // 493
					Meteor.fileStore.write(stream, fileId, function (err, file) {                                                    // 494
						console.log('fileStore.write', file);                                                                           // 495
						if (err) {                                                                                                      // 496
							throw new Error(err);                                                                                          // 497
						} else {                                                                                                        //
							var _url = file.url.replace(Meteor.absoluteUrl(), '/');                                                        // 499
							var attachment = {                                                                                             // 500
								title: 'File Uploaded: ' + file.name,                                                                         // 501
								title_link: _url                                                                                              // 502
							};                                                                                                             //
                                                                                                                      //
							if (/^image\/.+/.test(file.type)) {                                                                            // 505
								attachment.image_url = _url;                                                                                  // 506
								attachment.image_type = file.type;                                                                            // 507
								attachment.image_size = file.size;                                                                            // 508
								attachment.image_dimensions = file.identify && file.identify.size;                                            // 509
							}                                                                                                              //
							if (/^audio\/.+/.test(file.type)) {                                                                            // 511
								attachment.audio_url = _url;                                                                                  // 512
								attachment.audio_type = file.type;                                                                            // 513
								attachment.audio_size = file.size;                                                                            // 514
							}                                                                                                              //
							if (/^video\/.+/.test(file.type)) {                                                                            // 516
								attachment.video_url = _url;                                                                                  // 517
								attachment.video_type = file.type;                                                                            // 518
								attachment.video_size = file.size;                                                                            // 519
							}                                                                                                              //
                                                                                                                      //
							var msg = {                                                                                                    // 522
								rid: details.rid,                                                                                             // 523
								ts: timeStamp,                                                                                                // 524
								msg: '',                                                                                                      // 525
								file: {                                                                                                       // 526
									_id: file._id                                                                                                // 527
								},                                                                                                            //
								groupable: false,                                                                                             // 529
								attachments: [attachment]                                                                                     // 530
							};                                                                                                             //
                                                                                                                      //
							if (details.message_id && typeof details.message_id === 'string') {                                            // 533
								msg['_id'] = details.message_id;                                                                              // 534
							}                                                                                                              //
                                                                                                                      //
							return RocketChat.sendMessage(user, msg, room, true);                                                          // 537
						}                                                                                                               //
					});                                                                                                              //
				}                                                                                                                 //
			}));                                                                                                               //
		}                                                                                                                   //
                                                                                                                      //
		return uploadFile;                                                                                                  //
	})();                                                                                                                //
                                                                                                                      //
	SlackBridge.prototype.setEvents = (function () {                                                                     // 3
		function setEvents() {                                                                                              // 544
			var _this5 = this;                                                                                                 //
                                                                                                                      //
			var CLIENT_EVENTS = this.slackClient.CLIENT_EVENTS;                                                                // 545
			this.rtm.on(CLIENT_EVENTS.RTM.AUTHENTICATED, function () {                                                         // 546
				logger.connection.info('Connected');                                                                              // 547
			});                                                                                                                //
                                                                                                                      //
			this.rtm.on(CLIENT_EVENTS.RTM.UNABLE_TO_RTM_START, function () {                                                   // 550
				_this5.disconnect();                                                                                              // 551
			});                                                                                                                //
                                                                                                                      //
			this.rtm.on(CLIENT_EVENTS.RTM.DISCONNECT, function () {                                                            // 554
				_this5.disconnect();                                                                                              // 555
			});                                                                                                                //
                                                                                                                      //
			var RTM_EVENTS = this.slackClient.RTM_EVENTS;                                                                      // 558
                                                                                                                      //
			/**                                                                                                                //
   * Event fired when someone messages a channel the bot is in                                                        //
   * {                                                                                                                //
   *	type: 'message',                                                                                                 //
   * 	channel: [channel_id],                                                                                          //
   * 	user: [user_id],                                                                                                //
   * 	text: [message],                                                                                                //
   * 	ts: [ts.milli],                                                                                                 //
   * 	team: [team_id],                                                                                                //
   * 	subtype: [message_subtype],                                                                                     //
   * 	inviter: [message_subtype = 'group_join|channel_join' -> user_id]                                               //
   * }                                                                                                                //
   **/                                                                                                                //
			this.rtm.on(RTM_EVENTS.MESSAGE, Meteor.bindEnvironment(function (message) {                                        // 573
				logger.events.debug('MESSAGE: ', message);                                                                        // 574
				if (message) {                                                                                                    // 575
					_this5.saveMessage(message);                                                                                     // 576
				}                                                                                                                 //
			}));                                                                                                               //
                                                                                                                      //
			/**                                                                                                                //
   * Event fired when someone creates a public channel                                                                //
   * {                                                                                                                //
   *	type: 'channel_created',                                                                                         //
   *	channel: {                                                                                                       //
   *		id: [channel_id],                                                                                               //
   *		is_channel: true,                                                                                               //
   *		name: [channel_name],                                                                                           //
   *		created: [ts],                                                                                                  //
   *		creator: [user_id],                                                                                             //
   *		is_shared: false,                                                                                               //
   *		is_org_shared: false                                                                                            //
   *	},                                                                                                               //
   *	event_ts: [ts.milli]                                                                                             //
   * }                                                                                                                //
   **/                                                                                                                //
			this.rtm.on(RTM_EVENTS.CHANNEL_CREATED, Meteor.bindEnvironment(function () {}));                                   // 596
                                                                                                                      //
			/**                                                                                                                //
   * Event fired when the bot joins a public channel                                                                  //
   * {                                                                                                                //
   * 	type: 'channel_joined',                                                                                         //
   * 	channel: {                                                                                                      //
   * 		id: [channel_id],                                                                                              //
   * 		name: [channel_name],                                                                                          //
   * 		is_channel: true,                                                                                              //
   * 		created: [ts],                                                                                                 //
   * 		creator: [user_id],                                                                                            //
   * 		is_archived: false,                                                                                            //
   * 		is_general: false,                                                                                             //
   * 		is_member: true,                                                                                               //
   * 		last_read: [ts.milli],                                                                                         //
   * 		latest: [message_obj],                                                                                         //
   * 		unread_count: 0,                                                                                               //
   * 		unread_count_display: 0,                                                                                       //
   * 		members: [ user_ids ],                                                                                         //
   * 		topic: {                                                                                                       //
   * 			value: [channel_topic],                                                                                       //
   * 			creator: [user_id],                                                                                           //
   * 			last_set: 0                                                                                                   //
   * 		},                                                                                                             //
   * 		purpose: {                                                                                                     //
   * 			value: [channel_purpose],                                                                                     //
   * 			creator: [user_id],                                                                                           //
   * 			last_set: 0                                                                                                   //
   * 		}                                                                                                              //
   * 	}                                                                                                               //
   * }                                                                                                                //
   **/                                                                                                                //
			this.rtm.on(RTM_EVENTS.CHANNEL_JOINED, Meteor.bindEnvironment(function () {}));                                    // 629
                                                                                                                      //
			/**                                                                                                                //
   * Event fired when the bot leaves (or is removed from) a public channel                                            //
   * {                                                                                                                //
   * 	type: 'channel_left',                                                                                           //
   * 	channel: [channel_id]                                                                                           //
   * }                                                                                                                //
   **/                                                                                                                //
			this.rtm.on(RTM_EVENTS.CHANNEL_LEFT, Meteor.bindEnvironment(function () {}));                                      // 638
                                                                                                                      //
			/**                                                                                                                //
   * Event fired when an archived channel is deleted by an admin                                                      //
   * {                                                                                                                //
   * 	type: 'channel_deleted',                                                                                        //
   * 	channel: [channel_id],                                                                                          //
   *	event_ts: [ts.milli]                                                                                             //
   * }                                                                                                                //
   **/                                                                                                                //
			this.rtm.on(RTM_EVENTS.CHANNEL_DELETED, Meteor.bindEnvironment(function () {}));                                   // 648
                                                                                                                      //
			/**                                                                                                                //
   * Event fired when the channel has its name changed                                                                //
   * {                                                                                                                //
   * 	type: 'channel_rename',                                                                                         //
   * 	channel: {                                                                                                      //
   * 		id: [channel_id],                                                                                              //
   * 		name: [channel_name],                                                                                          //
   * 		is_channel: true,                                                                                              //
   * 		created: [ts]                                                                                                  //
   * 	},                                                                                                              //
   *	event_ts: [ts.milli]                                                                                             //
   * }                                                                                                                //
   **/                                                                                                                //
			this.rtm.on(RTM_EVENTS.CHANNEL_RENAME, Meteor.bindEnvironment(function () {}));                                    // 663
                                                                                                                      //
			/**                                                                                                                //
   * Event fired when the bot joins a private channel                                                                 //
   * {                                                                                                                //
   * 	type: 'group_joined',                                                                                           //
   * 	channel: {                                                                                                      //
   * 		id: [channel_id],                                                                                              //
   * 		name: [channel_name],                                                                                          //
   * 		is_group: true,                                                                                                //
   * 		created: [ts],                                                                                                 //
   * 		creator: [user_id],                                                                                            //
   * 		is_archived: false,                                                                                            //
   * 		is_mpim: false,                                                                                                //
   * 		is_open: true,                                                                                                 //
   * 		last_read: [ts.milli],                                                                                         //
   * 		latest: [message_obj],                                                                                         //
   * 		unread_count: 0,                                                                                               //
   * 		unread_count_display: 0,                                                                                       //
   * 		members: [ user_ids ],                                                                                         //
   * 		topic: {                                                                                                       //
   * 			value: [channel_topic],                                                                                       //
   * 			creator: [user_id],                                                                                           //
   * 			last_set: 0                                                                                                   //
   * 		},                                                                                                             //
   * 		purpose: {                                                                                                     //
   * 			value: [channel_purpose],                                                                                     //
   * 			creator: [user_id],                                                                                           //
   * 			last_set: 0                                                                                                   //
   * 		}                                                                                                              //
   * 	}                                                                                                               //
   * }                                                                                                                //
   **/                                                                                                                //
			this.rtm.on(RTM_EVENTS.GROUP_JOINED, Meteor.bindEnvironment(function () {}));                                      // 696
                                                                                                                      //
			/**                                                                                                                //
   * Event fired when the bot leaves (or is removed from) a private channel                                           //
   * {                                                                                                                //
   * 	type: 'group_left',                                                                                             //
   * 	channel: [channel_id]                                                                                           //
   * }                                                                                                                //
   **/                                                                                                                //
			this.rtm.on(RTM_EVENTS.GROUP_LEFT, Meteor.bindEnvironment(function () {}));                                        // 705
                                                                                                                      //
			/**                                                                                                                //
   * Event fired when the private channel has its name changed                                                        //
   * {                                                                                                                //
   * 	type: 'group_rename',                                                                                           //
   * 	channel: {                                                                                                      //
   * 		id: [channel_id],                                                                                              //
   * 		name: [channel_name],                                                                                          //
   * 		is_group: true,                                                                                                //
   * 		created: [ts]                                                                                                  //
   * 	},                                                                                                              //
   *	event_ts: [ts.milli]                                                                                             //
   * }                                                                                                                //
   **/                                                                                                                //
			this.rtm.on(RTM_EVENTS.GROUP_RENAME, Meteor.bindEnvironment(function () {}));                                      // 720
                                                                                                                      //
			/**                                                                                                                //
   * Event fired when a new user joins the team                                                                       //
   * {                                                                                                                //
   * 	type: 'team_join',                                                                                              //
   * 	user:                                                                                                           //
   * 	{                                                                                                               //
   * 		id: [user_id],                                                                                                 //
   * 		team_id: [team_id],                                                                                            //
   * 		name: [user_name],                                                                                             //
   * 		deleted: false,                                                                                                //
   * 		status: null,                                                                                                  //
   * 		color: [color_code],                                                                                           //
   * 		real_name: '',                                                                                                 //
   * 		tz: [timezone],                                                                                                //
   * 		tz_label: [timezone_label],                                                                                    //
   * 		tz_offset: [timezone_offset],                                                                                  //
   * 		profile:                                                                                                       //
   * 		{                                                                                                              //
   * 			avatar_hash: '',                                                                                              //
   * 			real_name: '',                                                                                                //
   * 			real_name_normalized: '',                                                                                     //
   * 			email: '',                                                                                                    //
   * 			image_24: '',                                                                                                 //
   * 			image_32: '',                                                                                                 //
   * 			image_48: '',                                                                                                 //
   * 			image_72: '',                                                                                                 //
   * 			image_192: '',                                                                                                //
   * 			image_512: '',                                                                                                //
   * 			fields: null                                                                                                  //
   * 		},                                                                                                             //
   * 		is_admin: false,                                                                                               //
   * 		is_owner: false,                                                                                               //
   * 		is_primary_owner: false,                                                                                       //
   * 		is_restricted: false,                                                                                          //
   * 		is_ultra_restricted: false,                                                                                    //
   * 		is_bot: false,                                                                                                 //
   * 		presence: [user_presence]                                                                                      //
   * 	},                                                                                                              //
   * 	cache_ts: [ts]                                                                                                  //
   * }                                                                                                                //
   **/                                                                                                                //
			this.rtm.on(RTM_EVENTS.TEAM_JOIN, Meteor.bindEnvironment(function () {}));                                         // 763
		}                                                                                                                   //
                                                                                                                      //
		return setEvents;                                                                                                   //
	})();                                                                                                                //
                                                                                                                      //
	SlackBridge.prototype.findSlackChannel = (function () {                                                              // 3
		function findSlackChannel(name) {                                                                                   // 766
			logger['class'].debug('Searching for Slack channel or group', name);                                               // 767
			var response = HTTP.get('https://slack.com/api/channels.list', { params: { token: this.apiToken } });              // 768
			if (response && response.data && _.isArray(response.data.channels) && response.data.channels.length > 0) {         // 769
				for (var _iterator2 = response.data.channels, _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
					var _ref2;                                                                                                       //
                                                                                                                      //
					if (_isArray2) {                                                                                                 //
						if (_i2 >= _iterator2.length) break;                                                                            //
						_ref2 = _iterator2[_i2++];                                                                                      //
					} else {                                                                                                         //
						_i2 = _iterator2.next();                                                                                        //
						if (_i2.done) break;                                                                                            //
						_ref2 = _i2.value;                                                                                              //
					}                                                                                                                //
                                                                                                                      //
					var channel = _ref2;                                                                                             //
                                                                                                                      //
					if (channel.name === name && channel.is_member === true) {                                                       // 771
						return channel;                                                                                                 // 772
					}                                                                                                                //
				}                                                                                                                 //
			}                                                                                                                  //
			response = HTTP.get('https://slack.com/api/groups.list', { params: { token: this.apiToken } });                    // 776
			if (response && response.data && _.isArray(response.data.groups) && response.data.groups.length > 0) {             // 777
				for (var _iterator3 = response.data.groups, _isArray3 = Array.isArray(_iterator3), _i3 = 0, _iterator3 = _isArray3 ? _iterator3 : _iterator3[Symbol.iterator]();;) {
					var _ref3;                                                                                                       //
                                                                                                                      //
					if (_isArray3) {                                                                                                 //
						if (_i3 >= _iterator3.length) break;                                                                            //
						_ref3 = _iterator3[_i3++];                                                                                      //
					} else {                                                                                                         //
						_i3 = _iterator3.next();                                                                                        //
						if (_i3.done) break;                                                                                            //
						_ref3 = _i3.value;                                                                                              //
					}                                                                                                                //
                                                                                                                      //
					var group = _ref3;                                                                                               //
                                                                                                                      //
					if (group.name === name) {                                                                                       // 779
						return group;                                                                                                   // 780
					}                                                                                                                //
				}                                                                                                                 //
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return findSlackChannel;                                                                                            //
	})();                                                                                                                //
                                                                                                                      //
	SlackBridge.prototype.importFromHistory = (function () {                                                             // 3
		function importFromHistory(family, options) {                                                                       // 786
			var response = HTTP.get('https://slack.com/api/' + family + '.history', { params: _.extend({ token: this.apiToken }, options) });
			if (response && response.data && _.isArray(response.data.messages) && response.data.messages.length > 0) {         // 788
				var latest = 0;                                                                                                   // 789
				for (var _iterator4 = response.data.messages.reverse(), _isArray4 = Array.isArray(_iterator4), _i4 = 0, _iterator4 = _isArray4 ? _iterator4 : _iterator4[Symbol.iterator]();;) {
					var _ref4;                                                                                                       //
                                                                                                                      //
					if (_isArray4) {                                                                                                 //
						if (_i4 >= _iterator4.length) break;                                                                            //
						_ref4 = _iterator4[_i4++];                                                                                      //
					} else {                                                                                                         //
						_i4 = _iterator4.next();                                                                                        //
						if (_i4.done) break;                                                                                            //
						_ref4 = _i4.value;                                                                                              //
					}                                                                                                                //
                                                                                                                      //
					var message = _ref4;                                                                                             //
                                                                                                                      //
					logger['class'].debug('MESSAGE: ', message);                                                                     // 791
					if (!latest || message.ts > latest) {                                                                            // 792
						latest = message.ts;                                                                                            // 793
					}                                                                                                                //
					message.channel = options.channel;                                                                               // 795
					this.saveMessage(message);                                                                                       // 796
				}                                                                                                                 //
				return { has_more: response.data.has_more, ts: latest };                                                          // 798
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return importFromHistory;                                                                                           //
	})();                                                                                                                //
                                                                                                                      //
	SlackBridge.prototype.importMessages = (function () {                                                                // 3
		function importMessages(rid, callback) {                                                                            // 802
			logger['class'].info('importMessages: ', rid);                                                                     // 803
			var rocketchat_room = RocketChat.models.Rooms.findOneById(rid);                                                    // 804
			if (rocketchat_room) {                                                                                             // 805
				if (this.channelMap[rid]) {                                                                                       // 806
					logger['class'].debug('Importing messages from Slack to Rocket.Chat', this.channelMap[rid], rid);                // 807
					var results = this.importFromHistory(this.channelMap[rid].family, { channel: this.channelMap[rid].id, oldest: 1 });
					while (results && results.has_more) {                                                                            // 809
						results = this.importFromHistory(this.channelMap[rid].family, { channel: this.channelMap[rid].id, oldest: results.ts });
					}                                                                                                                //
					return callback();                                                                                               // 812
				} else {                                                                                                          //
					var slack_room = this.findSlackChannel(rocketchat_room.name);                                                    // 814
					if (slack_room) {                                                                                                // 815
						this.channelMap[rid] = { id: slack_room.id, family: slack_room.id.charAt(0) === 'C' ? 'channels' : 'groups' };  // 816
						this.importMessages(rid, callback);                                                                             // 817
					} else {                                                                                                         //
						logger['class'].error('Could not find Slack room with specified name', rocketchat_room.name);                   // 819
						return callback(new Meteor.Error('error-slack-room-not-found', 'Could not find Slack room with specified name'));
					}                                                                                                                //
				}                                                                                                                 //
			} else {                                                                                                           //
				logger['class'].error('Could not find Rocket.Chat room with specified id', rid);                                  // 824
				return callback(new Meteor.Error('error-invalid-room', 'Invalid room'));                                          // 825
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return importMessages;                                                                                              //
	})();                                                                                                                //
                                                                                                                      //
	return SlackBridge;                                                                                                  //
})();                                                                                                                 //
                                                                                                                      //
RocketChat.SlackBridge = new SlackBridge();                                                                           // 830
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/rocketchat_slackbridge/slashcommand/slackbridge_import.server.js                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function SlackBridgeImport(command, params, item) {                                                                   // 1
	var channel, room, user;                                                                                             // 2
	if (command !== 'slackbridge-import' || !Match.test(params, String)) {                                               // 3
		return;                                                                                                             // 4
	}                                                                                                                    //
	room = RocketChat.models.Rooms.findOneById(item.rid);                                                                // 6
	channel = room.name;                                                                                                 // 7
	user = Meteor.users.findOne(Meteor.userId());                                                                        // 8
	RocketChat.Notifications.notifyUser(Meteor.userId(), 'message', {                                                    // 9
		_id: Random.id(),                                                                                                   // 10
		rid: item.rid,                                                                                                      // 11
		ts: new Date(),                                                                                                     // 12
		msg: TAPi18n.__('SlackBridge_is_importing_your_messages_at_s_', {                                                   // 13
			postProcess: 'sprintf',                                                                                            // 14
			sprintf: [channel]                                                                                                 // 15
		}, user.language)                                                                                                   //
	});                                                                                                                  //
                                                                                                                      //
	RocketChat.SlackBridge.importMessages(item.rid, function (err) {                                                     // 19
		if (err) {                                                                                                          // 20
			RocketChat.Notifications.notifyUser(user._id, 'message', {                                                         // 21
				_id: Random.id(),                                                                                                 // 22
				rid: item.rid,                                                                                                    // 23
				ts: new Date(),                                                                                                   // 24
				msg: TAPi18n.__('SlackBridge_got_an_error_while_importing_your_messages_at_s__s_', {                              // 25
					postProcess: 'sprintf',                                                                                          // 26
					sprintf: [channel, err.message]                                                                                  // 27
				}, user.language)                                                                                                 //
			});                                                                                                                //
		} else {                                                                                                            //
			RocketChat.Notifications.notifyUser(user._id, 'message', {                                                         // 31
				_id: Random.id(),                                                                                                 // 32
				rid: item.rid,                                                                                                    // 33
				ts: new Date(),                                                                                                   // 34
				msg: TAPi18n.__('SlackBridge_has_finished_importing_your_messages_at_s_', {                                       // 35
					postProcess: 'sprintf',                                                                                          // 36
					sprintf: [channel]                                                                                               // 37
				}, user.language)                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
	});                                                                                                                  //
                                                                                                                      //
	return SlackBridgeImport;                                                                                            // 43
}                                                                                                                     //
                                                                                                                      //
RocketChat.slashCommands.add('slackbridge-import', SlackBridgeImport);                                                // 46
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:slackbridge'] = {};

})();

//# sourceMappingURL=rocketchat_slackbridge.js.map
