(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var ECMAScript = Package.ecmascript.ECMAScript;
var _ = Package.underscore._;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var Inject = Package['meteorhacks:inject-initial'].Inject;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;

var require = meteorInstall({"node_modules":{"meteor":{"rocketchat:ui-master":{"server":{"inject.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_ui-master/server/inject.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/* globals Inject */                                                                                                   // 1
                                                                                                                       //
Inject.rawBody('page-loading', '\n<style>\n.loading {\n\ttop: 0;\n\tright: 0;\n\tbottom: 0;\n\tleft: 0;\n\tdisplay: flex;\n\talign-items: center;\n\tposition: absolute;\n\tjustify-content: center;\n\ttext-align: center;\n}\n.loading > div {\n\twidth: 10px;\n\theight: 10px;\n\tmargin: 2px;\n\tborder-radius: 100%;\n\tdisplay: inline-block;\n\t-webkit-animation: loading-bouncedelay 1.4s infinite ease-in-out both;\n\tanimation: loading-bouncedelay 1.4s infinite ease-in-out both;\n}\n.loading .bounce1 {\n\t-webkit-animation-delay: -0.32s;\n\tanimation-delay: -0.32s;\n}\n.loading .bounce2 {\n\t-webkit-animation-delay: -0.16s;\n\tanimation-delay: -0.16s;\n}\n@-webkit-keyframes loading-bouncedelay {\n\t0%, 80%, 100% { -webkit-transform: scale(0) }\n\t40% { -webkit-transform: scale(1.0) }\n}\n@keyframes loading-bouncedelay {\n\t0%, 80%, 100% { transform: scale(0); }\n\t40% { transform: scale(1.0); }\n}\n</style>\n<div id="initial-page-loading" class="page-loading">\n\t<div class="loading">\n\t\t<div class="bounce1"></div>\n\t\t<div class="bounce2"></div>\n\t\t<div class="bounce3"></div>\n\t</div>\n</div>');
                                                                                                                       //
RocketChat.settings.get('theme-color-primary-background-color', function (key) {                                       // 51
	var value = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '#04436a';                            // 51
                                                                                                                       //
	Inject.rawHead(key, '<style>body { background-color: ' + value + ';}</style>');                                       // 52
});                                                                                                                    // 53
                                                                                                                       //
RocketChat.settings.get('theme-color-component-color', function (key) {                                                // 55
	var value = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '#cccccc';                            // 55
                                                                                                                       //
	Inject.rawHead(key, '<style>.loading > div { background-color: ' + value + ';}</style>');                             // 56
});                                                                                                                    // 57
                                                                                                                       //
RocketChat.settings.get('Accounts_ForgetUserSessionOnWindowClose', function (key, value) {                             // 59
	if (value) {                                                                                                          // 60
		Inject.rawModHtml(key, function (html) {                                                                             // 61
			var script = '\n\t\t\t\t<script>\n\t\t\t\t\tif (Meteor._localStorage._data === undefined && window.sessionStorage) {\n\t\t\t\t\t\tMeteor._localStorage = window.sessionStorage;\n\t\t\t\t\t}\n\t\t\t\t</script>\n\t\t\t';
			return html.replace(/<\/body>/, script + '\n</body>');                                                              // 69
		});                                                                                                                  // 70
	} else {                                                                                                              // 71
		Inject.rawModHtml(key, function (html) {                                                                             // 72
			return html;                                                                                                        // 73
		});                                                                                                                  // 74
	}                                                                                                                     // 75
});                                                                                                                    // 76
                                                                                                                       //
RocketChat.settings.get('Site_Name', function (key) {                                                                  // 78
	var value = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'Rocket.Chat';                        // 78
                                                                                                                       //
	Inject.rawHead(key, '<title>' + value + '</title>' + ('<meta name="application-name" content="' + value + '">') + ('<meta name="apple-mobile-web-app-title" content="' + value + '">'));
});                                                                                                                    // 83
                                                                                                                       //
RocketChat.settings.get('Meta_language', function (key) {                                                              // 85
	var value = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';                                   // 85
                                                                                                                       //
	Inject.rawHead(key, '<meta http-equiv="content-language" content="' + value + '">' + ('<meta name="language" content="' + value + '">'));
});                                                                                                                    // 89
                                                                                                                       //
RocketChat.settings.get('Meta_robots', function (key) {                                                                // 91
	var value = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';                                   // 91
                                                                                                                       //
	Inject.rawHead(key, '<meta name="robots" content="' + value + '">');                                                  // 92
});                                                                                                                    // 93
                                                                                                                       //
RocketChat.settings.get('Meta_msvalidate01', function (key) {                                                          // 95
	var value = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';                                   // 95
                                                                                                                       //
	Inject.rawHead(key, '<meta name="msvalidate.01" content="' + value + '">');                                           // 96
});                                                                                                                    // 97
                                                                                                                       //
RocketChat.settings.get('Meta_google-site-verification', function (key) {                                              // 99
	var value = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';                                   // 99
                                                                                                                       //
	Inject.rawHead(key, '<meta name="google-site-verification" content="' + value + '" />');                              // 100
});                                                                                                                    // 101
                                                                                                                       //
RocketChat.settings.get('Meta_fb_app_id', function (key) {                                                             // 103
	var value = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';                                   // 103
                                                                                                                       //
	Inject.rawHead(key, '<meta property="fb:app_id" content="' + value + '">');                                           // 104
});                                                                                                                    // 105
                                                                                                                       //
RocketChat.settings.get('Meta_custom', function (key) {                                                                // 107
	var value = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';                                   // 107
                                                                                                                       //
	Inject.rawHead(key, value);                                                                                           // 108
});                                                                                                                    // 109
                                                                                                                       //
Meteor.defer(function () {                                                                                             // 111
	var baseUrl = void 0;                                                                                                 // 112
	if (__meteor_runtime_config__.ROOT_URL_PATH_PREFIX && __meteor_runtime_config__.ROOT_URL_PATH_PREFIX.trim() !== '') {
		baseUrl = __meteor_runtime_config__.ROOT_URL_PATH_PREFIX;                                                            // 114
	} else {                                                                                                              // 115
		baseUrl = '/';                                                                                                       // 116
	}                                                                                                                     // 117
	if (/\/$/.test(baseUrl) === false) {                                                                                  // 118
		baseUrl += '/';                                                                                                      // 119
	}                                                                                                                     // 120
	Inject.rawHead('base', '<base href="' + baseUrl + '">');                                                              // 121
});                                                                                                                    // 122
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}},{"extensions":[".js",".json",".coffee"]});
require("./node_modules/meteor/rocketchat:ui-master/server/inject.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:ui-master'] = {};

})();

//# sourceMappingURL=rocketchat_ui-master.js.map
