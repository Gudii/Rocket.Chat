(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var Importer = Package['rocketchat:importer'].Importer;
var Logger = Package['rocketchat:logger'].Logger;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;

var require = meteorInstall({"node_modules":{"meteor":{"rocketchat:importer-csv":{"server.js":["babel-runtime/helpers/slicedToArray","babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/rocketchat_importer-csv/server.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _slicedToArray;module.import('babel-runtime/helpers/slicedToArray',{"default":function(v){_slicedToArray=v}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});
                                                                                                                      //
                                                                                                                      //
                                                                                                                      //
/* globals Importer */                                                                                                // 1
                                                                                                                      //
Importer.CSV = function (_Importer$Base) {                                                                            // 3
	_inherits(ImporterCSV, _Importer$Base);                                                                              // 3
                                                                                                                      //
	function ImporterCSV(name, descriptionI18N, fileTypeRegex) {                                                         // 4
		_classCallCheck(this, ImporterCSV);                                                                                 // 4
                                                                                                                      //
		var _this = _possibleConstructorReturn(this, _Importer$Base.call(this, name, descriptionI18N, fileTypeRegex));      // 4
                                                                                                                      //
		_this.logger.debug('Constructed a new CSV Importer.');                                                              // 6
                                                                                                                      //
		_this.csvParser = Npm.require('csv-parse/lib/sync');                                                                // 8
		_this.messages = new Map();                                                                                         // 9
		return _this;                                                                                                       // 4
	}                                                                                                                    // 10
                                                                                                                      //
	ImporterCSV.prototype.prepare = function () {                                                                        // 3
		function prepare(dataURI, sentContentType, fileName) {                                                              // 3
			var _this2 = this;                                                                                                 // 12
                                                                                                                      //
			_Importer$Base.prototype.prepare.call(this, dataURI, sentContentType, fileName);                                   // 13
                                                                                                                      //
			var uriResult = RocketChatFile.dataURIParse(dataURI);                                                              // 15
			var zip = new this.AdmZip(new Buffer(uriResult.image, 'base64'));                                                  // 16
			var zipEntries = zip.getEntries();                                                                                 // 17
                                                                                                                      //
			var tempChannels = [];                                                                                             // 19
			var tempUsers = [];                                                                                                // 20
			var tempMessages = new Map();                                                                                      // 21
			for (var _iterator = zipEntries, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
				var _ref;                                                                                                         // 22
                                                                                                                      //
				if (_isArray) {                                                                                                   // 22
					if (_i >= _iterator.length) break;                                                                               // 22
					_ref = _iterator[_i++];                                                                                          // 22
				} else {                                                                                                          // 22
					_i = _iterator.next();                                                                                           // 22
					if (_i.done) break;                                                                                              // 22
					_ref = _i.value;                                                                                                 // 22
				}                                                                                                                 // 22
                                                                                                                      //
				var entry = _ref;                                                                                                 // 22
                                                                                                                      //
				this.logger.debug('Entry: ' + entry.entryName);                                                                   // 23
                                                                                                                      //
				//Ignore anything that has `__MACOSX` in it's name, as sadly these things seem to mess everything up              // 25
				if (entry.entryName.indexOf('__MACOSX') > -1) {                                                                   // 26
					this.logger.debug('Ignoring the file: ' + entry.entryName);                                                      // 27
					continue;                                                                                                        // 28
				}                                                                                                                 // 29
                                                                                                                      //
				//Directories are ignored, since they are "virtual" in a zip file                                                 // 31
				if (entry.isDirectory) {                                                                                          // 32
					this.logger.debug('Ignoring the directory entry: ' + entry.entryName);                                           // 33
					continue;                                                                                                        // 34
				}                                                                                                                 // 35
                                                                                                                      //
				//Parse the channels                                                                                              // 37
				if (entry.entryName.toLowerCase() === 'channels.csv') {                                                           // 38
					_Importer$Base.prototype.updateProgress.call(this, Importer.ProgressStep.PREPARING_CHANNELS);                    // 39
					var parsedChannels = this.csvParser(entry.getData().toString());                                                 // 40
					tempChannels = parsedChannels.map(function (c) {                                                                 // 41
						return {                                                                                                        // 42
							id: c[0].trim().replace('.', '_'),                                                                             // 43
							name: c[0].trim(),                                                                                             // 44
							creator: c[1].trim(),                                                                                          // 45
							isPrivate: c[2].trim().toLowerCase() === 'private' ? true : false,                                             // 46
							members: c[3].trim().split(';').map(function (m) {                                                             // 47
								return m.trim();                                                                                              // 47
							})                                                                                                             // 47
						};                                                                                                              // 42
					});                                                                                                              // 49
					continue;                                                                                                        // 50
				}                                                                                                                 // 51
                                                                                                                      //
				//Parse the users                                                                                                 // 53
				if (entry.entryName.toLowerCase() === 'users.csv') {                                                              // 54
					_Importer$Base.prototype.updateProgress.call(this, Importer.ProgressStep.PREPARING_USERS);                       // 55
					var parsedUsers = this.csvParser(entry.getData().toString());                                                    // 56
					tempUsers = parsedUsers.map(function (u) {                                                                       // 57
						return { id: u[0].trim().replace('.', '_'), username: u[0].trim(), email: u[1].trim(), name: u[2].trim() };     // 57
					});                                                                                                              // 57
					continue;                                                                                                        // 58
				}                                                                                                                 // 59
                                                                                                                      //
				//Parse the messages                                                                                              // 61
				if (entry.entryName.indexOf('/') > -1) {                                                                          // 62
					var item = entry.entryName.split('/'); //random/messages.csv                                                     // 63
					var channelName = item[0]; //random                                                                              // 64
					var msgGroupData = item[1].split('.')[0]; //2015-10-04                                                           // 65
                                                                                                                      //
					if (!tempMessages.get(channelName)) {                                                                            // 67
						tempMessages.set(channelName, new Map());                                                                       // 68
					}                                                                                                                // 69
                                                                                                                      //
					var msgs = [];                                                                                                   // 71
                                                                                                                      //
					try {                                                                                                            // 73
						msgs = this.csvParser(entry.getData().toString());                                                              // 74
					} catch (e) {                                                                                                    // 75
						this.logger.warn('The file ' + entry.entryName + ' contains invalid syntax', e);                                // 76
						continue;                                                                                                       // 77
					}                                                                                                                // 78
                                                                                                                      //
					tempMessages.get(channelName).set(msgGroupData, msgs.map(function (m) {                                          // 80
						return { username: m[0], ts: m[1], text: m[2] };                                                                // 80
					}));                                                                                                             // 80
					continue;                                                                                                        // 81
				}                                                                                                                 // 82
			}                                                                                                                  // 83
                                                                                                                      //
			// Insert the users record, eventually this might have to be split into several ones as well                       // 85
			// if someone tries to import a several thousands users instance                                                   // 86
			var usersId = this.collection.insert({ 'import': this.importRecord._id, 'importer': this.name, 'type': 'users', 'users': tempUsers });
			this.users = this.collection.findOne(usersId);                                                                     // 88
			_Importer$Base.prototype.updateRecord.call(this, { 'count.users': tempUsers.length });                             // 89
			_Importer$Base.prototype.addCountToTotal.call(this, tempUsers.length);                                             // 90
                                                                                                                      //
			// Insert the channels records.                                                                                    // 92
			var channelsId = this.collection.insert({ 'import': this.importRecord._id, 'importer': this.name, 'type': 'channels', 'channels': tempChannels });
			this.channels = this.collection.findOne(channelsId);                                                               // 94
			_Importer$Base.prototype.updateRecord.call(this, { 'count.channels': tempChannels.length });                       // 95
			_Importer$Base.prototype.addCountToTotal.call(this, tempChannels.length);                                          // 96
                                                                                                                      //
			// Save the messages records to the import record for `startImport` usage                                          // 98
			_Importer$Base.prototype.updateProgress.call(this, Importer.ProgressStep.PREPARING_MESSAGES);                      // 99
			var messagesCount = 0;                                                                                             // 100
                                                                                                                      //
			var _loop = function () {                                                                                          // 12
				function _loop(channel, messagesMap) {                                                                            // 12
					if (!_this2.messages.get(channel)) {                                                                             // 102
						_this2.messages.set(channel, new Map());                                                                        // 103
					}                                                                                                                // 104
                                                                                                                      //
					var _loop2 = function () {                                                                                       // 12
						function _loop2(_msgGroupData, _msgs) {                                                                         // 12
							messagesCount += _msgs.length;                                                                                 // 107
							_Importer$Base.prototype.updateRecord.call(_this2, { 'messagesstatus': channel + '/' + _msgGroupData });       // 108
                                                                                                                      //
							if (Importer.Base.getBSONSize(_msgs) > Importer.Base.MaxBSONSize) {                                            // 110
								Importer.Base.getBSONSafeArraysFromAnArray(_msgs).forEach(function (splitMsg, i) {                            // 111
									var messagesId = _this2.collection.insert({ 'import': _this2.importRecord._id, 'importer': _this2.name, 'type': 'messages', 'name': channel + '/' + _msgGroupData + '.' + i, 'messages': splitMsg });
									_this2.messages.get(channel).set(_msgGroupData + '.' + i, _this2.collection.findOne(messagesId));            // 113
								});                                                                                                           // 114
							} else {                                                                                                       // 115
								var messagesId = _this2.collection.insert({ 'import': _this2.importRecord._id, 'importer': _this2.name, 'type': 'messages', 'name': channel + '/' + _msgGroupData, 'messages': _msgs });
								_this2.messages.get(channel).set(_msgGroupData, _this2.collection.findOne(messagesId));                       // 117
							}                                                                                                              // 118
						}                                                                                                               // 12
                                                                                                                      //
						return _loop2;                                                                                                  // 12
					}();                                                                                                             // 12
                                                                                                                      //
					for (var _iterator3 = messagesMap.entries(), _isArray3 = Array.isArray(_iterator3), _i3 = 0, _iterator3 = _isArray3 ? _iterator3 : _iterator3[Symbol.iterator]();;) {
						var _ref7;                                                                                                      // 106
                                                                                                                      //
						if (_isArray3) {                                                                                                // 106
							if (_i3 >= _iterator3.length) break;                                                                           // 106
							_ref7 = _iterator3[_i3++];                                                                                     // 106
						} else {                                                                                                        // 106
							_i3 = _iterator3.next();                                                                                       // 106
							if (_i3.done) break;                                                                                           // 106
							_ref7 = _i3.value;                                                                                             // 106
						}                                                                                                               // 106
                                                                                                                      //
						var _ref5 = _ref7;                                                                                              // 106
                                                                                                                      //
						var _ref6 = _slicedToArray(_ref5, 2);                                                                           // 106
                                                                                                                      //
						var _msgGroupData = _ref6[0];                                                                                   // 106
						var _msgs = _ref6[1];                                                                                           // 106
                                                                                                                      //
						_loop2(_msgGroupData, _msgs);                                                                                   // 106
					}                                                                                                                // 119
				}                                                                                                                 // 12
                                                                                                                      //
				return _loop;                                                                                                     // 12
			}();                                                                                                               // 12
                                                                                                                      //
			for (var _iterator2 = tempMessages.entries(), _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
				var _ref4;                                                                                                        // 101
                                                                                                                      //
				if (_isArray2) {                                                                                                  // 101
					if (_i2 >= _iterator2.length) break;                                                                             // 101
					_ref4 = _iterator2[_i2++];                                                                                       // 101
				} else {                                                                                                          // 101
					_i2 = _iterator2.next();                                                                                         // 101
					if (_i2.done) break;                                                                                             // 101
					_ref4 = _i2.value;                                                                                               // 101
				}                                                                                                                 // 101
                                                                                                                      //
				var _ref2 = _ref4;                                                                                                // 101
                                                                                                                      //
				var _ref3 = _slicedToArray(_ref2, 2);                                                                             // 101
                                                                                                                      //
				var channel = _ref3[0];                                                                                           // 101
				var messagesMap = _ref3[1];                                                                                       // 101
                                                                                                                      //
				_loop(channel, messagesMap);                                                                                      // 101
			}                                                                                                                  // 120
                                                                                                                      //
			_Importer$Base.prototype.updateRecord.call(this, { 'count.messages': messagesCount, 'messagesstatus': null });     // 122
			_Importer$Base.prototype.addCountToTotal.call(this, messagesCount);                                                // 123
                                                                                                                      //
			//Ensure we have some users, channels, and messages                                                                // 125
			if (tempUsers.length === 0 || tempChannels.length === 0 || messagesCount === 0) {                                  // 126
				this.logger.warn('The loaded users count ' + tempUsers.length + ', the loaded channels ' + tempChannels.length + ', and the loaded messages ' + messagesCount);
				_Importer$Base.prototype.updateProgress.call(this, Importer.ProgressStep.ERROR);                                  // 128
				return _Importer$Base.prototype.getProgress.call(this);                                                           // 129
			}                                                                                                                  // 130
                                                                                                                      //
			var selectionUsers = tempUsers.map(function (u) {                                                                  // 132
				return new Importer.SelectionUser(u.id, u.username, u.email, false, false, true);                                 // 132
			});                                                                                                                // 132
			var selectionChannels = tempChannels.map(function (c) {                                                            // 133
				return new Importer.SelectionChannel(c.id, c.name, false, true, c.isPrivate);                                     // 133
			});                                                                                                                // 133
                                                                                                                      //
			_Importer$Base.prototype.updateProgress.call(this, Importer.ProgressStep.USER_SELECTION);                          // 135
			return new Importer.Selection(this.name, selectionUsers, selectionChannels);                                       // 136
		}                                                                                                                   // 137
                                                                                                                      //
		return prepare;                                                                                                     // 3
	}();                                                                                                                 // 3
                                                                                                                      //
	ImporterCSV.prototype.startImport = function () {                                                                    // 3
		function startImport(importSelection) {                                                                             // 3
			var _this3 = this;                                                                                                 // 139
                                                                                                                      //
			_Importer$Base.prototype.startImport.call(this, importSelection);                                                  // 140
			var started = Date.now();                                                                                          // 141
                                                                                                                      //
			//Ensure we're only going to import the users that the user has selected                                           // 143
			for (var _iterator4 = importSelection.users, _isArray4 = Array.isArray(_iterator4), _i4 = 0, _iterator4 = _isArray4 ? _iterator4 : _iterator4[Symbol.iterator]();;) {
				var _ref8;                                                                                                        // 144
                                                                                                                      //
				if (_isArray4) {                                                                                                  // 144
					if (_i4 >= _iterator4.length) break;                                                                             // 144
					_ref8 = _iterator4[_i4++];                                                                                       // 144
				} else {                                                                                                          // 144
					_i4 = _iterator4.next();                                                                                         // 144
					if (_i4.done) break;                                                                                             // 144
					_ref8 = _i4.value;                                                                                               // 144
				}                                                                                                                 // 144
                                                                                                                      //
				var user = _ref8;                                                                                                 // 144
                                                                                                                      //
				for (var _iterator12 = this.users.users, _isArray12 = Array.isArray(_iterator12), _i12 = 0, _iterator12 = _isArray12 ? _iterator12 : _iterator12[Symbol.iterator]();;) {
					var _ref20;                                                                                                      // 145
                                                                                                                      //
					if (_isArray12) {                                                                                                // 145
						if (_i12 >= _iterator12.length) break;                                                                          // 145
						_ref20 = _iterator12[_i12++];                                                                                   // 145
					} else {                                                                                                         // 145
						_i12 = _iterator12.next();                                                                                      // 145
						if (_i12.done) break;                                                                                           // 145
						_ref20 = _i12.value;                                                                                            // 145
					}                                                                                                                // 145
                                                                                                                      //
					var u = _ref20;                                                                                                  // 145
                                                                                                                      //
					if (u.id === user.user_id) {                                                                                     // 146
						u.do_import = user.do_import;                                                                                   // 147
					}                                                                                                                // 148
				}                                                                                                                 // 149
			}                                                                                                                  // 150
			this.collection.update({ _id: this.users._id }, { $set: { 'users': this.users.users } });                          // 151
                                                                                                                      //
			//Ensure we're only importing the channels the user has selected.                                                  // 153
			for (var _iterator5 = importSelection.channels, _isArray5 = Array.isArray(_iterator5), _i5 = 0, _iterator5 = _isArray5 ? _iterator5 : _iterator5[Symbol.iterator]();;) {
				var _ref9;                                                                                                        // 154
                                                                                                                      //
				if (_isArray5) {                                                                                                  // 154
					if (_i5 >= _iterator5.length) break;                                                                             // 154
					_ref9 = _iterator5[_i5++];                                                                                       // 154
				} else {                                                                                                          // 154
					_i5 = _iterator5.next();                                                                                         // 154
					if (_i5.done) break;                                                                                             // 154
					_ref9 = _i5.value;                                                                                               // 154
				}                                                                                                                 // 154
                                                                                                                      //
				var channel = _ref9;                                                                                              // 154
                                                                                                                      //
				for (var _iterator13 = this.channels.channels, _isArray13 = Array.isArray(_iterator13), _i13 = 0, _iterator13 = _isArray13 ? _iterator13 : _iterator13[Symbol.iterator]();;) {
					var _ref21;                                                                                                      // 155
                                                                                                                      //
					if (_isArray13) {                                                                                                // 155
						if (_i13 >= _iterator13.length) break;                                                                          // 155
						_ref21 = _iterator13[_i13++];                                                                                   // 155
					} else {                                                                                                         // 155
						_i13 = _iterator13.next();                                                                                      // 155
						if (_i13.done) break;                                                                                           // 155
						_ref21 = _i13.value;                                                                                            // 155
					}                                                                                                                // 155
                                                                                                                      //
					var c = _ref21;                                                                                                  // 155
                                                                                                                      //
					if (c.id === channel.channel_id) {                                                                               // 156
						c.do_import = channel.do_import;                                                                                // 157
					}                                                                                                                // 158
				}                                                                                                                 // 159
			}                                                                                                                  // 160
			this.collection.update({ _id: this.channels._id }, { $set: { 'channels': this.channels.channels } });              // 161
                                                                                                                      //
			var startedByUserId = Meteor.userId();                                                                             // 163
			Meteor.defer(function () {                                                                                         // 164
				_Importer$Base.prototype.updateProgress.call(_this3, Importer.ProgressStep.IMPORTING_USERS);                      // 165
				//Import the users                                                                                                // 166
                                                                                                                      //
				var _loop3 = function () {                                                                                        // 164
					function _loop3(u) {                                                                                             // 164
						if (!u.do_import) {                                                                                             // 168
							return 'continue';                                                                                             // 169
						}                                                                                                               // 170
                                                                                                                      //
						Meteor.runAsUser(startedByUserId, function () {                                                                 // 172
							var existantUser = RocketChat.models.Users.findOneByEmailAddress(u.email);                                     // 173
                                                                                                                      //
							//If we couldn't find one by their email address, try to find an existing user by their username               // 175
							if (!existantUser) {                                                                                           // 176
								existantUser = RocketChat.models.Users.findOneByUsername(u.username);                                         // 177
							}                                                                                                              // 178
                                                                                                                      //
							if (existantUser) {                                                                                            // 180
								//since we have an existing user, let's try a few things                                                      // 181
								u.rocketId = existantUser._id;                                                                                // 182
								RocketChat.models.Users.update({ _id: u.rocketId }, { $addToSet: { importIds: u.id } });                      // 183
							} else {                                                                                                       // 184
								(function () {                                                                                                // 184
									var userId = Accounts.createUser({ email: u.email, password: Date.now() + u.name + u.email.toUpperCase() });
									Meteor.runAsUser(userId, function () {                                                                       // 186
										Meteor.call('setUsername', u.username);                                                                     // 187
										Meteor.call('joinDefaultChannels', true);                                                                   // 188
										RocketChat.models.Users.setName(userId, u.name);                                                            // 189
										RocketChat.models.Users.update({ _id: userId }, { $addToSet: { importIds: u.id } });                        // 190
										u.rocketId = userId;                                                                                        // 191
									});                                                                                                          // 192
								})();                                                                                                         // 184
							}                                                                                                              // 193
                                                                                                                      //
							_Importer$Base.prototype.addCountCompleted.call(_this3, 1);                                                    // 195
						});                                                                                                             // 196
					}                                                                                                                // 164
                                                                                                                      //
					return _loop3;                                                                                                   // 164
				}();                                                                                                              // 164
                                                                                                                      //
				for (var _iterator6 = _this3.users.users, _isArray6 = Array.isArray(_iterator6), _i6 = 0, _iterator6 = _isArray6 ? _iterator6 : _iterator6[Symbol.iterator]();;) {
					var _ref10;                                                                                                      // 167
                                                                                                                      //
					if (_isArray6) {                                                                                                 // 167
						if (_i6 >= _iterator6.length) break;                                                                            // 167
						_ref10 = _iterator6[_i6++];                                                                                     // 167
					} else {                                                                                                         // 167
						_i6 = _iterator6.next();                                                                                        // 167
						if (_i6.done) break;                                                                                            // 167
						_ref10 = _i6.value;                                                                                             // 167
					}                                                                                                                // 167
                                                                                                                      //
					var u = _ref10;                                                                                                  // 167
                                                                                                                      //
					var _ret3 = _loop3(u);                                                                                           // 167
                                                                                                                      //
					if (_ret3 === 'continue') continue;                                                                              // 167
				}                                                                                                                 // 197
				_this3.collection.update({ _id: _this3.users._id }, { $set: { 'users': _this3.users.users } });                   // 198
                                                                                                                      //
				//Import the channels                                                                                             // 200
				_Importer$Base.prototype.updateProgress.call(_this3, Importer.ProgressStep.IMPORTING_CHANNELS);                   // 201
                                                                                                                      //
				var _loop4 = function () {                                                                                        // 164
					function _loop4(c) {                                                                                             // 164
						if (!c.do_import) {                                                                                             // 203
							return 'continue';                                                                                             // 204
						}                                                                                                               // 205
                                                                                                                      //
						Meteor.runAsUser(startedByUserId, function () {                                                                 // 207
							var existantRoom = RocketChat.models.Rooms.findOneByName(c.name);                                              // 208
							//If the room exists or the name of it is 'general', then we don't need to create it again                     // 209
							if (existantRoom || c.name.toUpperCase() === 'GENERAL') {                                                      // 210
								c.rocketId = c.name.toUpperCase() === 'GENERAL' ? 'GENERAL' : existantRoom._id;                               // 211
								RocketChat.models.Rooms.update({ _id: c.rocketId }, { $addToSet: { importIds: c.id } });                      // 212
							} else {                                                                                                       // 213
								//Find the rocketchatId of the user who created this channel                                                  // 214
								var creatorId = startedByUserId;                                                                              // 215
								for (var _iterator9 = _this3.users.users, _isArray9 = Array.isArray(_iterator9), _i9 = 0, _iterator9 = _isArray9 ? _iterator9 : _iterator9[Symbol.iterator]();;) {
									var _ref15;                                                                                                  // 216
                                                                                                                      //
									if (_isArray9) {                                                                                             // 216
										if (_i9 >= _iterator9.length) break;                                                                        // 216
										_ref15 = _iterator9[_i9++];                                                                                 // 216
									} else {                                                                                                     // 216
										_i9 = _iterator9.next();                                                                                    // 216
										if (_i9.done) break;                                                                                        // 216
										_ref15 = _i9.value;                                                                                         // 216
									}                                                                                                            // 216
                                                                                                                      //
									var _u = _ref15;                                                                                             // 216
                                                                                                                      //
									if (_u.username === c.creator && _u.do_import) {                                                             // 217
										creatorId = _u.rocketId;                                                                                    // 218
									}                                                                                                            // 219
								}                                                                                                             // 220
                                                                                                                      //
								//Create the channel                                                                                          // 222
								Meteor.runAsUser(creatorId, function () {                                                                     // 223
									var roomInfo = Meteor.call(c.isPrivate ? 'createPrivateGroup' : 'createChannel', c.name, c.members);         // 224
									c.rocketId = roomInfo.rid;                                                                                   // 225
								});                                                                                                           // 226
                                                                                                                      //
								RocketChat.models.Rooms.update({ _id: c.rocketId }, { $addToSet: { importIds: c.id } });                      // 228
							}                                                                                                              // 229
                                                                                                                      //
							_Importer$Base.prototype.addCountCompleted.call(_this3, 1);                                                    // 231
						});                                                                                                             // 232
					}                                                                                                                // 164
                                                                                                                      //
					return _loop4;                                                                                                   // 164
				}();                                                                                                              // 164
                                                                                                                      //
				for (var _iterator7 = _this3.channels.channels, _isArray7 = Array.isArray(_iterator7), _i7 = 0, _iterator7 = _isArray7 ? _iterator7 : _iterator7[Symbol.iterator]();;) {
					var _ref11;                                                                                                      // 202
                                                                                                                      //
					if (_isArray7) {                                                                                                 // 202
						if (_i7 >= _iterator7.length) break;                                                                            // 202
						_ref11 = _iterator7[_i7++];                                                                                     // 202
					} else {                                                                                                         // 202
						_i7 = _iterator7.next();                                                                                        // 202
						if (_i7.done) break;                                                                                            // 202
						_ref11 = _i7.value;                                                                                             // 202
					}                                                                                                                // 202
                                                                                                                      //
					var c = _ref11;                                                                                                  // 202
                                                                                                                      //
					var _ret4 = _loop4(c);                                                                                           // 202
                                                                                                                      //
					if (_ret4 === 'continue') continue;                                                                              // 202
				}                                                                                                                 // 233
				_this3.collection.update({ _id: _this3.channels._id }, { $set: { 'channels': _this3.channels.channels } });       // 234
                                                                                                                      //
				//Import the Messages                                                                                             // 236
				_Importer$Base.prototype.updateProgress.call(_this3, Importer.ProgressStep.IMPORTING_MESSAGES);                   // 237
                                                                                                                      //
				var _loop5 = function () {                                                                                        // 164
					function _loop5(ch, messagesMap) {                                                                               // 164
						var csvChannel = _this3.getChannelFromName(ch);                                                                 // 239
						if (!csvChannel.do_import) {                                                                                    // 240
							return 'continue';                                                                                             // 241
						}                                                                                                               // 242
                                                                                                                      //
						var room = RocketChat.models.Rooms.findOneById(csvChannel.rocketId, { fields: { usernames: 1, t: 1, name: 1 } });
						Meteor.runAsUser(startedByUserId, function () {                                                                 // 245
							for (var _iterator10 = messagesMap.entries(), _isArray10 = Array.isArray(_iterator10), _i10 = 0, _iterator10 = _isArray10 ? _iterator10 : _iterator10[Symbol.iterator]();;) {
								var _ref18;                                                                                                   // 246
                                                                                                                      //
								if (_isArray10) {                                                                                             // 246
									if (_i10 >= _iterator10.length) break;                                                                       // 246
									_ref18 = _iterator10[_i10++];                                                                                // 246
								} else {                                                                                                      // 246
									_i10 = _iterator10.next();                                                                                   // 246
									if (_i10.done) break;                                                                                        // 246
									_ref18 = _i10.value;                                                                                         // 246
								}                                                                                                             // 246
                                                                                                                      //
								var _ref16 = _ref18;                                                                                          // 246
                                                                                                                      //
								var _ref17 = _slicedToArray(_ref16, 2);                                                                       // 246
                                                                                                                      //
								var msgGroupData = _ref17[0];                                                                                 // 246
								var msgs = _ref17[1];                                                                                         // 246
                                                                                                                      //
								_Importer$Base.prototype.updateRecord.call(_this3, { 'messagesstatus': ch + '/' + msgGroupData + '.' + msgs.messages.length });
								for (var _iterator11 = msgs.messages, _isArray11 = Array.isArray(_iterator11), _i11 = 0, _iterator11 = _isArray11 ? _iterator11 : _iterator11[Symbol.iterator]();;) {
									var _ref19;                                                                                                  // 248
                                                                                                                      //
									if (_isArray11) {                                                                                            // 248
										if (_i11 >= _iterator11.length) break;                                                                      // 248
										_ref19 = _iterator11[_i11++];                                                                               // 248
									} else {                                                                                                     // 248
										_i11 = _iterator11.next();                                                                                  // 248
										if (_i11.done) break;                                                                                       // 248
										_ref19 = _i11.value;                                                                                        // 248
									}                                                                                                            // 248
                                                                                                                      //
									var msg = _ref19;                                                                                            // 248
                                                                                                                      //
									if (isNaN(new Date(parseInt(msg.ts)))) {                                                                     // 249
										_this3.logger.warn('Timestamp on a message in ' + ch + '/' + msgGroupData + ' is invalid');                 // 250
										_Importer$Base.prototype.addCountCompleted.call(_this3, 1);                                                 // 251
										continue;                                                                                                   // 252
									}                                                                                                            // 253
                                                                                                                      //
									var creator = _this3.getUserFromUsername(msg.username);                                                      // 255
									if (creator) {                                                                                               // 256
										var msgObj = {                                                                                              // 257
											_id: 'csv-' + csvChannel.id + '-' + msg.ts,                                                                // 258
											ts: new Date(parseInt(msg.ts)),                                                                            // 259
											msg: msg.text,                                                                                             // 260
											rid: room._id,                                                                                             // 261
											u: {                                                                                                       // 262
												_id: creator._id,                                                                                         // 263
												username: creator.username                                                                                // 264
											}                                                                                                          // 262
										};                                                                                                          // 257
                                                                                                                      //
										RocketChat.sendMessage(creator, msgObj, room, true);                                                        // 268
									}                                                                                                            // 269
                                                                                                                      //
									_Importer$Base.prototype.addCountCompleted.call(_this3, 1);                                                  // 271
								}                                                                                                             // 272
							}                                                                                                              // 273
						});                                                                                                             // 274
					}                                                                                                                // 164
                                                                                                                      //
					return _loop5;                                                                                                   // 164
				}();                                                                                                              // 164
                                                                                                                      //
				for (var _iterator8 = _this3.messages.entries(), _isArray8 = Array.isArray(_iterator8), _i8 = 0, _iterator8 = _isArray8 ? _iterator8 : _iterator8[Symbol.iterator]();;) {
					var _ref14;                                                                                                      // 238
                                                                                                                      //
					if (_isArray8) {                                                                                                 // 238
						if (_i8 >= _iterator8.length) break;                                                                            // 238
						_ref14 = _iterator8[_i8++];                                                                                     // 238
					} else {                                                                                                         // 238
						_i8 = _iterator8.next();                                                                                        // 238
						if (_i8.done) break;                                                                                            // 238
						_ref14 = _i8.value;                                                                                             // 238
					}                                                                                                                // 238
                                                                                                                      //
					var _ref12 = _ref14;                                                                                             // 238
                                                                                                                      //
					var _ref13 = _slicedToArray(_ref12, 2);                                                                          // 238
                                                                                                                      //
					var ch = _ref13[0];                                                                                              // 238
					var messagesMap = _ref13[1];                                                                                     // 238
                                                                                                                      //
					var _ret5 = _loop5(ch, messagesMap);                                                                             // 238
                                                                                                                      //
					if (_ret5 === 'continue') continue;                                                                              // 238
				}                                                                                                                 // 275
                                                                                                                      //
				_Importer$Base.prototype.updateProgress.call(_this3, Importer.ProgressStep.FINISHING);                            // 277
				_Importer$Base.prototype.updateProgress.call(_this3, Importer.ProgressStep.DONE);                                 // 278
				var timeTook = Date.now() - started;                                                                              // 279
				_this3.logger.log('CSV Import took ' + timeTook + ' milliseconds.');                                              // 280
			});                                                                                                                // 281
                                                                                                                      //
			return _Importer$Base.prototype.getProgress.call(this);                                                            // 283
		}                                                                                                                   // 284
                                                                                                                      //
		return startImport;                                                                                                 // 3
	}();                                                                                                                 // 3
                                                                                                                      //
	ImporterCSV.prototype.getSelection = function () {                                                                   // 3
		function getSelection() {                                                                                           // 3
			var selectionUsers = this.users.users.map(function (u) {                                                           // 287
				return new Importer.SelectionUser(u.id, u.username, u.email, false, false, true);                                 // 287
			});                                                                                                                // 287
			var selectionChannels = this.channels.channels.map(function (c) {                                                  // 288
				return new Importer.SelectionChannel(c.id, c.name, false, true, c.isPrivate);                                     // 288
			});                                                                                                                // 288
                                                                                                                      //
			return new Importer.Selection(this.name, selectionUsers, selectionChannels);                                       // 290
		}                                                                                                                   // 291
                                                                                                                      //
		return getSelection;                                                                                                // 3
	}();                                                                                                                 // 3
                                                                                                                      //
	ImporterCSV.prototype.getChannelFromName = function () {                                                             // 3
		function getChannelFromName(channelName) {                                                                          // 3
			for (var _iterator14 = this.channels.channels, _isArray14 = Array.isArray(_iterator14), _i14 = 0, _iterator14 = _isArray14 ? _iterator14 : _iterator14[Symbol.iterator]();;) {
				var _ref22;                                                                                                       // 294
                                                                                                                      //
				if (_isArray14) {                                                                                                 // 294
					if (_i14 >= _iterator14.length) break;                                                                           // 294
					_ref22 = _iterator14[_i14++];                                                                                    // 294
				} else {                                                                                                          // 294
					_i14 = _iterator14.next();                                                                                       // 294
					if (_i14.done) break;                                                                                            // 294
					_ref22 = _i14.value;                                                                                             // 294
				}                                                                                                                 // 294
                                                                                                                      //
				var ch = _ref22;                                                                                                  // 294
                                                                                                                      //
				if (ch.name === channelName) {                                                                                    // 295
					return ch;                                                                                                       // 296
				}                                                                                                                 // 297
			}                                                                                                                  // 298
		}                                                                                                                   // 299
                                                                                                                      //
		return getChannelFromName;                                                                                          // 3
	}();                                                                                                                 // 3
                                                                                                                      //
	ImporterCSV.prototype.getUserFromUsername = function () {                                                            // 3
		function getUserFromUsername(username) {                                                                            // 3
			for (var _iterator15 = this.users.users, _isArray15 = Array.isArray(_iterator15), _i15 = 0, _iterator15 = _isArray15 ? _iterator15 : _iterator15[Symbol.iterator]();;) {
				var _ref23;                                                                                                       // 302
                                                                                                                      //
				if (_isArray15) {                                                                                                 // 302
					if (_i15 >= _iterator15.length) break;                                                                           // 302
					_ref23 = _iterator15[_i15++];                                                                                    // 302
				} else {                                                                                                          // 302
					_i15 = _iterator15.next();                                                                                       // 302
					if (_i15.done) break;                                                                                            // 302
					_ref23 = _i15.value;                                                                                             // 302
				}                                                                                                                 // 302
                                                                                                                      //
				var u = _ref23;                                                                                                   // 302
                                                                                                                      //
				if (u.username === username) {                                                                                    // 303
					return RocketChat.models.Users.findOneById(u.rocketId, { fields: { username: 1 } });                             // 304
				}                                                                                                                 // 305
			}                                                                                                                  // 306
		}                                                                                                                   // 307
                                                                                                                      //
		return getUserFromUsername;                                                                                         // 3
	}();                                                                                                                 // 3
                                                                                                                      //
	return ImporterCSV;                                                                                                  // 3
}(Importer.Base);                                                                                                     // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"main.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/rocketchat_importer-csv/main.js                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/* globals Importer */                                                                                                // 1
                                                                                                                      //
Importer.addImporter('csv', Importer.CSV, {                                                                           // 3
	name: 'CSV',                                                                                                         // 4
	warnings: [{                                                                                                         // 5
		text: 'Importer_CSV_Information',                                                                                   // 6
		href: 'https://rocket.chat/docs/administrator-guides/import/csv/'                                                   // 7
	}],                                                                                                                  // 5
	fileTypeRegex: new RegExp('application\/.*?zip')                                                                     // 9
});                                                                                                                   // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/rocketchat:importer-csv/server.js");
require("./node_modules/meteor/rocketchat:importer-csv/main.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:importer-csv'] = {};

})();

//# sourceMappingURL=rocketchat_importer-csv.js.map
