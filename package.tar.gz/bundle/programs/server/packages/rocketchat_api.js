(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var _ = Package.underscore._;
var ECMAScript = Package.ecmascript.ECMAScript;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var Restivus = Package['nimble:restivus'].Restivus;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;

/* Package-scope variables */
var __coffeescriptShare;

var require = meteorInstall({"node_modules":{"meteor":{"rocketchat:api":{"server":{"api.coffee.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/rocketchat_api/server/api.coffee.js                                                                 //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var API,                                                                                                        // 1
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                                                                  //
                                                                                                                //
API = (function(superClass) {                                                                                   // 1
  extend(API, superClass);                                                                                      //
                                                                                                                //
  function API() {                                                                                              //
    this.authMethods = [];                                                                                      //
    API.__super__.constructor.apply(this, arguments);                                                           //
  }                                                                                                             //
                                                                                                                //
  API.prototype.addAuthMethod = function(method) {                                                              //
    return this.authMethods.push(method);                                                                       //
  };                                                                                                            //
                                                                                                                //
  API.prototype.success = function(result) {                                                                    //
    if (result == null) {                                                                                       //
      result = {};                                                                                              //
    }                                                                                                           //
    if (_.isObject(result)) {                                                                                   //
      result.success = true;                                                                                    //
    }                                                                                                           //
    return {                                                                                                    // 13
      statusCode: 200,                                                                                          //
      body: result                                                                                              //
    };                                                                                                          //
  };                                                                                                            //
                                                                                                                //
  API.prototype.failure = function(result) {                                                                    //
    if (_.isObject(result)) {                                                                                   //
      result.success = false;                                                                                   //
    } else {                                                                                                    //
      result = {                                                                                                //
        success: false,                                                                                         //
        error: result                                                                                           //
      };                                                                                                        //
    }                                                                                                           //
    return {                                                                                                    // 25
      statusCode: 400,                                                                                          //
      body: result                                                                                              //
    };                                                                                                          //
  };                                                                                                            //
                                                                                                                //
  API.prototype.unauthorized = function(msg) {                                                                  //
    return {                                                                                                    // 30
      statusCode: 403,                                                                                          //
      body: {                                                                                                   //
        success: false,                                                                                         //
        error: msg || 'unauthorized'                                                                            //
      }                                                                                                         //
    };                                                                                                          //
  };                                                                                                            //
                                                                                                                //
  return API;                                                                                                   //
                                                                                                                //
})(Restivus);                                                                                                   //
                                                                                                                //
RocketChat.API = {};                                                                                            // 37
                                                                                                                //
RocketChat.API.v1 = new API({                                                                                   // 40
  version: 'v1',                                                                                                //
  useDefaultAuth: true,                                                                                         //
  prettyJson: true,                                                                                             //
  enableCors: false,                                                                                            //
  auth: {                                                                                                       //
    token: 'services.resume.loginTokens.hashedToken',                                                           //
    user: function() {                                                                                          //
      var i, len, method, ref, ref1, result, token;                                                             // 48
      if (((ref = this.bodyParams) != null ? ref.payload : void 0) != null) {                                   //
        this.bodyParams = JSON.parse(this.bodyParams.payload);                                                  //
      }                                                                                                         //
      ref1 = RocketChat.API.v1.authMethods;                                                                     // 51
      for (i = 0, len = ref1.length; i < len; i++) {                                                            // 51
        method = ref1[i];                                                                                       //
        result = method.apply(this, arguments);                                                                 //
        if (result !== (void 0) && result !== null && result !== false) {                                       //
          return result;                                                                                        // 54
        }                                                                                                       //
      }                                                                                                         // 51
      if (this.request.headers['x-auth-token']) {                                                               //
        token = Accounts._hashLoginToken(this.request.headers['x-auth-token']);                                 //
      }                                                                                                         //
      return {                                                                                                  // 59
        userId: this.request.headers['x-user-id'],                                                              //
        token: token                                                                                            //
      };                                                                                                        //
    }                                                                                                           //
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.coffee.js":function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/rocketchat_api/server/routes.coffee.js                                                              //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat.API.v1.addRoute('info', {                                                                            // 1
  authRequired: false                                                                                           //
}, {                                                                                                            //
  get: function() {                                                                                             //
    return RocketChat.Info;                                                                                     //
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
RocketChat.API.v1.addRoute('me', {                                                                              // 5
  authRequired: true                                                                                            //
}, {                                                                                                            //
  get: function() {                                                                                             //
    return _.pick(this.user, ['_id', 'name', 'emails', 'status', 'statusConnection', 'username', 'utcOffset', 'active', 'language']);
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
RocketChat.API.v1.addRoute('chat.messageExamples', {                                                            // 21
  authRequired: true                                                                                            //
}, {                                                                                                            //
  get: function() {                                                                                             //
    return RocketChat.API.v1.success({                                                                          // 23
      body: [                                                                                                   //
        {                                                                                                       //
          token: Random.id(24),                                                                                 //
          channel_id: Random.id(),                                                                              //
          channel_name: 'general',                                                                              //
          timestamp: new Date,                                                                                  //
          user_id: Random.id(),                                                                                 //
          user_name: 'rocket.cat',                                                                              //
          text: 'Sample text 1',                                                                                //
          trigger_word: 'Sample'                                                                                //
        }, {                                                                                                    //
          token: Random.id(24),                                                                                 //
          channel_id: Random.id(),                                                                              //
          channel_name: 'general',                                                                              //
          timestamp: new Date,                                                                                  //
          user_id: Random.id(),                                                                                 //
          user_name: 'rocket.cat',                                                                              //
          text: 'Sample text 2',                                                                                //
          trigger_word: 'Sample'                                                                                //
        }, {                                                                                                    //
          token: Random.id(24),                                                                                 //
          channel_id: Random.id(),                                                                              //
          channel_name: 'general',                                                                              //
          timestamp: new Date,                                                                                  //
          user_id: Random.id(),                                                                                 //
          user_name: 'rocket.cat',                                                                              //
          text: 'Sample text 3',                                                                                //
          trigger_word: 'Sample'                                                                                //
        }                                                                                                       //
      ]                                                                                                         //
    });                                                                                                         //
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
RocketChat.API.v1.addRoute('chat.postMessage', {                                                                // 55
  authRequired: true                                                                                            //
}, {                                                                                                            //
  post: function() {                                                                                            //
    var e, messageReturn;                                                                                       // 57
    try {                                                                                                       // 57
      messageReturn = processWebhookMessage(this.bodyParams, this.user);                                        //
      if (messageReturn == null) {                                                                              //
        return RocketChat.API.v1.failure('unknown-error');                                                      // 61
      }                                                                                                         //
      return RocketChat.API.v1.success({                                                                        // 63
        ts: Date.now(),                                                                                         //
        channel: messageReturn.channel,                                                                         //
        message: messageReturn.message                                                                          //
      });                                                                                                       //
    } catch (error) {                                                                                           //
      e = error;                                                                                                //
      return RocketChat.API.v1.failure(e.error);                                                                // 68
    }                                                                                                           //
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
RocketChat.API.v1.addRoute('channels.setTopic', {                                                               // 71
  authRequired: true                                                                                            //
}, {                                                                                                            //
  post: function() {                                                                                            //
    if (this.bodyParams.channel == null) {                                                                      //
      return RocketChat.API.v1.failure('Body param "channel" is required');                                     // 74
    }                                                                                                           //
    if (this.bodyParams.topic == null) {                                                                        //
      return RocketChat.API.v1.failure('Body param "topic" is required');                                       // 77
    }                                                                                                           //
    if (!RocketChat.authz.hasPermission(this.userId, 'edit-room', this.bodyParams.channel)) {                   //
      return RocketChat.API.v1.unauthorized();                                                                  // 80
    }                                                                                                           //
    if (!RocketChat.saveRoomTopic(this.bodyParams.channel, this.bodyParams.topic, this.user)) {                 //
      return RocketChat.API.v1.failure('invalid_channel');                                                      // 83
    }                                                                                                           //
    return RocketChat.API.v1.success({                                                                          // 85
      topic: this.bodyParams.topic                                                                              //
    });                                                                                                         //
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
RocketChat.API.v1.addRoute('channels.create', {                                                                 // 90
  authRequired: true                                                                                            //
}, {                                                                                                            //
  post: function() {                                                                                            //
    var e, id;                                                                                                  // 92
    if (this.bodyParams.name == null) {                                                                         //
      return RocketChat.API.v1.failure('Body param "name" is required');                                        // 93
    }                                                                                                           //
    if (!RocketChat.authz.hasPermission(this.userId, 'create-c')) {                                             //
      return RocketChat.API.v1.unauthorized();                                                                  // 96
    }                                                                                                           //
    id = void 0;                                                                                                //
    try {                                                                                                       // 99
      Meteor.runAsUser(this.userId, (function(_this) {                                                          //
        return function() {                                                                                     //
          return id = Meteor.call('createChannel', _this.bodyParams.name, []);                                  //
        };                                                                                                      //
      })(this));                                                                                                //
    } catch (error) {                                                                                           //
      e = error;                                                                                                //
      return RocketChat.API.v1.failure(e.name + ': ' + e.message);                                              // 103
    }                                                                                                           //
    return RocketChat.API.v1.success({                                                                          // 105
      channel: RocketChat.models.Rooms.findOneById(id.rid)                                                      //
    });                                                                                                         //
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
RocketChat.API.v1.addRoute('channels.history', {                                                                // 108
  authRequired: true                                                                                            //
}, {                                                                                                            //
  get: function() {                                                                                             //
    var count, e, inclusive, latestDate, oldestDate, result, rid, unreads;                                      // 110
    if (this.queryParams.roomId == null) {                                                                      //
      return RocketChat.API.v1.failure('Query parameter "roomId" is required.');                                // 111
    }                                                                                                           //
    rid = this.queryParams.roomId;                                                                              //
    latestDate = new Date;                                                                                      //
    if (this.queryParams.latest != null) {                                                                      //
      latestDate = new Date(this.queryParams.latest);                                                           //
    }                                                                                                           //
    oldestDate = void 0;                                                                                        //
    if (this.queryParams.oldest != null) {                                                                      //
      oldestDate = new Date(this.queryParams.oldest);                                                           //
    }                                                                                                           //
    inclusive = false;                                                                                          //
    if (this.queryParams.inclusive != null) {                                                                   //
      inclusive = this.queryParams.inclusive;                                                                   //
    }                                                                                                           //
    count = 20;                                                                                                 //
    if (this.queryParams.count != null) {                                                                       //
      count = parseInt(this.queryParams.count);                                                                 //
    }                                                                                                           //
    unreads = false;                                                                                            //
    if (this.queryParams.unreads != null) {                                                                     //
      unreads = this.queryParams.unreads;                                                                       //
    }                                                                                                           //
    result = {};                                                                                                //
    try {                                                                                                       // 137
      Meteor.runAsUser(this.userId, (function(_this) {                                                          //
        return function() {                                                                                     //
          return result = Meteor.call('getChannelHistory', {                                                    //
            rid: rid,                                                                                           //
            latest: latestDate,                                                                                 //
            oldest: oldestDate,                                                                                 //
            inclusive: inclusive,                                                                               //
            count: count,                                                                                       //
            unreads: unreads                                                                                    //
          });                                                                                                   //
        };                                                                                                      //
      })(this));                                                                                                //
    } catch (error) {                                                                                           //
      e = error;                                                                                                //
      return RocketChat.API.v1.failure(e.name + ': ' + e.message);                                              // 141
    }                                                                                                           //
    return RocketChat.API.v1.success({                                                                          // 143
      result: result                                                                                            //
    });                                                                                                         //
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
RocketChat.API.v1.addRoute('channels.cleanHistory', {                                                           // 146
  authRequired: true                                                                                            //
}, {                                                                                                            //
  post: function() {                                                                                            //
    var e, inclusive, latest, oldest, roomId;                                                                   // 148
    if (this.bodyParams.roomId == null) {                                                                       //
      return RocketChat.API.v1.failure('Body parameter "roomId" is required.');                                 // 149
    }                                                                                                           //
    roomId = this.bodyParams.roomId;                                                                            //
    if (this.bodyParams.latest == null) {                                                                       //
      return RocketChat.API.v1.failure('Body parameter "latest" is required.');                                 // 154
    }                                                                                                           //
    if (this.bodyParams.oldest == null) {                                                                       //
      return RocketChat.API.v1.failure('Body parameter "oldest" is required.');                                 // 157
    }                                                                                                           //
    latest = new Date(this.bodyParams.latest);                                                                  //
    oldest = new Date(this.bodyParams.oldest);                                                                  //
    inclusive = false;                                                                                          //
    if (this.bodyParams.inclusive != null) {                                                                    //
      inclusive = this.bodyParams.inclusive;                                                                    //
    }                                                                                                           //
    try {                                                                                                       // 166
      Meteor.runAsUser(this.userId, (function(_this) {                                                          //
        return function() {                                                                                     //
          return Meteor.call('cleanChannelHistory', {                                                           //
            roomId: roomId,                                                                                     //
            latest: latest,                                                                                     //
            oldest: oldest,                                                                                     //
            inclusive: inclusive                                                                                //
          });                                                                                                   //
        };                                                                                                      //
      })(this));                                                                                                //
    } catch (error) {                                                                                           //
      e = error;                                                                                                //
      return RocketChat.API.v1.failure(e.name + ': ' + e.message);                                              // 170
    }                                                                                                           //
    return RocketChat.API.v1.success({                                                                          // 172
      success: true                                                                                             //
    });                                                                                                         //
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
RocketChat.API.v1.addRoute('groups.list', {                                                                     // 176
  authRequired: true                                                                                            //
}, {                                                                                                            //
  get: function() {                                                                                             //
    var roomIds;                                                                                                // 178
    roomIds = _.pluck(RocketChat.models.Subscriptions.findByTypeAndUserId('p', this.userId).fetch(), 'rid');    //
    return {                                                                                                    // 179
      groups: RocketChat.models.Rooms.findByIds(roomIds).fetch()                                                //
    };                                                                                                          //
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
RocketChat.API.v1.addRoute('channel.addall', {                                                                  // 182
  authRequired: true                                                                                            //
}, {                                                                                                            //
  post: function() {                                                                                            //
    var e, id;                                                                                                  // 185
    id = void 0;                                                                                                //
    try {                                                                                                       // 186
      Meteor.runAsUser(this.userId, (function(_this) {                                                          //
        return function() {                                                                                     //
          return id = Meteor.call('addAllUserToRoom', _this.bodyParams.roomId, []);                             //
        };                                                                                                      //
      })(this));                                                                                                //
    } catch (error) {                                                                                           //
      e = error;                                                                                                //
      return RocketChat.API.v1.failure(e.name + ': ' + e.message);                                              // 190
    }                                                                                                           //
    return RocketChat.API.v1.success({                                                                          // 192
      channel: RocketChat.models.Rooms.findOneById(this.bodyParams.roomId)                                      //
    });                                                                                                         //
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
RocketChat.API.v1.addRoute('users.list', {                                                                      // 196
  authRequired: true                                                                                            //
}, {                                                                                                            //
  get: function() {                                                                                             //
    if (RocketChat.authz.hasRole(this.userId, 'admin') === false) {                                             //
      return RocketChat.API.v1.unauthorized();                                                                  // 199
    }                                                                                                           //
    return {                                                                                                    // 201
      users: RocketChat.models.Users.find().fetch()                                                             //
    };                                                                                                          //
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
RocketChat.API.v1.addRoute('users.create', {                                                                    // 204
  authRequired: true                                                                                            //
}, {                                                                                                            //
  post: function() {                                                                                            //
    var e, nameValidation, newUserId, user, userData;                                                           // 206
    try {                                                                                                       // 206
      check(this.bodyParams, {                                                                                  //
        email: String,                                                                                          //
        name: String,                                                                                           //
        password: String,                                                                                       //
        username: String,                                                                                       //
        role: Match.Maybe(String),                                                                              //
        joinDefaultChannels: Match.Maybe(Boolean),                                                              //
        requirePasswordChange: Match.Maybe(Boolean),                                                            //
        sendWelcomeEmail: Match.Maybe(Boolean),                                                                 //
        verified: Match.Maybe(Boolean),                                                                         //
        customFields: Match.Maybe(Object)                                                                       //
      });                                                                                                       //
      try {                                                                                                     // 220
        nameValidation = new RegExp('^' + RocketChat.settings.get('UTF8_Names_Validation') + '$');              //
      } catch (error) {                                                                                         //
        nameValidation = new RegExp('^[0-9a-zA-Z-_.]+$');                                                       //
      }                                                                                                         //
      if (!nameValidation.test(this.bodyParams.username)) {                                                     //
        return RocketChat.API.v1.failure('Invalid username');                                                   // 226
      }                                                                                                         //
      if (!RocketChat.checkUsernameAvailability(this.bodyParams.username)) {                                    //
        return RocketChat.API.v1.failure('Username not available');                                             // 229
      }                                                                                                         //
      userData = {};                                                                                            //
      newUserId = RocketChat.saveUser(this.userId, this.bodyParams);                                            //
      if (this.bodyParams.customFields != null) {                                                               //
        RocketChat.saveCustomFields(newUserId, this.bodyParams.customFields);                                   //
      }                                                                                                         //
      user = RocketChat.models.Users.findOneById(newUserId);                                                    //
      if (typeof this.bodyParams.joinDefaultChannels === 'undefined' || this.bodyParams.joinDefaultChannels) {  //
        RocketChat.addUserToDefaultChannels(user);                                                              //
      }                                                                                                         //
      return RocketChat.API.v1.success({                                                                        // 243
        user: user                                                                                              //
      });                                                                                                       //
    } catch (error) {                                                                                           //
      e = error;                                                                                                //
      return RocketChat.API.v1.failure(e.name + ': ' + e.message);                                              // 246
    }                                                                                                           //
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
RocketChat.API.v1.addRoute('user.update', {                                                                     // 249
  authRequired: true                                                                                            //
}, {                                                                                                            //
  post: function() {                                                                                            //
    var e, userData;                                                                                            // 251
    try {                                                                                                       // 251
      check(this.bodyParams, {                                                                                  //
        userId: String,                                                                                         //
        data: {                                                                                                 //
          email: Match.Maybe(String),                                                                           //
          name: Match.Maybe(String),                                                                            //
          password: Match.Maybe(String),                                                                        //
          username: Match.Maybe(String),                                                                        //
          role: Match.Maybe(String),                                                                            //
          joinDefaultChannels: Match.Maybe(Boolean),                                                            //
          requirePasswordChange: Match.Maybe(Boolean),                                                          //
          sendWelcomeEmail: Match.Maybe(Boolean),                                                               //
          verified: Match.Maybe(Boolean),                                                                       //
          customFields: Match.Maybe(Object)                                                                     //
        }                                                                                                       //
      });                                                                                                       //
      userData = _.extend({                                                                                     //
        _id: this.bodyParams.userId                                                                             //
      }, this.bodyParams.data);                                                                                 //
      RocketChat.saveUser(this.userId, userData);                                                               //
      if (this.bodyParams.data.customFields != null) {                                                          //
        RocketChat.saveCustomFields(this.bodyParams.userId, this.bodyParams.data.customFields);                 //
      }                                                                                                         //
      return RocketChat.API.v1.success({                                                                        // 273
        user: RocketChat.models.Users.findOneById(this.bodyParams.userId)                                       //
      });                                                                                                       //
    } catch (error) {                                                                                           //
      e = error;                                                                                                //
      return RocketChat.API.v1.failure(e.name + ': ' + e.message);                                              // 276
    }                                                                                                           //
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
RocketChat.API.v1.addRoute('user.info', {                                                                       // 279
  authRequired: true                                                                                            //
}, {                                                                                                            //
  post: function() {                                                                                            //
    if (RocketChat.authz.hasRole(this.userId, 'admin') === false) {                                             //
      return RocketChat.API.v1.unauthorized();                                                                  // 282
    }                                                                                                           //
    return {                                                                                                    // 284
      user: RocketChat.models.Users.findOneByUsername(this.bodyParams.name)                                     //
    };                                                                                                          //
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
RocketChat.API.v1.addRoute('user.getpresence', {                                                                // 287
  authRequired: true                                                                                            //
}, {                                                                                                            //
  post: function() {                                                                                            //
    return {                                                                                                    // 289
      user: RocketChat.models.Users.findOne({                                                                   //
        username: this.bodyParams.name                                                                          //
      }, {                                                                                                      //
        fields: {                                                                                               //
          status: 1                                                                                             //
        }                                                                                                       //
      })                                                                                                        //
    };                                                                                                          //
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
RocketChat.API.v1.addRoute('users.delete', {                                                                    // 292
  authRequired: true                                                                                            //
}, {                                                                                                            //
  post: function() {                                                                                            //
    var e, id;                                                                                                  // 294
    if (this.bodyParams.userId == null) {                                                                       //
      return RocketChat.API.v1.failure('Body param "userId" is required');                                      // 295
    }                                                                                                           //
    if (!RocketChat.authz.hasPermission(this.userId, 'delete-user')) {                                          //
      return RocketChat.API.v1.unauthorized();                                                                  // 298
    }                                                                                                           //
    id = void 0;                                                                                                //
    try {                                                                                                       // 301
      Meteor.runAsUser(this.userId, (function(_this) {                                                          //
        return function() {                                                                                     //
          return id = Meteor.call('deleteUser', _this.bodyParams.userId, []);                                   //
        };                                                                                                      //
      })(this));                                                                                                //
    } catch (error) {                                                                                           //
      e = error;                                                                                                //
      return RocketChat.API.v1.failure(e.name + ': ' + e.message);                                              // 305
    }                                                                                                           //
    return RocketChat.API.v1.success;                                                                           // 307
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
RocketChat.API.v1.addRoute('users.setAvatar', {                                                                 // 310
  authRequired: true                                                                                            //
}, {                                                                                                            //
  post: function() {                                                                                            //
    var Busboy, busboy, e, user;                                                                                // 312
    try {                                                                                                       // 312
      Busboy = Npm.require('busboy');                                                                           //
      busboy = new Busboy({                                                                                     //
        headers: this.request.headers                                                                           //
      });                                                                                                       //
      user = Meteor.users.findOne(this.userId);                                                                 //
      Meteor.wrapAsync((function(_this) {                                                                       //
        return function(callback) {                                                                             //
          busboy.on('file', Meteor.bindEnvironment(function(fieldname, file, filename, encoding, mimetype) {    //
            var imageData;                                                                                      // 321
            if (fieldname !== 'image') {                                                                        //
              return callback(new Meteor.Error('invalid-field'));                                               // 322
            }                                                                                                   //
            imageData = [];                                                                                     //
            file.on('data', Meteor.bindEnvironment(function(data) {                                             //
              return imageData.push(data);                                                                      //
            }));                                                                                                //
            return file.on('end', Meteor.bindEnvironment(function() {                                           //
              RocketChat.setUserAvatar(user, Buffer.concat(imageData), mimetype, 'rest');                       //
              return callback();                                                                                //
            }));                                                                                                //
          }));                                                                                                  //
          return _this.request.pipe(busboy);                                                                    //
        };                                                                                                      //
      })(this))();                                                                                              //
    } catch (error) {                                                                                           //
      e = error;                                                                                                //
      return RocketChat.API.v1.failure(e.name + ': ' + e.message);                                              // 335
    }                                                                                                           //
    return RocketChat.API.v1.success();                                                                         // 337
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
RocketChat.API.v1.addRoute('groups.create', {                                                                   // 340
  authRequired: true                                                                                            //
}, {                                                                                                            //
  post: function() {                                                                                            //
    var e, id;                                                                                                  // 342
    if (this.bodyParams.name == null) {                                                                         //
      return RocketChat.API.v1.failure('Body param "name" is required');                                        // 343
    }                                                                                                           //
    if (!RocketChat.authz.hasPermission(this.userId, 'create-p')) {                                             //
      return RocketChat.API.v1.unauthorized();                                                                  // 346
    }                                                                                                           //
    id = void 0;                                                                                                //
    try {                                                                                                       // 349
      if (this.bodyParams.members == null) {                                                                    //
        Meteor.runAsUser(this.userId, (function(_this) {                                                        //
          return function() {                                                                                   //
            return id = Meteor.call('createPrivateGroup', _this.bodyParams.name, []);                           //
          };                                                                                                    //
        })(this));                                                                                              //
      } else {                                                                                                  //
        Meteor.runAsUser(this.userId, (function(_this) {                                                        //
          return function() {                                                                                   //
            return id = Meteor.call('createPrivateGroup', _this.bodyParams.name, _this.bodyParams.members, []);
          };                                                                                                    //
        })(this));                                                                                              //
      }                                                                                                         //
    } catch (error) {                                                                                           //
      e = error;                                                                                                //
      return RocketChat.API.v1.failure(e.name + ': ' + e.message);                                              // 357
    }                                                                                                           //
    return RocketChat.API.v1.success({                                                                          // 359
      group: RocketChat.models.Rooms.findOneById(id.rid)                                                        //
    });                                                                                                         //
  }                                                                                                             //
});                                                                                                             //
                                                                                                                //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"settings.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/rocketchat_api/server/settings.js                                                                   //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
// settings endpoints                                                                                           // 1
RocketChat.API.v1.addRoute('settings/:_id', { authRequired: true }, {                                           // 2
	get: function () {                                                                                             // 3
		function get() {                                                                                              // 2
			if (!RocketChat.authz.hasPermission(this.userId, 'view-privileged-setting')) {                               // 4
				return RocketChat.API.v1.unauthorized();                                                                    // 5
			}                                                                                                            // 6
                                                                                                                //
			return RocketChat.API.v1.success(_.pick(RocketChat.models.Settings.findOneNotHiddenById(this.urlParams._id), '_id', 'value'));
		}                                                                                                             // 9
                                                                                                                //
		return get;                                                                                                   // 2
	}(),                                                                                                           // 2
	post: function () {                                                                                            // 10
		function post() {                                                                                             // 2
			if (!RocketChat.authz.hasPermission(this.userId, 'edit-privileged-setting')) {                               // 11
				return RocketChat.API.v1.unauthorized();                                                                    // 12
			}                                                                                                            // 13
                                                                                                                //
			try {                                                                                                        // 15
				check(this.bodyParams, {                                                                                    // 16
					value: Match.Any                                                                                           // 17
				});                                                                                                         // 16
                                                                                                                //
				if (RocketChat.models.Settings.updateValueNotHiddenById(this.urlParams._id, this.bodyParams.value)) {       // 20
					return RocketChat.API.v1.success();                                                                        // 21
				}                                                                                                           // 22
                                                                                                                //
				return RocketChat.API.v1.failure();                                                                         // 24
			} catch (e) {                                                                                                // 25
				return RocketChat.API.v1.failure(e.message);                                                                // 26
			}                                                                                                            // 27
		}                                                                                                             // 28
                                                                                                                //
		return post;                                                                                                  // 2
	}()                                                                                                            // 2
});                                                                                                             // 2
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}},{"extensions":[".js",".json",".coffee"]});
require("./node_modules/meteor/rocketchat:api/server/api.coffee.js");
require("./node_modules/meteor/rocketchat:api/server/routes.coffee.js");
require("./node_modules/meteor/rocketchat:api/server/settings.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:api'] = {};

})();

//# sourceMappingURL=rocketchat_api.js.map
