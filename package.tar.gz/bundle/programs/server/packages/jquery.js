(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.jquery = {};

})();
